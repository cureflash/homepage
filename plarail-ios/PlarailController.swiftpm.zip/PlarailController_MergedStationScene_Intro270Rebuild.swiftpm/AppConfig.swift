import Foundation
import CoreGraphics

/// UI配置以外のアプリ設定。
///
/// - モーター指令値・速度計・加減速時間: `Motor`
/// - 音声ID・再生間隔・BUSY判定・音声選択規則: `Audio`
/// - 画面上の位置と大きさ: `UILayoutConfig.swift`
///
/// ESP32側にも同じ目的のConfigがあります。Duty、時間、音声IDを変更する場合は、
/// アプリとESP32の設定が矛盾しないように両方を確認してください。
enum AppConfig {
    enum Build {
        static let label = "BUILD 2026.08.08 CFG6"
    }

    enum Debug {
        static let mode2Passcode = "debugmode2"
        static let legacyMode2Passcode = "debgumode2"

        /// Debug Mode 2で短い音声を再生したとみなす時間。
        static let simulatedShortAudioDuration: TimeInterval = 1.2
        /// Debug Mode 2で長い車内放送を再生したとみなす時間。
        static let simulatedAnnouncementDuration: TimeInterval = 1.2
        /// 非常停止復帰の疑似整定時間。
        static let emergencyResetDuration: TimeInterval = 2.0
        /// Debug Mode 2でマイコン応答を受信したとみなすまでの時間。
        static let simulatedMicrocontrollerResponseDelay: TimeInterval = 5.0
    }

    enum Refresh {
        static let simulationInterval: TimeInterval = 0.1
        static let clockInterval: TimeInterval = 1.0
    }

    enum BLE {
        static let peripheralLocalName = "prarail-controller"
        static let serviceUUID = "7BEB2D00-4A65-4AA1-9D8A-5B6011E0A001"
        static let commandUUID = "7BEB2D01-4A65-4AA1-9D8A-5B6011E0A001"
        static let telemetryUUID = "7BEB2D02-4A65-4AA1-9D8A-5B6011E0A001"

        static let heartbeatInterval: TimeInterval = 5
        static let heartbeatHealthyAge: TimeInterval = 8
        static let voltageTelemetryInterval: TimeInterval = 5
        static let voltageTelemetryMissLimit = 2
        static let voltageTelemetryHealthyAge: TimeInterval = 10
        static let maximumTransportLogEntries = 300
    }

    // MARK: - Motor

    /// アプリから送るDuty、速度計の表示値、加減速時間をすべてここで調整する。
    /// Dutyは1000分率。例: 700 = 70%。
    enum Motor {
        // Dutyの有効範囲
        static let minimumDutyPermille = 0.0
        static let maximumDutyPermille = 1000.0
        static let dutyEqualityTolerancePermille = 0.5
        /// ESP32の段階Duty通知を400/700付近と判定する許容幅。
        static let telemetryStageDetectionTolerancePermille = 5
        static let minimumAnimationDuration: TimeInterval = 0.01

        // 各ノッチのDuty
        static let stopDutyPermille = 0
        static let dutyN = 400
        static let dutyP1 = 500
        static let dutyP2 = 600
        static let dutyP3 = 700
        static let dutyP4 = 800
        static let dutyP5 = 900
        static let dutyP6 = 1000

        // 各ノッチの速度計表示値（実速度センサー値ではない）
        static let displaySpeedN = 20
        static let displaySpeedP1 = 70
        static let displaySpeedP2 = 100
        static let displaySpeedP3 = 180
        static let displaySpeedP4 = 230
        static let displaySpeedP5 = 270
        static let displaySpeedP6 = 300

        // 速度計LED折れ線上の段階位置
        static let gaugeStepN = 1
        static let gaugeStepP1 = 2
        static let gaugeStepP2 = 3
        static let gaugeStepP3 = 4
        static let gaugeStepP4 = 5
        static let gaugeStepP5 = 6
        static let gaugeStepP6 = 7

        // 発車ボタンで使用する初期ノッチ
        static let defaultDepartureNotch: Notch = .p3

        // 通常ノッチ変更。1‰あたりの表示変化時間。
        static let manualMillisecondsPerPermille = 15.0

        // 発車時の二段始動プロファイル（0→400‰を0.5秒、400→700‰を6秒）
        static let startupFirstDuty = 400.0
        static let startupSecondDuty = 700.0
        static let startupFirstStageDuration: TimeInterval = 0.5
        static let startupSecondStageDuration: TimeInterval = 6.0

        // 停車プロファイル表示
        static let stopEffectiveDutyPermille = 200
        static let stopDisplayDuration = Stop.finalBrakeDisplayDuration
        static let stopFinalCutToZeroIsImmediate = true

        // 互換名。既存コードからも同じConfigを参照する。
        static let normalNotchDutyDifference = 100.0
        static var normalNotchDuration: TimeInterval {
            normalNotchDutyDifference * manualMillisecondsPerPermille / 1000.0
        }
        static let startupTo400Duration = startupFirstStageDuration
        static let startup400To700Duration = startupSecondStageDuration
        // 旧名互換。値は現在400→700‰の時間を表す。
        static let startup400To500Duration = startup400To700Duration

        static func dutyPermille(for notch: Notch) -> Int {
            switch notch {
            case .n: return dutyN
            case .p1: return dutyP1
            case .p2: return dutyP2
            case .p3: return dutyP3
            case .p4: return dutyP4
            case .p5: return dutyP5
            case .p6: return dutyP6
            }
        }

        static func displaySpeed(for notch: Notch) -> Int {
            switch notch {
            case .n: return displaySpeedN
            case .p1: return displaySpeedP1
            case .p2: return displaySpeedP2
            case .p3: return displaySpeedP3
            case .p4: return displaySpeedP4
            case .p5: return displaySpeedP5
            case .p6: return displaySpeedP6
            }
        }

        static func gaugeStep(for notch: Notch) -> Int {
            switch notch {
            case .n: return gaugeStepN
            case .p1: return gaugeStepP1
            case .p2: return gaugeStepP2
            case .p3: return gaugeStepP3
            case .p4: return gaugeStepP4
            case .p5: return gaugeStepP5
            case .p6: return gaugeStepP6
            }
        }

        static func notch(forDutyPermille duty: Int) -> Notch? {
            switch duty {
            case dutyN: return .n
            case dutyP1: return .p1
            case dutyP2: return .p2
            case dutyP3: return .p3
            case dutyP4: return .p4
            case dutyP5: return .p5
            case dutyP6: return .p6
            default: return nil
            }
        }
    }

    // MARK: - Stop sequence timing

    /// 停車シーケンスの時間・0km/h判定はここで一括調整する。
    enum Stop {
        /// 180km/hまでの予備減速目標。
        static let preDecelerationTargetDutyPermille = Motor.dutyP3
        static let preDecelerationTargetSpeed = Motor.displaySpeedP3
        /// 180km/h超から180km/hまで落とす表示時間。
        static let preDecelerationDuration: TimeInterval = 10.0
        /// 180km/h到達後、停車チャイム開始まで。
        static let chimeDelayAfterReachingTarget: TimeInterval = 1.0
        /// すでに180km/h以下で停車ボタンを押した場合、停車チャイムは即時開始する。
        static let chimeDelayWhenAlreadyAtOrBelowTarget: TimeInterval = 0.0
        /// 停車チャイム終了後、180km/hへの予備減速を開始するまで。
        static let preDecelerationDelayAfterChime: TimeInterval = 2.0
        /// 180km/h以下で予備減速が不要な場合、停車チャイム終了後から車内放送開始まで。
        static let announcementDelayAfterChime: TimeInterval = 0.0
        /// 180km/hへの予備減速完了後、車内放送開始まで。
        static let announcementDelayAfterPreDeceleration: TimeInterval = 0.0
        /// 車内放送終了後、最終減速開始まで。
        static let finalBrakeDelayAfterAnnouncement: TimeInterval = 2.0
        /// 最終減速の速度計表示時間。
        static let finalBrakeDisplayDuration: TimeInterval = 7.0
        /// 速度計がこの値以下になったら0km/h到達として扱う。
        static let zeroSpeedDetectionThreshold: Double = 0.5
        /// 0km/h到達後、駅停車状態へ切り替えるまで。
        static let stoppedStateDelayAfterZero: TimeInterval = 0.5
        /// 停車ボタン押下後、掲示板を接近表示へ切り替えるまで。
        static let displayBlankingDelay: TimeInterval = 0.4
        /// 停車音声エラー時の次段処理待機。
        static let failureRecoveryDelay: TimeInterval = 1.5
        /// Debug Mode 2のSTOP_PROFILE疑似テレメトリ間隔。
        static let debugMotorTelemetryOffset: TimeInterval = 0.05
        static let debugVehicleReadyTelemetryOffset: TimeInterval = 0.05
    }

    // MARK: - Audio

    /// 音声ID、音声間隔、BUSY LOW判定、駅ごとの選択規則をここで調整する。
    enum Audio {
        // 車内チャイムID（途中駅 / 終着駅）
        static let hikariIntermediateTrack = 1000
        static let hikariTerminalTrack = 1001
        static let nozomiIntermediateTrack = 1002
        static let nozomiTerminalTrack = 1003
        static let ambitiousIntermediateTrack = 1004
        static let ambitiousTerminalTrack = 1005

        /// 「会いにいこう」は途中駅・終着駅とも同一音源。1006は使用しない。
        static let ainiIkouTrack = 1007
        static let ainiIkouIntermediateTrack = ainiIkouTrack
        static let ainiIkouTerminalTrack = ainiIkouTrack

        static let iiHiTabidachiIntermediateTrack = 1010
        static let iiHiTabidachiTerminalTrack = 1011

        // 基本音声ID
        static let defaultDepartureFirstTrack = 1009
        static let tokyoDownboundDepartureFirstTrack = nozomiTerminalTrack
        static let galaxyExpress999DepartureTrack = 1012
        static let sanyoHikariDepartureTrack = 1001
        static let otomeNoInoriTrack = 1008
        static let connectionHornTrack = 2000
        static let emergencyStopTrack = 2001
        static let lowVoltageStopTrack = 2002
        static let oldDoorChimeTrack = 2003
        static let atcTrack = 2004
        static let noAudioTrack = 0

        // 旧名互換
        static let departureBellTrack = defaultDepartureFirstTrack

        /// 下り東京駅発車だけ、最初の音をのぞみ終着チャイムにする。
        static let useTokyoDownboundNozomiChime = true

        /// 発車後案内。コード末尾は「発車駅」を表す。
        /// uo=上り新大阪発、us=上り品川発、dt=下り東京発。
        static let departureAnnouncementTracks: [String: Int] = [
            // 山陽区間は進行方向によらず、発車駅ごとの共通音源を使う。
            "uh": 101, "dh": 101,
            "uc": 102, "dc": 102,
            "ur": 103, "dr": 103,
            "ua": 104, "da": 104,
            "ub": 105, "db": 105,

            "uo": 106, "uk": 107, "un": 108,
            "uy": 109, "us": 110, "ut": 111,
            "dt": 201, "ds": 202, "dy": 203,
            "dn": 204, "dk": 205, "do": 206
        ]

        /// 停車前案内。コード末尾は「次の停車駅」を表す。
        static let arrivalApproachTracks: [String: Int] = [
            // 山陽区間は進行方向によらず、停車駅ごとの共通音源を使う。
            "uh": 301, "dh": 301,
            "uc": 302, "dc": 302,
            "ur": 303, "dr": 303,
            "ua": 304, "da": 304,
            "ub": 305, "db": 305,

            "uo": 306, "uk": 307, "un": 308,
            "uy": 309, "us": 310, "ut": 311,
            "dt": 401, "ds": 402, "dy": 403,
            "dn": 404, "dk": 405, "do": 406
        ]

        /// 駅到着案内。駅をキーにして全IDをConfigから変更できる。
        static let stationArrivalTracks: [Station: Int] = [
            .tokyo: 501,
            .shinagawa: 502,
            .shinYokohama: 503,
            .nagoya: 504,
            .kyoto: 505,
            .shinOsaka: 506
        ]

        static func stationArrivalTrack(for station: Station) -> Int {
            stationArrivalTracks[station] ?? noAudioTrack
        }

        static func departureFirstTrack(
            direction: TravelDirection?,
            currentStation: Station?
        ) -> Int {
            switch currentStation {
            case .hakata, .kokura:
                return galaxyExpress999DepartureTrack
            case .hiroshima, .okayama, .shinKobe:
                return sanyoHikariDepartureTrack
            default:
                break
            }

            if useTokyoDownboundNozomiChime,
               direction == .downbound,
               currentStation == .tokyo {
                return tokyoDownboundDepartureFirstTrack
            }
            return defaultDepartureFirstTrack
        }

        // 音声停止指令から最初のPLAYを送るまでの待機
        static let stopCommandToFirstPlayDelay: TimeInterval = 0.0

        // 発車時は「乙女の祈り」が鳴り終わって1秒後にモーター加速を開始する。
        static let departureMotorStartDelayAfterOtomeFinished: TimeInterval = 1.0

        // 停車シーケンス時間は AppConfig.Stop に集約。旧参照名は互換用。
        static let stopPreDecelerationTargetDutyPermille = Stop.preDecelerationTargetDutyPermille
        static let stopPreDecelerationTargetSpeed = Stop.preDecelerationTargetSpeed
        static let stopPreDecelerationDuration = Stop.preDecelerationDuration
        static let stopChimeDelayAfterReaching180 = Stop.chimeDelayAfterReachingTarget
        static let stopFinalBrakeDelayAfterAnnouncement = Stop.finalBrakeDelayAfterAnnouncement
        static let stopStateDelayAfterZero = Stop.stoppedStateDelayAfterZero

        /// AUDIO,ERROR時に同じ曲を自動再送しない。誤放送防止のため既定値はfalse。
        static let automaticallyRetryFailedTrack = false
        /// 将来再試行を有効にした場合の最大追加試行回数。現在はfalseなので未使用。
        static let maximumAutomaticRetryCount = 0
        static let automaticRetryDelay: TimeInterval = 2.0

        // 発車操作: 発車ブザーFINISHEDから「乙女の祈り」を開始するまでの間隔。
        static let departureFirstToSecondMinimumDelay: TimeInterval = 1.0
        // 停車操作: チャイム終了後から車内放送開始まで。
        static let stopChimeToAnnouncementMinimumDelay = Stop.announcementDelayAfterChime

        // 400→700‰の第2加速段を開始した瞬間に、発車後チャイムを予約する。
        // 加速そのものは6秒のまま、チャイムは第2加速段開始から8秒後に開始する。
        static let postDepartureReservationDelayAfterSecondStageStart: TimeInterval = 8.0
        static let postDepartureQueueStartDelay: TimeInterval = 0.0
        static let postDepartureChimeToAnnouncementDelay: TimeInterval = 2.0

        // 手動連続再生
        static let manualQueueInterTrackDelay: TimeInterval = 0.0

        // エラー回復と表示
        static let stopFailureRecoveryDelay = Stop.failureRecoveryDelay
        static let stopDisplayBlankingDelay = Stop.displayBlankingDelay

        // 互換名
        static let departureSecondDelay = departureFirstToSecondMinimumDelay
        static let stopSecondDelay = stopChimeToAnnouncementMinimumDelay
        static let queueInterTrackSettling = postDepartureChimeToAnnouncementDelay

        // BUSY LOW最低継続時間
        static let shortTrackMinimumBusyMs = 250
        static let announcementMinimumBusyMs = 1000
        static let validTrackRange = 1...2999
        static let announcementTrackRange = 100...999

        static func minimumBusyDurationMs(for track: Int) -> Int {
            announcementTrackRange.contains(track)
                ? announcementMinimumBusyMs
                : shortTrackMinimumBusyMs
        }
    }

    enum Marquee {
        static let routeProgressDisplayToken = "__ROUTE_PROGRESS_DISPLAY__"
        static let baseScrollSpeed: CGFloat = 51
        static let dashboardSpeedMultiplier: CGFloat = 1.5
        static let measurementFontSize: CGFloat = 38
        static let maximumDisplayWidth: CGFloat = 520
        static let exitMargin: CGFloat = 96
    }

    enum Speedometer {
        static let calibration: [SpeedometerCalibrationPoint] = [
            .init(dutyPermille: Double(Motor.stopDutyPermille), gaugeProgress: 0, displaySpeed: 0),
            .init(dutyPermille: Double(Motor.dutyN), gaugeProgress: Double(Motor.gaugeStepN), displaySpeed: Double(Motor.displaySpeedN)),
            .init(dutyPermille: Double(Motor.dutyP1), gaugeProgress: Double(Motor.gaugeStepP1), displaySpeed: Double(Motor.displaySpeedP1)),
            .init(dutyPermille: Double(Motor.dutyP2), gaugeProgress: Double(Motor.gaugeStepP2), displaySpeed: Double(Motor.displaySpeedP2)),
            .init(dutyPermille: Double(Motor.dutyP3), gaugeProgress: Double(Motor.gaugeStepP3), displaySpeed: Double(Motor.displaySpeedP3)),
            .init(dutyPermille: Double(Motor.dutyP4), gaugeProgress: Double(Motor.gaugeStepP4), displaySpeed: Double(Motor.displaySpeedP4)),
            .init(dutyPermille: Double(Motor.dutyP5), gaugeProgress: Double(Motor.gaugeStepP5), displaySpeed: Double(Motor.displaySpeedP5)),
            .init(dutyPermille: Double(Motor.dutyP6), gaugeProgress: Double(Motor.gaugeStepP6), displaySpeed: Double(Motor.displaySpeedP6))
        ]
    }

    enum Voltage {
        static let warningMillivolts = 7000
    }
}
