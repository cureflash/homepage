import SwiftUI
import Foundation

extension ContentView {
    // MARK: - 状態
    
    var stations: [Station] {
        route.stations
    }
    
    var currentStation: Station? {
        route.currentStation
    }
    
    var nextStation: Station? {
        route.nextStation
    }
    
    var routeSectionText: String {
        // 発車ブザー開始後から発車後チャイム開始までは、方向幕上の現在地表示も消灯する。
        // 発車後チャイムのSTARTEDでwaitingフラグが解除され、駅間表示へ切り替わる。
        if operation.departureDisplayWaitingForPostDepartureChime {
            return ""
        }

        guard let currentStation else {
            return "行先を選択してください"
        }
        
        if routePhase == .stoppedAtStation {
            return "現在地：\(currentStation.title)駅"
        }
        
        if routePhase == .arrived {
            return "現在地：\(currentStation.title)駅"
        }
        
        if routePhase == .emergencyStopped {
            return "\(currentStation.title)  区間内停止"
        }
        
        guard let nextStation else {
            return "\(currentStation.title)  到着"
        }
        
        return "\(currentStation.title) >>> \(nextStation.title)"
    }
    
    var routeStatusText: String {
        guard let travelDirection else {
            return "未設定"
        }
        
        return "\(travelDirection.title) / \(routePhase.title)"
    }
    
    var fixedDisplayMessage: String? {
        switch stopSequence {
        case .reducingTo180, .holdingAnnouncement, .brakingToStop:
            if let nextStation {
                return "まもなく\(nextStation.title)"
            }
        case .none, .blankingDisplay, .completed:
            break
        }
        
        // 終着駅は到着表示を固定する。
        if routePhase == .arrived, let currentStation {
            return "\(currentStation.title)に到着"
        }
        
        // 設定した始発駅では列車種別と行先を固定表示する。
        if routePhase == .stoppedAtStation,
           vehicleState == .ready,
           let currentStation,
           currentStation == selectedOriginStation,
           let selectedService,
           let selectedDestination {
            return "この電車は\(selectedService.title)号 \(selectedDestination.title)行きです"
        }

        // 途中駅では停車中表示を固定する。
        if routePhase == .stoppedAtStation,
           vehicleState == .ready,
           let currentStation {
            return "\(currentStation.title)に停車中"
        }
        
        return nil
    }
    
    var isSequenceLocked: Bool {
        vehicleState == .departureSequence ||
        vehicleState == .stopSequence ||
        vehicleState == .coasting ||
        vehicleState == .arrivalAnnouncing ||
        vehicleState == .emergencyStopped ||
        vehicleState == .lowBatteryStopping ||
        vehicleState == .lowBatteryStopped
    }
    
    var canRequestDeparture: Bool {
        isAppOperationAvailable &&
        isRouteConfigured &&
        routePhase == .stoppedAtStation &&
        vehicleState == .ready &&
        !isSequenceLocked
    }
    
    var canRequestStop: Bool {
        isAppOperationAvailable &&
        isRouteConfigured &&
        routePhase == .running &&
        vehicleState == .running &&
        nextStation != nil &&
        !isSequenceLocked
    }

    var driverOperationStatusText: String {
        if let queued = operation.queuedDutyNotch {
            return "QUEUED \(queued.rawValue)"
        }

        if let pending = operation.pendingDutyNotch {
            return "PENDING \(pending.rawValue)"
        }

        if operation.driverCommandFeedbackIsError,
           !operation.driverCommandFeedback.isEmpty {
            return operation.driverCommandFeedback
        }

        return driveState.rawValue
    }

    var driverOperationStatusColor: Color {
        if operation.driverCommandFeedbackIsError {
            return .red
        }

        if operation.pendingDutyNotch != nil ||
            operation.queuedDutyNotch != nil {
            return .orange
        }

        return driveState.color
    }

    func isNotchSelected(_ notch: Notch) -> Bool {
        selectedNotch == notch
    }

    func isNotchPending(_ notch: Notch) -> Bool {
        operation.pendingDutyNotch == notch ||
        operation.queuedDutyNotch == notch
    }
    
    private var architectureFaultActive: Bool {
        driveState == .fault ||
        vehicleState == .emergencyStopped ||
        vehicleState == .lowBatteryStopped
    }

    private var architectureTransportState: ModuleState {
        if connectionCheckingActive {
            return .active
        }

        return isSimulatedOrPhysicalLinkReady ? .active : .offline
    }

    private var architectureDriveState: ModuleState {
        if architectureFaultActive {
            return .fault
        }

        guard isSimulatedOrPhysicalLinkReady else {
            return .offline
        }

        let drivePathIsActive =
            driveState == .progress ||
            driveState == .settling ||
            driveState == .stable ||
            driveState == .coasting ||
            vehicleState == .departureSequence ||
            vehicleState == .running ||
            vehicleState == .stopSequence ||
            vehicleState == .coasting ||
            vehicleState == .lowBatteryStopping

        return drivePathIsActive ? .active : .standby
    }

    private var architectureSensorState: ModuleState {
        if architectureFaultActive {
            return .fault
        }

        guard isSimulatedOrPhysicalLinkReady else {
            return .offline
        }

        let sensorPathIsActive =
            routePhase == .running ||
            routePhase == .approaching ||
            stopSequence.isActive ||
            vehicleState == .running ||
            vehicleState == .coasting

        return sensorPathIsActive ? .active : .standby
    }

    private var architectureADCState: ModuleState {
        if vehicleState == .lowBatteryStopping ||
            vehicleState == .lowBatteryStopped {
            return .fault
        }

        guard isSimulatedOrPhysicalLinkReady else {
            return .offline
        }

        return batteryVoltage == nil ? .standby : .active
    }

    private var architectureAudioState: ModuleState {
        guard isSimulatedOrPhysicalLinkReady || isDebugMode2 else {
            return .offline
        }

        let audioPathIsActive =
            audioQueue.isBusy ||
            vehicleState == .departureSequence ||
            vehicleState == .arrivalAnnouncing ||
            stopSequence == .holdingAnnouncement

        return audioPathIsActive ? .active : .standby
    }

    var modules: [ModuleInfo] {
        [
            ModuleInfo(name: "APP", state: .active),
            ModuleInfo(name: "BLE", state: architectureTransportState),
            ModuleInfo(name: "ESP32", state: architectureTransportState),
            ModuleInfo(name: "PWM", state: architectureDriveState),
            ModuleInfo(name: "DRIVER", state: architectureDriveState),
            ModuleInfo(name: "MOTOR", state: architectureDriveState),
            ModuleInfo(name: "SENSOR", state: architectureSensorState),
            ModuleInfo(name: "ADC", state: architectureADCState),
            ModuleInfo(name: "AUDIO", state: architectureAudioState),
            ModuleInfo(name: "SPEAKER", state: architectureAudioState)
        ]
    }

    func moduleState(_ name: String) -> ModuleState {
        modules.first(where: { $0.name == name })?.state ?? .offline
    }

    /// 二つのモジュール間の接続線を、両端の状態から決める。
    func architectureLinkState(
        _ firstModule: String,
        _ secondModule: String
    ) -> ModuleState {
        let first = moduleState(firstModule)
        let second = moduleState(secondModule)

        if first == .fault || second == .fault {
            return .fault
        }

        if first == .offline || second == .offline {
            return .offline
        }

        if first == .active && second == .active {
            return .active
        }

        return .standby
    }

    // MARK: - 種別・行先選択
    
    func selectTrainService(_ service: TrainService) {
        guard !routeDisplayUpdatePending else { return }
        
        updateRouteDisplayAfterSelection {
            selectedService = service
            if let destination = selectedDestination {
                // A service change during running is a fresh route configuration,
                // so the dashboard always returns to the origin/ready state.
                initializeRoute(destination: destination)
                lastMessage = "DISPLAY SET : \(service.code) / \(destination.code) / ROUTE RESET"
            } else {
                lastMessage = "DISPLAY SET : \(service.code) / DESTINATION WAIT"
            }
        }
    }
    
    func selectDestination(_ destination: Destination) {
        guard !routeDisplayUpdatePending else { return }
        
        updateRouteDisplayAfterSelection {
            selectedDestination = destination
            // Direction, origin, and ROUTE MAP switch as soon as a destination
            // is selected, whether or not the service has already been chosen.
            initializeRoute(destination: destination)
            if let service = selectedService {
                lastMessage = "DISPLAY SET : \(service.code) / \(destination.code) / ROUTE RESET"
            } else {
                lastMessage = "DISPLAY SET : SERVICE WAIT / \(destination.code) / ROUTE RESET"
            }
        }
    }
    
    func selectOriginStation(_ station: Station) {
        guard !routeDisplayUpdatePending else { return }

        route.setOriginStation(station)
        stopSequence = .none
        blankDisplayStartedAt = nil
        announcementStartedAt = nil
        clearMarqueePlayback()
        clearPreDepartureAnnouncement()
        lastSimulationTime = Date()

        if let destination = selectedDestination,
           station == destination.terminalStation {
            lastMessage = "ORIGIN REJECTED : START AND DESTINATION ARE SAME"
        } else {
            showPreDepartureAnnouncementIfReady()
            lastMessage = "ORIGIN SET : \(station.title)"
        }
    }

    /// 種別と行先が両方そろった時点で、確認音2000を通常の音声経路で再生する。
    func updateRouteDisplayAfterSelection(_ update: @escaping () -> Void) {
        routeDisplayUpdatePending = true
        
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            update()
        }
        routeDisplayUpdatePending = false
        
        guard selectedService != nil, selectedDestination != nil else { return }
        guard isAppOperationAvailable else { return }

        let runID = nextRunID()
        sendCommand(
            PlarailBLECommand.playAudio(
                runID: runID,
                track: AudioCatalog.hornTrack,
                minimumBusyDurationMs: AppConfig.Audio.shortTrackMinimumBusyMs
            )
        )
        lastMessage = "SEND : ROUTE CONFIRM AUDIO / TRACK \(AudioCatalog.hornTrack)"
    }
    
    func initializeRoute(destination: Destination) {
        route.configure(destination: destination, origin: selectedOriginStation)
        stopSequence = .none
        blankDisplayStartedAt = nil
        announcementStartedAt = nil
        clearMarqueePlayback()
        showPreDepartureAnnouncementIfReady()
        lastSimulationTime = Date()
        
        // A new service/destination is a fresh timetable. Abandon all local
        // sequence state so the origin can depart again without stale RUNNING or
        // STOP-SEQUENCE locks. This is app-state reset only; Debug Mode 2 follows
        // exactly the same transition while suppressing BLE writes.
        pendingNotchAfterDeparture = nil
        operation.postDepartureAudioReservedAt = nil
        operation.postDepartureAudioPendingRequestRunID = nil
        audioQueue.clear()
        clearOperationAudioSequence()
        selectedNotch = .n
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        targetSpeed = 0
        
        if isAppOperationAvailable {
            vehicleState = .ready
            driveState = .stop
        } else {
            vehicleState = .unknown
            driveState = .disconnected
        }
    }
    
    // MARK: - BLE接続・運行指令
    
    func connectionControlTapped() {
        if isDebugMode2 {
            disableDebugMode2()
            return
        }
        
        if bleManager.isLinkActive {
            lastMessage = "TX > BLE DISCONNECT REQUEST"
            pendingBLEPassword = nil
            bleManager.disconnect()
            return
        }
        
        // Ask for the password before starting a physical scan. This gives
        // debgumode2 a path that never activates BLE at all.
        pendingBLEPassword = nil
        showPasswordSheet = true
        lastMessage = "BLE : PASSWORD REQUIRED"
    }
    
    func submitBLEPassword(_ password: String) {
        let submittedPassword = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !submittedPassword.isEmpty else { return }
        
        if submittedPassword == Self.debugMode2Passcode ||
            submittedPassword == Self.legacyDebugMode2Passcode {
            enableDebugMode2()
            return
        }
        
        pendingBLEPassword = submittedPassword
        
        if bleManager.connectionPhase == .awaitingPassword {
            authenticatePendingBLEPasswordIfPossible()
            return
        }
        
        if !bleManager.isLinkActive {
            lastMessage = "BLE : SCAN FOR \(PlarailBLEUUID.peripheralLocalName)"
            bleManager.connect()
        } else {
            lastMessage = "BLE : WAITING FOR PASSWORD REQUEST"
        }
    }
    
    func authenticatePendingBLEPasswordIfPossible() {
        guard !isDebugMode2,
              let password = pendingBLEPassword,
              bleManager.connectionPhase == .awaitingPassword else {
            return
        }
        
        // Clear first so an AUTH,FAIL notification does not automatically
        // retry the same password indefinitely.
        pendingBLEPassword = nil
        bleManager.authenticate(password: password)
    }
    
    func cancelBLEPasswordEntry() {
        pendingBLEPassword = nil
        if bleManager.isLinkActive {
            bleManager.disconnect()
        }
        lastMessage = "BLE CONNECTION CANCELLED"
    }
    
    func enableDebugMode2() {
        DebugAudioPlayer.shared.stop()
        debugSimulationID = UUID()
        isDebugMode2 = true
        pendingBLEPassword = nil
        showPasswordSheet = false
        
        // Stop any physical link first. Commands still pass through the normal
        // app path, but Debug Mode 2 records TX and injects delayed simulated RX.
        bleManager.disconnect()
        connected = true
        batteryVoltage = 7.4
        vehicleState = .ready
        driveState = .stop
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        selectedNotch = .n
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        targetSpeed = 0
        lastMessage = "DEBUG MODE 2 ENABLED : SIMULATED LINK READY / TX-RX LOG ACTIVE"
    }
    
    /// BLE横のDEBUGボタン用。
    /// Debug Mode 2を有効化したあと、通常の種別・行先選択と同じ経路を通して
    /// 「のぞみ / 東京行き / 新大阪始発」を設定する。
    /// これにより確認用の警笛を鳴らし、走行シーン側も通常選択時と同じ
    /// 「駅なし -> 始発駅へ接近」の演出を開始する。
    /// BLE・ESP32向けの既存送信ロジック自体は変更しない。
    func enableQuickDebugMode2() {
        enableDebugMode2()

        // 既存の経路設定が残っていても、DEBUG押下を新しい選択イベントとして扱う。
        route.resetToManualMode()
        selectedOriginStation = .shinOsaka

        // 通常のUI選択関数を使う。種別選択時点では行先未設定なので無音、
        // 行先選択で両方がそろった瞬間に既存の確認警笛処理が1回だけ走る。
        selectTrainService(.nozomi)
        selectDestination(.tokyo)

        lastMessage = "DEBUG MODE 2 : NOZOMI / TOKYO / ORIGIN SHIN-OSAKA / INITIAL APPROACH"
    }

    func disableDebugMode2() {
        DebugAudioPlayer.shared.stop()
        debugSimulationID = UUID()
        isDebugMode2 = false
        pendingBLEPassword = nil
        connected = false
        batteryVoltage = nil
        vehicleState = .unknown
        driveState = .disconnected
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        selectedNotch = .n
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        targetSpeed = 0
        lastMessage = "DEBUG MODE 2 DISABLED"
    }
    
    func handleVehicleConnectionChecking(_ isChecking: Bool) {
        guard !isDebugMode2 else { return }
        
        if isChecking {
            connected = false
            driveState = .checking
            lastMessage = "RX < AUTH OK / 接続確認中"
            return
        }
        
        if bleManager.connectionPhase == .ready, driveState == .checking {
            driveState = .stop
            lastMessage = "RX < CONNECTION READY / CHECK COMPLETE"
        }
    }
    
    func handleBLEConnectionPhase(_ phase: PlarailBLEConnectionPhase) {
        // A disconnect callback can arrive just after Debug Mode 2 is enabled.
        // It must not overwrite the simulator state.
        guard !isDebugMode2 else { return }
        
        switch phase {
        case .idle:
            connected = false
            batteryVoltage = nil
            clearPendingDutyCommands(revertSelection: false)
            operation.pendingStopRunID = nil
            operation.pendingStopApproachTrack = nil
            operation.pendingStopArrivalTrack = nil
            driveState = .disconnected
            lastMessage = "BLE LINK OFFLINE"
            
        case .scanning:
            connected = false
            batteryVoltage = nil
            lastMessage = "BLE SEARCHING : \(PlarailBLEUUID.peripheralLocalName)"
            
        case .connecting:
            connected = false
            batteryVoltage = nil
            lastMessage = "BLE CONNECTING"
            
        case .discovering:
            connected = false
            batteryVoltage = nil
            lastMessage = "BLE DISCOVERING GATT"
            
        case .awaitingPassword:
            connected = false
            batteryVoltage = nil
            showPasswordSheet = true
            lastMessage = "BLE LINKED : PASSWORD REQUIRED"
            authenticatePendingBLEPasswordIfPossible()
            
        case .authenticating:
            lastMessage = bleManager.isVehicleConnectionChecking
            ? "TX > AUTH,******** / VEHICLE CHECKING"
            : "BLE AUTHENTICATING"
            
        case .awaitingReady:
            connected = false
            driveState = .checking
            lastMessage = "RX < AUTH OK / 接続確認中"
            
        case .ready:
            connected = true
            showPasswordSheet = false
            if driveState == .checking {
                driveState = .stop
            }
            lastMessage = "BLE READY : \(bleManager.peripheralName)"
            
        case .bluetoothUnavailable:
            connected = false
            batteryVoltage = nil
            clearPendingDutyCommands(revertSelection: false)
            operation.pendingStopRunID = nil
            operation.pendingStopApproachTrack = nil
            operation.pendingStopArrivalTrack = nil
            driveState = .disconnected
            bleErrorMessage = "iPadのBluetoothが利用できません。Bluetoothを有効にしてください。"
            showBLEErrorAlert = true
            
        case .failed(let message):
            connected = false
            batteryVoltage = nil
            clearPendingDutyCommands(revertSelection: false)
            operation.pendingStopRunID = nil
            operation.pendingStopApproachTrack = nil
            operation.pendingStopArrivalTrack = nil
            driveState = .disconnected
            bleErrorMessage = message
            showBLEErrorAlert = true
            lastMessage = "BLE ERROR : \(message)"
        }
    }
    
    func requireOperationalConnection(for operation: String) -> Bool {
        guard isAppOperationAvailable else {
            offlineOperationName = operation
            showOfflineOperationAlert = true
            lastMessage = "COMMAND REJECTED : BLE OFFLINE"
            return false
        }
        return true
    }
    
    func nextRunID() -> UInt16 {
        operation.nextRunID()
    }
    
    
    // MARK: - Command transport

    /// 実機ではBLE送信し、Debug Mode 2では同じTXログを残して疑似応答を生成する。
    func sendCommand(_ command: String) {
        guard isDebugMode2 else {
            bleManager.send(command)
            return
        }

        let sessionID = debugSimulationID
        bleManager.recordSimulatedTransmission(command)
        scheduleSimulatedMicrocontrollerResponse(
            for: command,
            sessionID: sessionID
        )
    }

    func scheduleSimulatedTelemetry(
        _ line: String,
        after delay: TimeInterval,
        sessionID: UUID
    ) {
        scheduleDebugAction(after: delay, sessionID: sessionID) {
            self.bleManager.receiveSimulatedTelemetry(line)
        }
    }

    /// Debug Mode 2では音声をTX時点でiPadから即時再生する。
    /// 疑似RXだけは従来どおり5秒遅らせる。
    func startDebugAudioPlayback(
        runID: UInt16,
        track: Int,
        sessionID: UUID,
        telemetryDelay: TimeInterval,
        localStarted: (() -> Void)? = nil,
        localCompletion: (() -> Void)? = nil
    ) {
        guard isDebugMode2, debugSimulationID == sessionID else { return }

        let fallbackDuration = AppConfig.Audio.announcementTrackRange.contains(track)
            ? AppConfig.Debug.simulatedAnnouncementDuration
            : AppConfig.Debug.simulatedShortAudioDuration
        let fallbackDurationMs = Int((fallbackDuration * 1000).rounded())

        scheduleSimulatedTelemetry(
            "AUDIO,\(runID),STARTED,\(track)",
            after: telemetryDelay,
            sessionID: sessionID
        )

        let started = DebugAudioPlayer.shared.play(
            track: track,
            onStarted: {
                guard self.isDebugMode2, self.debugSimulationID == sessionID else { return }
                localStarted?()
            },
            onFinished: { durationMs in
                guard self.isDebugMode2, self.debugSimulationID == sessionID else { return }
                localCompletion?()
                self.scheduleSimulatedTelemetry(
                    "AUDIO,\(runID),FINISHED,\(track),DURATION_MS,\(durationMs)",
                    after: telemetryDelay,
                    sessionID: sessionID
                )
            }
        )

        guard !started else { return }

        scheduleDebugAction(after: fallbackDuration, sessionID: sessionID) {
            localCompletion?()
            self.scheduleSimulatedTelemetry(
                "AUDIO,\(runID),FINISHED,\(track),DURATION_MS,\(fallbackDurationMs)",
                after: telemetryDelay,
                sessionID: sessionID
            )
        }
    }

    func startDebugAudioSequence(
        runID: UInt16,
        tracks: [Int],
        index: Int = 0,
        sessionID: UUID,
        telemetryDelay: TimeInterval
    ) {
        guard tracks.indices.contains(index) else { return }

        let currentTrack = tracks[index]
        startDebugAudioPlayback(
            runID: runID,
            track: currentTrack,
            sessionID: sessionID,
            telemetryDelay: telemetryDelay,
            localStarted: {
                self.handleDebugLocalAudioStarted(
                    runID: runID,
                    track: currentTrack,
                    sessionID: sessionID
                )
            },
            localCompletion: {
            let nextIndex = index + 1
            guard tracks.indices.contains(nextIndex) else { return }

            self.scheduleDebugAction(
                after: AppConfig.Audio.postDepartureChimeToAnnouncementDelay,
                sessionID: sessionID
            ) {
                self.startDebugAudioSequence(
                    runID: runID,
                    tracks: tracks,
                    index: nextIndex,
                    sessionID: sessionID,
                    telemetryDelay: telemetryDelay
                )
            }
        }
        )
    }

    /// Debug Mode 2ではiPad側の実音声開始を即時の動作基準にする。
    /// 疑似RXは5秒後に届くが、発車加速の1秒待ちは実音声の開始時刻から数える。
    func handleDebugLocalAudioStarted(runID: UInt16, track: Int, sessionID: UUID) {
        if operation.departureDisplayWaitingForPostDepartureChime,
           isRouteConfigured,
           track == postDepartureChimeTrack {
            operation.departureDisplayWaitingForPostDepartureChime = false
            startDepartureMarqueeSequence()
        }

        guard runID == operation.operationAudioRunID else { return }

        switch operation.operationAudioStage {
        case .departureFirstWaitingStart:
            guard track == operation.operationAudioFirstTrack else { return }
            operation.operationAudioStage = .departureFirstPlaying

        case .departureSecondWaitingStart:
            guard track == operation.operationAudioSecondTrack else { return }
            operation.operationAudioStage = .departureSecondPlaying

        case .stopFirstWaitingStart:
            guard track == operation.operationAudioFirstTrack else { return }
            operation.operationAudioStage = .stopFirstPlaying

        case .stopSecondWaitingStart:
            guard track == operation.operationAudioSecondTrack else { return }
            operation.operationAudioStage = .stopSecondPlaying
            stopSequence = operation.stopPreDecelerationCompleted ? .holdingAnnouncement : .reducingTo180
            announcementStartedAt = Date()

        default:
            break
        }
    }

    /// Debug Mode 2では実音声の終了を使って次の操作へ進める。
    /// 5秒遅れの疑似RXはログ・通常受信処理確認用として別に流す。
    func handleDebugLocalAudioFinished(runID: UInt16, track: Int) {
        if runID == operation.pendingATCAudioRunID,
           track == AudioCatalog.atcTrack {
            applyPendingNotchAfterATC(runID: runID)
            return
        }

        if runID == operation.operationAudioRunID {
            switch operation.operationAudioStage {
            case .departureFirstWaitingStart, .departureFirstPlaying:
                guard track == operation.operationAudioFirstTrack else { break }
                operation.operationAudioFirstFinished = true
                operation.operationAudioStage = .departureWaitingSecond
                operation.operationAudioSecondNotBefore = Date().addingTimeInterval(
                    AppConfig.Audio.departureFirstToSecondMinimumDelay
                )
                let sessionID = debugSimulationID
                scheduleDebugAction(
                    after: AppConfig.Audio.departureFirstToSecondMinimumDelay,
                    sessionID: sessionID
                ) {
                    self.updateOperationAudioSequence(now: Date())
                }
                return

            case .departureSecondWaitingStart, .departureSecondPlaying:
                guard track == operation.operationAudioSecondTrack else { break }
                let sessionID = debugSimulationID
                scheduleDebugAction(
                    after: AppConfig.Audio.departureMotorStartDelayAfterOtomeFinished,
                    sessionID: sessionID
                ) {
                    self.beginDepartureMotorAfterOtomeFinished(runID: runID)
                }
                return

            case .stopFirstWaitingStart, .stopFirstPlaying:
                guard track == operation.operationAudioFirstTrack else { break }
                continueStopSequenceAfterChime(runID: runID)
                return

            case .stopSecondWaitingStart, .stopSecondPlaying:
                guard track == operation.operationAudioSecondTrack else { break }
                beginStopProfileAfterAudio(runID: runID, audioFailed: false)
                return

            default:
                break
            }
        }

        if audioQueue.finish(runID: runID, track: track) {
            sendNextQueuedAudioIfPossible()
        }
    }

    /// マイコンからの最初の返答は、各TXから5秒後に受信したものとして処理する。
    func scheduleSimulatedMicrocontrollerResponse(
        for command: String,
        sessionID: UUID
    ) {
        let parts = command
            .split(separator: ",", omittingEmptySubsequences: false)
            .map(String.init)
        guard !parts.isEmpty else { return }

        let responseDelay = AppConfig.Debug.simulatedMicrocontrollerResponseDelay

        if parts.count >= 3,
           parts[0] == "AUDIO",
           parts[1] == "STOP" {
            DebugAudioPlayer.shared.stop()
            return
        }

        if parts.count >= 4,
           parts[0] == "AUDIO",
           parts[1] == "PLAY",
           let runID = UInt16(parts[2]),
           let track = Int(parts[3]) {
            startDebugAudioPlayback(
                runID: runID,
                track: track,
                sessionID: sessionID,
                telemetryDelay: responseDelay,
                localStarted: {
                    self.handleDebugLocalAudioStarted(
                        runID: runID,
                        track: track,
                        sessionID: sessionID
                    )
                },
                localCompletion: {
                    self.handleDebugLocalAudioFinished(runID: runID, track: track)
                }
            )
            return
        }

        if parts.count >= 5,
           parts[0] == "AUDIO",
           parts[1] == "POST_DEPARTURE",
           let runID = UInt16(parts[2]),
           let chimeTrack = Int(parts[3]),
           let announcementTrack = Int(parts[4]) {
            let tracks = [chimeTrack, announcementTrack].filter { $0 > 0 }

            startDebugAudioSequence(
                runID: runID,
                tracks: tracks,
                sessionID: sessionID,
                telemetryDelay: responseDelay
            )
            return
        }

        if parts.count >= 4,
           parts[0] == "MOTOR",
           parts[1] == "SET_DUTY",
           let runID = UInt16(parts[2]) {
            scheduleSimulatedTelemetry(
                "COMMAND,\(runID),RECEIVED,SET_DUTY",
                after: responseDelay,
                sessionID: sessionID
            )
            return
        }

        if parts.count >= 3,
           parts[0] == "COMMAND",
           let runID = UInt16(parts[1]),
           parts[2] == "EXECUTE" {
            let duty = operation.pendingDutyNotch?.dutyPermille
                ?? selectedNotch.dutyPermille
            let departureCommand = vehicleState == .departureSequence
            let currentDuty = speedometerPresentation(at: Date()).dutyPermille

            scheduleSimulatedTelemetry(
                "COMMAND,\(runID),APPLIED,SET_DUTY,\(duty)",
                after: responseDelay,
                sessionID: sessionID
            )

            if departureCommand {
                scheduleSimulatedTelemetry(
                    "STATE,\(runID),MOTOR,ACCELERATION,DUTY,0",
                    after: responseDelay + 0.05,
                    sessionID: sessionID
                )
                scheduleSimulatedTelemetry(
                    "STATE,\(runID),MOTOR,ACCELERATION,DUTY,\(Int(AppConfig.Motor.startupFirstDuty))",
                    after: responseDelay + AppConfig.Motor.startupFirstStageDuration,
                    sessionID: sessionID
                )

                let extraAcceleration = max(
                    0,
                    speedometerSlewDuration(
                        from: AppConfig.Motor.startupSecondDuty,
                        to: Double(duty)
                    )
                )
                let completedAt = responseDelay
                    + AppConfig.Motor.startupFirstStageDuration
                    + AppConfig.Motor.startupSecondStageDuration
                    + extraAcceleration

                scheduleSimulatedTelemetry(
                    "STATE,\(runID),MOTOR,STABLE,DUTY,\(duty)",
                    after: completedAt,
                    sessionID: sessionID
                )
                scheduleSimulatedTelemetry(
                    "STATE,\(runID),VEHICLE,RUNNING",
                    after: completedAt + 0.05,
                    sessionID: sessionID
                )
                let reached700At = responseDelay
                    + AppConfig.Motor.startupFirstStageDuration
                    + AppConfig.Motor.startupSecondStageDuration
                scheduleSimulatedTelemetry(
                    "REQUEST,\(runID),POST_DEPARTURE_AUDIO",
                    after: reached700At + 0.10,
                    sessionID: sessionID
                )
            } else {
                let transitionDuration = max(
                    0.05,
                    speedometerSlewDuration(
                        from: currentDuty,
                        to: Double(duty)
                    )
                )
                let motionState = duty < Int(currentDuty) ? "DECELERATE" : "ACCELERATION"

                scheduleSimulatedTelemetry(
                    "STATE,\(runID),MOTOR,\(motionState),DUTY,\(Int(currentDuty.rounded()))",
                    after: responseDelay + 0.05,
                    sessionID: sessionID
                )
                scheduleSimulatedTelemetry(
                    "STATE,\(runID),MOTOR,STABLE,DUTY,\(duty)",
                    after: responseDelay + transitionDuration,
                    sessionID: sessionID
                )
            }
            return
        }

        if parts.count >= 3,
           parts[0] == "MOTOR",
           parts[1] == "STOP_PROFILE",
           let runID = UInt16(parts[2]) {
            // 疑似RXは5秒後だが、iPad上の最終減速はTX時点から開始する。
            stopSequence = .brakingToStop
            driveState = .progress
            targetSpeed = 0
            startSpeedometerSlew(
                to: 0,
                durationOverride: AppConfig.Stop.finalBrakeDisplayDuration
            )

            scheduleSimulatedTelemetry(
                "COMMAND,\(runID),APPLIED,STOP_PROFILE",
                after: responseDelay,
                sessionID: sessionID
            )
            scheduleSimulatedTelemetry(
                "STATE,\(runID),MOTOR,DECELERATE,DUTY,\(Int(speedometerPresentation(at: Date()).dutyPermille.rounded()))",
                after: responseDelay + AppConfig.Stop.debugMotorTelemetryOffset,
                sessionID: sessionID
            )
            scheduleSimulatedTelemetry(
                "STATE,\(runID),MOTOR,STOPPED,DUTY,0",
                after: responseDelay + AppConfig.Stop.finalBrakeDisplayDuration,
                sessionID: sessionID
            )
            scheduleSimulatedTelemetry(
                "STATE,\(runID),VEHICLE,READY",
                after: responseDelay + AppConfig.Stop.finalBrakeDisplayDuration + AppConfig.Stop.debugVehicleReadyTelemetryOffset,
                sessionID: sessionID
            )
            return
        }

        if parts.count >= 3,
           parts[0] == "MOTOR",
           parts[1] == "EMERGENCY_STOP",
           let runID = UInt16(parts[2]) {
            scheduleSimulatedTelemetry(
                "STATE,\(runID),MOTOR,STOPPED,DUTY,0",
                after: responseDelay,
                sessionID: sessionID
            )
            scheduleSimulatedTelemetry(
                "STATE,\(runID),VEHICLE,EMERGENCY_STOPPED",
                after: responseDelay + 0.05,
                sessionID: sessionID
            )
            return
        }

        if parts.count >= 3,
           parts[0] == "MOTOR",
           parts[1] == "EMERGENCY_RESET",
           let runID = UInt16(parts[2]) {
            scheduleSimulatedTelemetry(
                "STATE,\(runID),VEHICLE,ALIGNING",
                after: responseDelay,
                sessionID: sessionID
            )
            scheduleSimulatedTelemetry(
                "STATE,\(runID),VEHICLE,READY",
                after: responseDelay + AppConfig.Debug.emergencyResetDuration,
                sessionID: sessionID
            )
            return
        }

        if parts.count >= 3,
           parts[0] == "STATE",
           parts[1] == "REQUEST",
           let runID = UInt16(parts[2]) {
            scheduleSimulatedTelemetry(
                "STATE,\(runID),VEHICLE,\(vehicleState.rawValue)",
                after: responseDelay,
                sessionID: sessionID
            )
        }
    }

    // MARK: - Legacy Debug Mode 2 app-only simulation
    
    func beginDebugSimulation() -> UUID {
        debugSimulation.beginSession()
    }
    
    func scheduleDebugAction(
        after delay: TimeInterval,
        sessionID: UUID,
        _ action: @escaping () -> Void
    ) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            guard self.isDebugMode2, self.debugSimulationID == sessionID else { return }
            action()
        }
    }
    
    func startDebugNotchSlew(
        to notch: Notch,
        sessionID: UUID,
        finalDriveState: DriveState
    ) {
        let currentDuty = speedometerPresentation(at: Date()).dutyPermille
        startSpeedometerSlew(to: Double(notch.dutyPermille))
        
        let duration = max(
            0.35,
            speedometerSlewDuration(from: currentDuty, to: Double(notch.dutyPermille))
        )
        
        scheduleDebugAction(after: duration, sessionID: sessionID) {
            self.driveState = finalDriveState
            self.lastMessage = "DEBUG MODE 2 : MOTOR \(finalDriveState.rawValue)"
        }
    }
    
    func debugRequestDeparture(requestedNotch: Notch) {
        if isRouteConfigured {
            guard canRequestDeparture else {
                lastMessage = "DEBUG MODE 2 : DEPARTURE REJECTED"
                return
            }
        } else {
            guard vehicleState == .ready, !isSequenceLocked else {
                lastMessage = "DEBUG MODE 2 : DEPARTURE REJECTED"
                return
            }
        }

        let sessionID = beginDebugSimulation()
        let runID = nextRunID()
        pendingNotchAfterDeparture = requestedNotch
        shouldQueuePostDepartureAnnouncement = isRouteConfigured
        audioQueue.clear()

        selectedNotch = requestedNotch
        // Keep the numerical speedometer at zero until the ESP32 reports
        // acceleration after the second audio has completed.
        targetSpeed = 0
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        vehicleState = .departureSequence
        driveState = .stable
        lastMessage = "DEBUG MODE 2 : BUZZER START / RUN \(runID)"
        resetSpeedometerSlew(to: 0)

        let secondAudioStart = AppConfig.Debug.simulatedShortAudioDuration
            + AppConfig.Audio.departureFirstToSecondMinimumDelay
        let motorStart = secondAudioStart
            + AppConfig.Debug.simulatedAnnouncementDuration
            + AppConfig.Audio.departureMotorStartDelayAfterOtomeFinished
        let startupSecondStageStart = motorStart + AppConfig.Motor.startupFirstStageDuration
        let startupCompleted = startupSecondStageStart + AppConfig.Motor.startupSecondStageDuration

        scheduleDebugAction(after: secondAudioStart, sessionID: sessionID) {
            self.lastMessage = "DEBUG MODE 2 : OTOME NO INORI START"
        }

        scheduleDebugAction(after: motorStart, sessionID: sessionID) {
            self.driveState = .progress
            self.startSpeedometerSlew(
                to: AppConfig.Motor.startupFirstDuty,
                durationOverride: AppConfig.Motor.startupFirstStageDuration
            )
        }

        scheduleDebugAction(after: startupSecondStageStart, sessionID: sessionID) {
            self.startSpeedometerSlew(
                to: AppConfig.Motor.startupSecondDuty,
                durationOverride: AppConfig.Motor.startupSecondStageDuration
            )
        }

        scheduleDebugAction(after: startupCompleted, sessionID: sessionID) {
            self.vehicleState = .running
            if self.isRouteConfigured {
                self.routePhase = .running
            }
            self.finishDebugDeparture(sessionID: sessionID)
        }
    }

    func finishDebugDeparture(sessionID: UUID) {
        if let requestedNotch = pendingNotchAfterDeparture {
            pendingNotchAfterDeparture = nil
            selectedNotch = requestedNotch
            targetSpeed = requestedNotch.targetSpeed
            startDebugNotchSlew(
                to: requestedNotch,
                sessionID: sessionID,
                finalDriveState: .stable
            )
        }
        
        if shouldQueuePostDepartureAnnouncement {
            shouldQueuePostDepartureAnnouncement = false
            queuePostDepartureAnnouncement()
        }
        
        lastMessage = "DEBUG MODE 2 : RUNNING / DUTY \(selectedNotch.dutyPermille)"
    }
    
    func debugSetPowerNotch(_ notch: Notch) {
        if notch != .n,
           isRouteConfigured,
           routePhase == .stoppedAtStation,
           vehicleState == .ready,
           !isSequenceLocked {
            debugRequestDeparture(requestedNotch: notch)
            return
        }
        
        guard !isSequenceLocked else {
            lastMessage = "DEBUG MODE 2 : COMMAND REJECTED / SEQUENCE ACTIVE"
            return
        }
        
        let sessionID = beginDebugSimulation()
        selectedNotch = notch
        targetSpeed = notch.targetSpeed
        driveState = notch == .n ? .coasting : .progress
        lastMessage = "DEBUG MODE 2 : SET_DUTY \(notch.dutyPermille)"
        
        startDebugNotchSlew(
            to: notch,
            sessionID: sessionID,
            finalDriveState: notch == .n ? .coasting : .stable
        )
    }
    
    func debugRequestStopAtNextStation() {
        guard canRequestStop, let nextStation else {
            lastMessage = "DEBUG MODE 2 : STOP REJECTED / ROUTE NOT READY"
            return
        }

        let sessionID = beginDebugSimulation()
        pendingArrivalStation = nextStation
        vehicleState = .stopSequence
        routePhase = .approaching
        driveState = .stable
        selectedNotch = .n
        targetSpeed = 0
        clearMarqueePlayback()
        stopSequence = .blankingDisplay
        blankDisplayStartedAt = Date()
        announcementStartedAt = nil
        let debugChimeTrack = selectedChimeTrack
        let debugAnnouncementTrack = route.arrivalApproachCode.flatMap {
            AudioCatalog.arrivalApproachTrack(routeCode: $0)
        } ?? AudioCatalog.noAudioTrack
        lastMessage = "DEBUG MODE 2 : CHIME \(debugChimeTrack) START"

        let announcementStart = AppConfig.Stop.announcementDelayAfterChime
        let brakingStart = announcementStart + AppConfig.Debug.simulatedAnnouncementDuration
        let stopCompleted = brakingStart + AppConfig.Stop.finalBrakeDisplayDuration

        scheduleDebugAction(
            after: AppConfig.Stop.displayBlankingDelay,
            sessionID: sessionID
        ) {
            self.stopSequence = .reducingTo180
        }

        scheduleDebugAction(after: announcementStart, sessionID: sessionID) {
            self.stopSequence = .holdingAnnouncement
            self.announcementStartedAt = Date()
            self.lastMessage = "DEBUG MODE 2 : ANNOUNCEMENT \(debugAnnouncementTrack) START"
        }

        scheduleDebugAction(after: brakingStart, sessionID: sessionID) {
            self.stopSequence = .brakingToStop
            self.driveState = .coasting
            self.startSpeedometerSlew(
                to: 0,
                durationOverride: AppConfig.Stop.finalBrakeDisplayDuration
            )
        }

        scheduleDebugAction(after: stopCompleted, sessionID: sessionID) {
            self.finishDebugStop(at: nextStation)
        }
    }

    func finishDebugStop(at station: Station) {
        currentSpeed = 0
        targetSpeed = 0
        selectedNotch = .n
        driveState = .stop
        vehicleState = .ready
        stopSequence = .none
        blankDisplayStartedAt = nil
        announcementStartedAt = nil
        pendingArrivalStation = nil
        
        if let terminalStation = selectedDestination?.terminalStation,
           station == terminalStation {
            routePhase = .arrived
            terminalArrivalStationName = station.title
            resetRouteToManualMode()
            showTerminalArrivalAlert = true
            lastMessage = "DEBUG MODE 2 : TERMINAL ARRIVED / \(station.title)"
            return
        }
        
        if let currentStationIndex,
           let travelDirection {
            self.currentStationIndex = currentStationIndex + travelDirection.step
        }
        
        routePhase = .stoppedAtStation
        showPreDepartureAnnouncementIfReady()
        lastMessage = "DEBUG MODE 2 : ARRIVED / \(station.title)"
    }
    
    func debugEmergencyStop() {
        _ = beginDebugSimulation()
        audioQueue.clear()
        shouldQueuePostDepartureAnnouncement = false
        pendingNotchAfterDeparture = nil
        pendingArrivalStation = nil
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        selectedNotch = .n
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        targetSpeed = 0
        driveState = .fault
        vehicleState = .emergencyStopped
        routePhase = .emergencyStopped
        stopSequence = .none
        clearMarqueePlayback()
        lastMessage = "DEBUG MODE 2 : EMERGENCY STOP"
    }
    
    func debugEmergencyReset() {
        guard vehicleState == .emergencyStopped else { return }
        let sessionID = beginDebugSimulation()
        clearRouteAfterEmergencyRecovery()
        vehicleState = .aligning
        driveState = .checking
        lastMessage = "DEBUG MODE 2 : EMERGENCY RESET / ESC ALIGNING"
        
        scheduleDebugAction(after: AppConfig.Debug.emergencyResetDuration, sessionID: sessionID) {
            self.vehicleState = .ready
            self.driveState = .stop
            self.lastMessage = "DEBUG MODE 2 : EMERGENCY RESET COMPLETE / READY"
        }
    }
    
    func clearPendingDutyCommands(revertSelection: Bool) {
        operation.pendingDutyRunID = nil
        operation.pendingDutyNotch = nil
        operation.queuedDutyNotch = nil

        if revertSelection {
            selectedNotch = operation.confirmedNotch
            targetSpeed = operation.confirmedNotch.targetSpeed
        }
    }

    func beginNotchChangeAfterATC(_ notch: Notch) {
        guard operation.pendingATCAudioRunID == nil else {
            operation.driverCommandFeedback = "ATC BUSY"
            return
        }

        let runID = nextRunID()
        operation.pendingATCAudioRunID = runID
        operation.pendingATCNotch = notch
        operation.driverCommandFeedback = "ATC \(notch.rawValue)"
        operation.driverCommandFeedbackIsError = false

        sendCommand(
            PlarailBLECommand.playAudio(
                runID: runID,
                track: AudioCatalog.atcTrack,
                minimumBusyDurationMs: AppConfig.Audio.shortTrackMinimumBusyMs
            )
        )
        lastMessage = "SEND : ATC / TRACK \(AudioCatalog.atcTrack) / THEN \(notch.rawValue)"
    }

    func applyPendingNotchAfterATC(runID: UInt16) {
        guard runID == operation.pendingATCAudioRunID,
              let notch = operation.pendingATCNotch else { return }

        operation.pendingATCAudioRunID = nil
        operation.pendingATCNotch = nil
        driveState = notch == .n ? .coasting : .progress
        targetSpeed = notch.targetSpeed

        // Debug Mode 2では疑似マイコン応答を5秒待たず、ATC終了直後から表示を動かす。
        if isDebugMode2 {
            startSpeedometerSlew(to: Double(notch.dutyPermille))
        }

        sendDutyCommand(notch)
        lastMessage = "ATC FINISHED : MOTOR,SET_DUTY,\(notch.dutyPermille)"
    }

    func startStopChimeImmediately(
        runID: UInt16,
        chimeTrack: Int
    ) {
        guard operation.pendingStopRunID == runID,
              vehicleState == .stopSequence,
              operation.operationAudioStage == .stopFirstWaitingStart else {
            return
        }

        sendCommand(
            PlarailBLECommand.playAudio(
                runID: runID,
                track: chimeTrack,
                minimumBusyDurationMs: AppConfig.Audio.minimumBusyDurationMs(
                    for: chimeTrack
                )
            )
        )
        lastMessage = "SEND : STOP CHIME / TRACK \(chimeTrack)"
    }

    /// 停車チャイム終了後に予備減速を開始する。
    /// 180km/h以下なら予備減速を省略し、そのまま車内放送へ進む。
    func continueStopSequenceAfterChime(runID: UInt16) {
        guard operation.pendingStopRunID == runID,
              vehicleState == .stopSequence,
              operation.operationAudioFirstTrack != nil else {
            return
        }

        operation.operationAudioFirstFinished = true
        operation.operationAudioStage = .stopWaitingSecond

        let currentPresentation = speedometerPresentation(at: Date())
        let needsReduction =
            currentPresentation.displaySpeed > Double(AppConfig.Stop.preDecelerationTargetSpeed)

        // 180km/h以下なら予備減速は不要。従来どおりチャイム後すぐ放送へ進む。
        guard needsReduction else {
            operation.stopPreDecelerationCompleted = true
            operation.operationAudioSecondNotBefore = Date().addingTimeInterval(
                AppConfig.Stop.announcementDelayAfterChime
            )
            DispatchQueue.main.asyncAfter(
                deadline: .now() + AppConfig.Stop.announcementDelayAfterChime
            ) {
                self.updateOperationAudioSequence(now: Date())
            }
            return
        }

        // チャイム終了後の既存待ち時間を維持し、その後に
        // 「180km/hへの減速」と「車内放送」を同時開始する。
        operation.stopPreDecelerationCompleted = false
        operation.operationAudioSecondNotBefore = nil
        DispatchQueue.main.asyncAfter(
            deadline: .now() + AppConfig.Stop.preDecelerationDelayAfterChime
        ) {
            guard self.operation.pendingStopRunID == runID,
                  self.vehicleState == .stopSequence,
                  self.operation.operationAudioStage == .stopWaitingSecond else {
                return
            }

            self.stopSequence = .reducingTo180
            self.driveState = .progress
            self.targetSpeed = Double(AppConfig.Stop.preDecelerationTargetSpeed)
            self.startSpeedometerSlew(
                to: Double(AppConfig.Stop.preDecelerationTargetDutyPermille),
                durationOverride: AppConfig.Stop.preDecelerationDuration
            )

            // 減速開始と同じタイミングで2曲目(車内放送)を送る。
            self.operation.operationAudioSecondNotBefore = Date()
            self.updateOperationAudioSequence(now: Date())
            self.lastMessage =
                "STOP PRE-DECEL + ANNOUNCEMENT : TO \(AppConfig.Stop.preDecelerationTargetSpeed)km/h"

            DispatchQueue.main.asyncAfter(
                deadline: .now() + AppConfig.Stop.preDecelerationDuration
            ) {
                guard self.operation.pendingStopRunID == runID,
                      self.vehicleState == .stopSequence else {
                    return
                }

                self.operation.stopPreDecelerationCompleted = true
                self.driveState = .stable
                self.targetSpeed = Double(AppConfig.Stop.preDecelerationTargetSpeed)

                // 放送がまだ流れているなら、その終了を待つ。
                // 先に放送が終わっていた場合はここから最終減速待ちへ進む。
                if self.operation.operationAudioStage == .stopWaitingBrake {
                    self.scheduleFinalBrakeWhenStopAudioAndPreDecelReady(runID: runID)
                } else if self.operation.operationAudioStage == .stopSecondPlaying ||
                            self.operation.operationAudioStage == .stopSecondWaitingStart {
                    self.stopSequence = .holdingAnnouncement
                }
            }
        }
    }

    func markStopZeroReached(runID: UInt16) {
        guard operation.pendingStopRunID == runID,
              pendingArrivalStation != nil else { return }
        guard operation.stopZeroReachedAt == nil else { return }

        operation.stopZeroReachedAt = Date()
        currentSpeed = 0
        targetSpeed = 0
        driveState = .stop

        DispatchQueue.main.asyncAfter(
            deadline: .now() + AppConfig.Stop.stoppedStateDelayAfterZero
        ) {
            guard self.operation.pendingStopRunID == runID,
                  self.operation.stopZeroReachedAt != nil,
                  self.pendingArrivalStation != nil else {
                return
            }

            self.stopSequence = .completed
            self.handleVehicleTelemetry(runID: runID, state: VehicleControllerState.ready.rawValue)
        }
    }

    func sendDutyCommand(_ notch: Notch, runID suppliedRunID: UInt16? = nil) {
        guard operation.pendingDutyRunID == nil else {
            operation.queuedDutyNotch = notch
            operation.driverCommandFeedback = "QUEUED \(notch.rawValue)"
            operation.driverCommandFeedbackIsError = false
            lastMessage = "QUEUE : MOTOR,SET_DUTY,\(notch.dutyPermille)"
            return
        }

        let runID = suppliedRunID ?? nextRunID()
        if let suppliedRunID {
            activeRunID = suppliedRunID
        }
        operation.pendingDutyRunID = runID
        operation.pendingDutyNotch = notch
        operation.driverCommandFeedback = "PENDING \(notch.rawValue)"
        operation.driverCommandFeedbackIsError = false

        sendCommand(
            PlarailBLECommand.setDuty(
                runID: runID,
                dutyPermille: notch.dutyPermille
            )
        )
        lastMessage = "SEND : MOTOR,SET_DUTY,\(runID),\(notch.dutyPermille)"
    }

    func sendLatestQueuedDutyIfNeeded(appliedDuty: Int) {
        guard let queued = operation.queuedDutyNotch else { return }
        operation.queuedDutyNotch = nil

        guard queued.dutyPermille != appliedDuty else {
            selectedNotch = queued
            return
        }

        DispatchQueue.main.async {
            self.sendDutyCommand(queued)
        }
    }

    func rejectPendingDutyCommand(runID: UInt16, reason: String) {
        guard operation.pendingDutyRunID == runID else { return }

        clearPendingDutyCommands(revertSelection: true)
        operation.driverCommandFeedback = "REJECTED"
        operation.driverCommandFeedbackIsError = true
        lastMessage = "SET_DUTY REJECTED : \(reason)"
    }

    func requestDeparture(requestedNotch: Notch) {
        guard requireOperationalConnection(for: "発車") else { return }

        if isRouteConfigured {
            guard canRequestDeparture else {
                lastMessage = "DEPARTURE REJECTED : VEHICLE NOT READY"
                return
            }
        } else {
            guard vehicleState == .ready, !isSequenceLocked else {
                lastMessage = "DEPARTURE REJECTED : VEHICLE NOT READY"
                return
            }
        }

        beginAppDrivenDeparture(requestedNotch: requestedNotch)
    }

    func beginAppDrivenDeparture(requestedNotch: Notch) {
        // 前の手動音声・接続音を先に停止し、別runIDで新しい発車処理を開始する。
        let cancelRunID = nextRunID()
        sendCommand(PlarailBLECommand.stopAudio(runID: cancelRunID))

        let runID = nextRunID()
        let firstTrack = AppConfig.Audio.departureFirstTrack(
            direction: travelDirection,
            currentStation: currentStation
        )
        let secondTrack = AudioCatalog.otomeNoInoriTrack

        audioQueue.clear()
        clearOperationAudioSequence()
        pendingNotchAfterDeparture = requestedNotch
        shouldQueuePostDepartureAnnouncement = isRouteConfigured
        operation.postDepartureAudioReservedAt = nil
        operation.postDepartureAudioPendingRequestRunID = nil
        clearPendingDutyCommands(revertSelection: false)

        selectedNotch = requestedNotch
        // 乙女の祈りのFINISHED後にSET_DUTYを送るまで速度計は0のまま。
        targetSpeed = 0
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        vehicleState = .departureSequence
        driveState = .stable
        operation.driverCommandFeedback = ""
        operation.driverCommandFeedbackIsError = false
        operation.departureDisplayWaitingForPostDepartureChime = isRouteConfigured
        clearMarqueePlayback()
        clearPreDepartureAnnouncement()

        operation.operationAudioRunID = runID
        operation.operationAudioFirstTrack = firstTrack
        operation.operationAudioSecondTrack = secondTrack
        operation.operationAudioStage = .departureFirstWaitingStart
        operation.operationAudioFirstFinished = false
        operation.operationAudioSecondNotBefore = nil

        DispatchQueue.main.asyncAfter(
            deadline: .now() + AppConfig.Audio.stopCommandToFirstPlayDelay
        ) {
            guard self.operation.operationAudioRunID == runID,
                  self.operation.operationAudioStage == .departureFirstWaitingStart else {
                return
            }

            self.sendCommand(
                PlarailBLECommand.playAudio(
                    runID: runID,
                    track: firstTrack,
                    minimumBusyDurationMs: AppConfig.Audio.minimumBusyDurationMs(
                        for: firstTrack
                    )
                )
            )
            self.lastMessage = "SEND : DEPARTURE FIRST AUDIO / TRACK \(firstTrack)"
        }
    }

    func setPowerNotch(_ notch: Notch) {
        guard requireOperationalConnection(for: "ノッチ操作") else { return }
        
        // 運行モードで駅停車中に力行ノッチを入れたら、発車操作として扱う。
        if notch != .n,
           isRouteConfigured,
           routePhase == .stoppedAtStation,
           vehicleState == .ready,
           !isSequenceLocked {
            requestDeparture(requestedNotch: notch)
            return
        }
        
        guard !isSequenceLocked else {
            lastMessage = "COMMAND REJECTED : SEQUENCE ACTIVE"
            return
        }
        
        // 通常の速度変更はATC確認音を先に鳴らし、終了直後にSET_DUTYを送る。
        selectedNotch = notch
        targetSpeed = notch.targetSpeed
        operation.driverCommandFeedbackIsError = false
        beginNotchChangeAfterATC(notch)
    }
    
    func selectNeutral() {
        setPowerNotch(.n)
    }
    
    func requestStopAtNextStation() {
        guard requireOperationalConnection(for: "停車") else { return }
        guard canRequestStop, let nextStation else {
            lastMessage = "STOP REQUEST REJECTED : ROUTE NOT READY"
            return
        }

        guard let approachCode = route.arrivalApproachCode,
              let approachTrack = AudioCatalog.arrivalApproachTrack(
                routeCode: approachCode
              ) else {
            lastMessage = "STOP REQUEST REJECTED : ROUTE AUDIO NOT FOUND"
            return
        }

        let stopRequestPresentation = speedometerPresentation(at: Date())

        let cancelRunID = nextRunID()
        sendCommand(PlarailBLECommand.stopAudio(runID: cancelRunID))

        let runID = nextRunID()
        let stopChimeTrack = selectedChimeTrack

        audioQueue.clear()
        clearOperationAudioSequence()
        clearPendingDutyCommands(revertSelection: false)

        operation.pendingStopRunID = runID
        operation.pendingStopApproachTrack = approachTrack
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.stopPreDecelerationCompleted = false
        operation.stopAnnouncementFailed = false
        operation.driverCommandFeedback = ""
        operation.driverCommandFeedbackIsError = false
        pendingArrivalStation = nextStation
        vehicleState = .stopSequence
        routePhase = .approaching
        driveState = .stable
        selectedNotch = .n
        targetSpeed = stopRequestPresentation.displaySpeed

        stopSequence = .blankingDisplay
        blankDisplayStartedAt = Date()
        announcementStartedAt = nil
        clearMarqueePlayback()

        operation.operationAudioRunID = runID
        operation.operationAudioFirstTrack = stopChimeTrack
        operation.operationAudioSecondTrack = approachTrack
        operation.operationAudioStage = .stopFirstWaitingStart
        operation.operationAudioFirstFinished = false
        operation.operationAudioSecondNotBefore = nil

        startStopChimeImmediately(
            runID: runID,
            chimeTrack: stopChimeTrack
        )
    }

    func finishDepartureAfterMotorStarted() {
        // P3=700‰ならここで発車加速完了。P4以上はESP32が700‰到達後も
        // 追加加速するため、最終STABLE通知まで要求ノッチを保持する。
        if pendingNotchAfterDeparture?.dutyPermille ?? 0 <=
            Int(AppConfig.Motor.startupSecondDuty) {
            pendingNotchAfterDeparture = nil
        }
        clearOperationAudioSequence()

        // 実機の発車後音声は、ESP32が700‰到達時に送る
        // REQUEST,<runID>,POST_DEPARTURE_AUDIO を起点にする。
        // ここではキューを開始せず、要求受信まで音声IDを保持する。
    }

    /// 400→700‰の第2加速段が始まった瞬間に呼び、8秒後の発車後音声を予約する。
    func reservePostDepartureAudio(runID: UInt16) {
        guard runID == activeRunID, shouldQueuePostDepartureAnnouncement else { return }

        let due = Date().addingTimeInterval(
            AppConfig.Audio.postDepartureReservationDelayAfterSecondStageStart
        )
        operation.postDepartureAudioReservedAt = due
        operation.postDepartureAudioPendingRequestRunID = nil

        DispatchQueue.main.asyncAfter(
            deadline: .now() + AppConfig.Audio.postDepartureReservationDelayAfterSecondStageStart
        ) {
            guard self.activeRunID == runID,
                  self.shouldQueuePostDepartureAnnouncement,
                  self.operation.postDepartureAudioReservedAt == due else {
                return
            }

            // ESP32の700‰到達REQUESTが既に来ていれば、予約時刻ちょうどに返答する。
            if self.operation.postDepartureAudioPendingRequestRunID == runID {
                self.sendPostDepartureAudioNow(runID: runID)
            } else {
                self.lastMessage = "POST-DEPARTURE AUDIO TIMER READY / WAIT REQUEST / RUN \(runID)"
            }
        }
    }

    func respondToPostDepartureAudioRequest(runID: UInt16) {
        // 古い発車処理の遅延REQUESTで現在の経路音声を返さない。
        guard runID == activeRunID else {
            sendCommand(
                PlarailBLECommand.postDepartureAudio(
                    runID: runID,
                    chimeTrack: AppConfig.Audio.noAudioTrack,
                    announcementTrack: AppConfig.Audio.noAudioTrack
                )
            )
            lastMessage = "TX > STALE POST_DEPARTURE REQUEST / RUN \(runID) / NO AUDIO"
            return
        }

        guard shouldQueuePostDepartureAnnouncement else {
            sendCommand(
                PlarailBLECommand.postDepartureAudio(
                    runID: runID,
                    chimeTrack: AppConfig.Audio.noAudioTrack,
                    announcementTrack: AppConfig.Audio.noAudioTrack
                )
            )
            return
        }

        // 700‰到達REQUESTが8秒予約より先に来た場合は、runIDだけ保持して待つ。
        if let reservedAt = operation.postDepartureAudioReservedAt, Date() < reservedAt {
            operation.postDepartureAudioPendingRequestRunID = runID
            let remain = max(0, reservedAt.timeIntervalSinceNow)
            lastMessage = String(format: "RX < POST_DEPARTURE REQUEST / RESERVED %.1fs", remain)
            return
        }

        sendPostDepartureAudioNow(runID: runID)
    }

    func sendPostDepartureAudioNow(runID: UInt16) {
        guard runID == activeRunID else { return }

        guard shouldQueuePostDepartureAnnouncement,
              isRouteConfigured,
              let departureCode = route.departureAnnouncementCode,
              let departureTrack = AudioCatalog.departureAnnouncementTrack(
                routeCode: departureCode
              ) else {
            shouldQueuePostDepartureAnnouncement = false
            operation.postDepartureAudioReservedAt = nil
            operation.postDepartureAudioPendingRequestRunID = nil
            sendCommand(
                PlarailBLECommand.postDepartureAudio(
                    runID: runID,
                    chimeTrack: AppConfig.Audio.noAudioTrack,
                    announcementTrack: AppConfig.Audio.noAudioTrack
                )
            )
            lastMessage = "TX > AUDIO,POST_DEPARTURE,\(runID),0,0"
            return
        }

        let chimeTrack = postDepartureChimeTrack
        shouldQueuePostDepartureAnnouncement = false
        operation.postDepartureAudioReservedAt = nil
        operation.postDepartureAudioPendingRequestRunID = nil
        sendCommand(
            PlarailBLECommand.postDepartureAudio(
                runID: runID,
                chimeTrack: chimeTrack,
                announcementTrack: departureTrack
            )
        )
        lastMessage = "TX > AUDIO,POST_DEPARTURE,\(runID),\(chimeTrack),\(departureTrack)"
    }

    func clearOperationAudioSequence() {
        operation.operationAudioStage = .none
        operation.operationAudioRunID = nil
        operation.operationAudioFirstTrack = nil
        operation.operationAudioSecondTrack = nil
        operation.operationAudioSecondNotBefore = nil
        operation.operationAudioFirstFinished = false
    }

    func updateOperationAudioSequence(now: Date) {
        guard let runID = operation.operationAudioRunID,
              let secondTrack = operation.operationAudioSecondTrack,
              operation.operationAudioFirstFinished,
              let notBefore = operation.operationAudioSecondNotBefore,
              now >= notBefore else {
            return
        }

        switch operation.operationAudioStage {
        case .departureWaitingSecond:
            operation.operationAudioStage = .departureSecondWaitingStart
        case .stopWaitingSecond:
            operation.operationAudioStage = .stopSecondWaitingStart
        default:
            return
        }

        // ESP32側でもConfig::Audio::INTER_TRACK_GAP_MSのアイドル時間を確保する。
        // 2曲目はAppConfig.Audioの最低BUSY時間未満ならTOO_SHORTになる。
        sendCommand(
            PlarailBLECommand.playAudio(
                runID: runID,
                track: secondTrack,
                minimumBusyDurationMs: AppConfig.Audio.announcementMinimumBusyMs
            )
        )
        lastMessage = "SEND : SECOND AUDIO / TRACK \(secondTrack) / MIN_BUSY_MS \(AppConfig.Audio.announcementMinimumBusyMs)"
    }

    func beginDepartureMotorAfterOtomeFinished(runID: UInt16) {
        guard operation.operationAudioStage == .departureSecondPlaying,
              let requestedNotch = pendingNotchAfterDeparture else {
            return
        }

        operation.operationAudioStage = .departureWaitingMotor
        targetSpeed = requestedNotch.targetSpeed
        driveState = .progress

        // Debug Mode 2では疑似RXを待たず、乙女の祈りFINISHEDから1秒後に
        // iPad上の速度計も実際に加速させる。
        if isDebugMode2 {
            let sessionID = debugSimulationID
            resetSpeedometerSlew(to: 0)
            startSpeedometerSlew(
                to: AppConfig.Motor.startupFirstDuty,
                durationOverride: AppConfig.Motor.startupFirstStageDuration
            )

            scheduleDebugAction(
                after: AppConfig.Motor.startupFirstStageDuration,
                sessionID: sessionID
            ) {
                self.startSpeedometerSlew(
                    to: AppConfig.Motor.startupSecondDuty,
                    durationOverride: AppConfig.Motor.startupSecondStageDuration
                )
                self.reservePostDepartureAudio(runID: runID)
            }

            if requestedNotch.dutyPermille > Int(AppConfig.Motor.startupSecondDuty) {
                scheduleDebugAction(
                    after: AppConfig.Motor.startupFirstStageDuration +
                        AppConfig.Motor.startupSecondStageDuration,
                    sessionID: sessionID
                ) {
                    self.startSpeedometerSlew(to: Double(requestedNotch.dutyPermille))
                }
            }
        } else {
            // 実機も、SET_DUTY送信から0→400‰の0.5秒が終わった時点を
            // 400→700‰開始とみなし、そこから8秒後に発車後音声を予約する。
            DispatchQueue.main.asyncAfter(
                deadline: .now() + AppConfig.Motor.startupFirstStageDuration
            ) {
                guard self.activeRunID == runID,
                      self.shouldQueuePostDepartureAnnouncement else { return }
                self.reservePostDepartureAudio(runID: runID)
            }
        }

        sendDutyCommand(requestedNotch, runID: runID)
        lastMessage = "SEND : DEPARTURE MOTOR / OTOME FINISH +1.0s / DUTY \(requestedNotch.dutyPermille)"
    }

    func beginStopProfileAfterAudio(runID: UInt16, audioFailed: Bool) {
        guard operation.operationAudioStage == .stopSecondPlaying ||
                operation.operationAudioStage == .stopSecondWaitingStart else {
            return
        }

        operation.operationAudioStage = .stopWaitingBrake
        operation.stopAnnouncementFailed = audioFailed
        lastMessage = audioFailed
            ? "WAIT : STOP PROFILE / AUDIO ERROR"
            : "WAIT : STOP PROFILE / ANNOUNCEMENT FINISHED"

        // 車内放送が予備減速より先に終わった場合は、減速完了まで待つ。
        // 予備減速が無い/既に完了していれば従来どおり最終減速へ進む。
        scheduleFinalBrakeWhenStopAudioAndPreDecelReady(runID: runID)
    }

    func scheduleFinalBrakeWhenStopAudioAndPreDecelReady(runID: UInt16) {
        guard operation.operationAudioRunID == runID,
              operation.operationAudioStage == .stopWaitingBrake,
              vehicleState == .stopSequence,
              operation.stopPreDecelerationCompleted else {
            return
        }

        let audioFailed = operation.stopAnnouncementFailed
        DispatchQueue.main.asyncAfter(
            deadline: .now() + AppConfig.Stop.finalBrakeDelayAfterAnnouncement
        ) {
            guard self.operation.operationAudioRunID == runID,
                  self.operation.operationAudioStage == .stopWaitingBrake,
                  self.vehicleState == .stopSequence,
                  self.operation.stopPreDecelerationCompleted else {
                return
            }

            self.stopSequence = .brakingToStop
            self.driveState = .progress
            self.targetSpeed = 0
            self.startSpeedometerSlew(
                to: 0,
                durationOverride: AppConfig.Stop.finalBrakeDisplayDuration
            )
            DispatchQueue.main.asyncAfter(
                deadline: .now() + AppConfig.Stop.finalBrakeDisplayDuration
            ) {
                self.markStopZeroReached(runID: runID)
            }
            self.sendCommand(PlarailBLECommand.stopProfile(runID: runID))
            self.lastMessage = audioFailed
                ? "SEND : STOP_PROFILE / PRE-DECEL + AUDIO ERROR COMPLETE"
                : "SEND : STOP_PROFILE / PRE-DECEL + ANNOUNCEMENT COMPLETE"
        }
    }

    func abortDepartureAudioSequence(reason: String) {
        pendingNotchAfterDeparture = nil
        shouldQueuePostDepartureAnnouncement = false
        operation.postDepartureAudioReservedAt = nil
        operation.postDepartureAudioPendingRequestRunID = nil
        clearOperationAudioSequence()
        vehicleState = .ready
        routePhase = isRouteConfigured ? .stoppedAtStation : .unconfigured
        selectedNotch = .n
        operation.confirmedNotch = .n
        targetSpeed = 0
        driveState = .stop
        operation.driverCommandFeedback = "AUDIO ERROR"
        operation.driverCommandFeedbackIsError = true
        lastMessage = "DEPARTURE ABORTED : \(reason)"
    }

    func queuePostDepartureAnnouncement() {
        guard let currentStation else {
            lastMessage = "AUDIO QUEUE SKIPPED : DEPARTURE STATION NOT SET"
            return
        }

        guard let departureCode = route.departureAnnouncementCode,
              let departureTrack = AudioCatalog.departureAnnouncementTrack(
                routeCode: departureCode
              ) else {
            lastMessage = "AUDIO QUEUE SKIPPED : DEPARTURE AUDIO NOT FOUND"
            return
        }

        let runID = nextRunID()
        let chimeTrack = postDepartureChimeTrack
        audioQueue.start(
            runID: runID,
            tracks: [chimeTrack, departureTrack],
            firstTrackDelay: AppConfig.Audio.postDepartureQueueStartDelay,
            interTrackDelay: AppConfig.Audio.postDepartureChimeToAnnouncementDelay
        )
        sendNextQueuedAudioIfPossible()
        lastMessage = "AUDIO QUEUE : \(currentStation.title)発 / \(chimeTrack) -> \(departureTrack) / RUN \(runID)"
    }

    func sendNextQueuedAudioIfPossible() {
        guard isSimulatedOrPhysicalLinkReady,
              !isSequenceLocked,
              currentQueuedAudioTrack == nil,
              let runID = audioQueue.runID,
              let track = audioQueue.takeNextTrack(at: Date()) else {
            return
        }

        let minimumBusyMs = AppConfig.Audio.minimumBusyDurationMs(for: track)
        sendCommand(
            PlarailBLECommand.playAudio(
                runID: runID,
                track: track,
                minimumBusyDurationMs: minimumBusyMs
            )
        )
        lastMessage = "SEND : AUDIO,PLAY,\(runID),\(track),MIN_BUSY_MS,\(minimumBusyMs)"
    }

    func playManualAudioTrack(_ track: Int) {
        playManualAudioSequence([track])
    }

    func playManualAudioSequence(_ tracks: [Int]) {
        guard requireOperationalConnection(for: "音声再生") else { return }

        let validTracks = tracks.filter { AppConfig.Audio.validTrackRange.contains($0) }
        guard !validTracks.isEmpty else {
            lastMessage = "AUDIO REJECTED : TRACK ID MUST BE \(AppConfig.Audio.validTrackRange.lowerBound)...\(AppConfig.Audio.validTrackRange.upperBound)"
            return
        }

        guard !isSequenceLocked else {
            lastMessage = "AUDIO REJECTED : SEQUENCE ACTIVE"
            return
        }

        guard currentQueuedAudioTrack == nil,
              queuedAudioTracks.isEmpty else {
            lastMessage = "AUDIO REJECTED : AUDIO QUEUE BUSY"
            return
        }

        shouldQueuePostDepartureAnnouncement = false
        let runID = nextRunID()
        audioQueue.start(
            runID: runID,
            tracks: validTracks,
            interTrackDelay: AppConfig.Audio.manualQueueInterTrackDelay
        )
        sendNextQueuedAudioIfPossible()

        let joined = validTracks.map(String.init).joined(separator: ",")
        lastMessage = validTracks.count == 1
        ? "MANUAL AUDIO START : ID \(joined) / RUN \(runID)"
        : "MANUAL AUDIO SEQUENCE : [\(joined)] / RUN \(runID)"
    }

    func stopManualAudioPlayback() {
        guard requireOperationalConnection(for: "音声停止") else { return }

        guard !isSequenceLocked else {
            lastMessage = "AUDIO STOP REJECTED : SEQUENCE ACTIVE"
            return
        }

        audioQueue.clear()
        let runID = nextRunID()

        sendCommand(PlarailBLECommand.stopAudio(runID: runID))
        lastMessage = "SEND : AUDIO,STOP,\(runID)"
    }

    func sendSound(_ sound: String) {
        guard requireOperationalConnection(for: "警笛") else { return }
        
        guard !isSequenceLocked,
              !audioQueue.isBusy else {
            lastMessage = "AUDIO REJECTED : BUSY"
            return
        }
        
        guard sound == "HORN" else {
            // 任意音声の選択UIは未確定なので、ここでは送信しない。
            lastMessage = "AUDIO REJECTED : MANUAL AUDIO NOT CONFIGURED"
            return
        }
        
        sendCommand(
            PlarailBLECommand.playAudio(
                runID: activeRunID,
                track: AudioCatalog.hornTrack,
                minimumBusyDurationMs: AppConfig.Audio.shortTrackMinimumBusyMs
            )
        )
        lastMessage = "SEND : AUDIO,PLAY,\(activeRunID),\(AudioCatalog.hornTrack)"
    }
    
    func emergencyStop() {
        guard requireOperationalConnection(for: "非常停止") else { return }
        
        audioQueue.clear()
        shouldQueuePostDepartureAnnouncement = false
        pendingNotchAfterDeparture = nil
        pendingArrivalStation = nil
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        selectedNotch = .n
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        targetSpeed = 0
        driveState = .fault
        vehicleState = .emergencyStopped
        routePhase = .emergencyStopped
        stopSequence = .none
        clearMarqueePlayback()
        clearPreDepartureAnnouncement()
        
        sendCommand(PlarailBLECommand.emergencyStop(runID: activeRunID))
        lastMessage = "SEND : MOTOR,EMERGENCY_STOP,\(activeRunID)"
    }
    
    /// App-command emergency stops may be reset by the ESP32 after it returns
    /// to the stop duty and completes a fresh ESC alignment. Low-voltage stops
    /// deliberately have no recovery command.
    func emergencyReset() {
        guard vehicleState == .emergencyStopped else {
            lastMessage = "EMERGENCY RESET REJECTED : NOT STOPPED"
            return
        }
        guard requireOperationalConnection(for: "非常停止復帰") else { return }
        
        sendCommand(PlarailBLECommand.emergencyReset(runID: activeRunID))
        lastMessage = "SEND : MOTOR,EMERGENCY_RESET,\(activeRunID)"
    }
    
    func clearRouteAfterEmergencyRecovery() {
        // An app-originated emergency stop never resumes motion automatically.
        // It restores the selected route at the current station, ready for a fresh
        // departure command. Low-voltage stops never call this function.
        pendingArrivalStation = nil
        pendingNotchAfterDeparture = nil
        shouldQueuePostDepartureAnnouncement = false
        audioQueue.clear()
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        stopSequence = .none
        blankDisplayStartedAt = nil
        announcementStartedAt = nil
        clearMarqueePlayback()
        selectedNotch = .n
        targetSpeed = 0
        resetSpeedometerSlew(to: 0)
        currentSpeed = 0
        
        if isRouteConfigured {
            routePhase = .stoppedAtStation
            showPreDepartureAnnouncementIfReady()
        } else {
            routePhase = .unconfigured
            clearPreDepartureAnnouncement()
        }
    }
    
    func handleTelemetry(_ event: PlarailTelemetry) {
        switch event {
        case .authenticationRequired:
            lastMessage = "RX < AUTH REQUIRED"
            showPasswordSheet = true
            
        case .authenticationOK:
            lastMessage = "RX < AUTH OK"
            
        case .authenticationFailed:
            lastMessage = "RX < AUTH FAIL"
            showPasswordSheet = true
            
        case .connection(_, let state):
            switch state {
            case "CHECKING":
                driveState = .checking
                lastMessage = "RX < CONNECTION CHECKING"
            case "READY":
                lastMessage = "RX < CONNECTION READY"
            case "LOCKED":
                driveState = .fault
                lastMessage = "RX < CONNECTION LOCKED"
            default:
                lastMessage = "RX < CONNECTION \(state)"
            }
            
        case .vehicle(let runID, let state):
            handleVehicleTelemetry(runID: runID, state: state)
            
        case .motor(let runID, let state, let duty):
            handleMotorTelemetry(
                runID: runID,
                state: state,
                dutyPermille: duty
            )

        case .postDepartureAudioRequest(let runID):
            respondToPostDepartureAudioRequest(runID: runID)
            
        case .audioStarted(let runID, let track):
            lastMessage = "RECEIVE : AUDIO STARTED \(track)"

            if operation.departureDisplayWaitingForPostDepartureChime,
               isRouteConfigured,
               track == postDepartureChimeTrack {
                operation.departureDisplayWaitingForPostDepartureChime = false
                startDepartureMarqueeSequence()
            }

            if runID == operation.operationAudioRunID {
                switch operation.operationAudioStage {
                case .departureFirstWaitingStart:
                    guard track == operation.operationAudioFirstTrack else { break }
                    operation.operationAudioStage = .departureFirstPlaying

                case .departureSecondWaitingStart:
                    guard track == operation.operationAudioSecondTrack else { break }
                    operation.operationAudioStage = .departureSecondPlaying

                case .stopFirstWaitingStart:
                    guard track == operation.operationAudioFirstTrack else { break }
                    operation.operationAudioStage = .stopFirstPlaying
                    operation.operationAudioSecondNotBefore = Date().addingTimeInterval(AppConfig.Audio.stopSecondDelay)

                case .stopSecondWaitingStart:
                    guard track == operation.operationAudioSecondTrack else { break }
                    operation.operationAudioStage = .stopSecondPlaying
                    stopSequence = operation.stopPreDecelerationCompleted ? .holdingAnnouncement : .reducingTo180
                    announcementStartedAt = Date()

                default:
                    break
                }
            }

        case .audioFinished(let runID, let track, let durationMs):
            let durationText = durationMs.map { " / BUSY \($0)ms" } ?? ""
            lastMessage = "RECEIVE : AUDIO FINISHED \(track)\(durationText)"

            if runID == operation.pendingATCAudioRunID,
               track == AudioCatalog.atcTrack {
                applyPendingNotchAfterATC(runID: runID)
                return
            }

            if runID == operation.operationAudioRunID {
                switch operation.operationAudioStage {
                case .departureFirstPlaying:
                    guard track == operation.operationAudioFirstTrack else { break }
                    operation.operationAudioFirstFinished = true
                    operation.operationAudioStage = .departureWaitingSecond
                    operation.operationAudioSecondNotBefore = Date().addingTimeInterval(
                        AppConfig.Audio.departureFirstToSecondMinimumDelay
                    )
                    DispatchQueue.main.asyncAfter(
                        deadline: .now() + AppConfig.Audio.departureFirstToSecondMinimumDelay
                    ) {
                        self.updateOperationAudioSequence(now: Date())
                    }
                    return

                case .departureSecondPlaying:
                    guard track == operation.operationAudioSecondTrack else { break }
                    DispatchQueue.main.asyncAfter(
                        deadline: .now() + AppConfig.Audio.departureMotorStartDelayAfterOtomeFinished
                    ) {
                        guard self.operation.operationAudioRunID == runID,
                              self.operation.operationAudioStage == .departureSecondPlaying else {
                            return
                        }
                        self.beginDepartureMotorAfterOtomeFinished(runID: runID)
                    }
                    return

                case .stopFirstPlaying:
                    guard track == operation.operationAudioFirstTrack else { break }
                    continueStopSequenceAfterChime(runID: runID)
                    return

                case .stopSecondPlaying:
                    guard track == operation.operationAudioSecondTrack else { break }
                    beginStopProfileAfterAudio(runID: runID, audioFailed: false)
                    return

                default:
                    break
                }
            }

            if audioQueue.finish(runID: runID, track: track) {
                sendNextQueuedAudioIfPossible()
            }

        case .audioError(let runID, let track, let reason, let durationMs):
            let trackText = track.map(String.init) ?? "UNKNOWN"
            let durationText = durationMs.map { " / BUSY \($0)ms" } ?? ""

            if runID == operation.pendingATCAudioRunID {
                operation.pendingATCAudioRunID = nil
                operation.pendingATCNotch = nil
                operation.driverCommandFeedback = "ATC ERROR"
                operation.driverCommandFeedbackIsError = true
                lastMessage = "ATC PLAY FAILED : \(reason)\(durationText)"
                return
            }

            if runID == operation.operationAudioRunID {
                switch operation.operationAudioStage {
                case .departureFirstWaitingStart, .departureFirstPlaying:
                    abortDepartureAudioSequence(
                        reason: "TRACK \(trackText) / \(reason)\(durationText)"
                    )
                    return

                case .departureSecondWaitingStart, .departureSecondPlaying:
                    abortDepartureAudioSequence(
                        reason: "SECOND TRACK \(trackText) / \(reason)\(durationText)"
                    )
                    return

                case .stopFirstWaitingStart, .stopFirstPlaying:
                    // チャイム失敗でも放送と停車は継続する。
                    operation.operationAudioFirstFinished = true
                    operation.operationAudioSecondNotBefore = Date().addingTimeInterval(AppConfig.Stop.failureRecoveryDelay)
                    operation.operationAudioStage = .stopWaitingSecond
                    lastMessage = "STOP CHIME FAILED : \(reason)\(durationText) / CONTINUE"
                    updateOperationAudioSequence(now: Date())
                    return

                case .stopSecondWaitingStart, .stopSecondPlaying:
                    // 停車は音声より安全を優先し、エラー後も減速する。
                    lastMessage = "STOP ANNOUNCEMENT FAILED : \(reason)\(durationText) / BRAKE"
                    beginStopProfileAfterAudio(runID: runID, audioFailed: true)
                    return

                default:
                    break
                }
            }

            if audioQueue.finish(runID: runID, track: track) {
                sendNextQueuedAudioIfPossible()
            }
            lastMessage = "MUSIC PLAY FAILED : TRACK \(trackText) / \(reason)\(durationText)"
            
        case .power(_, let millivolts):
            updateBatteryVoltage(Double(millivolts) / 1000.0)
            
        case .command(let runID, let phase, let command, let details):
            let suffix = details.isEmpty ? "" : "," + details.joined(separator: ",")
            lastMessage = "RX < COMMAND,\(runID),\(phase),\(command)\(suffix)"
            
            // SET_DUTYはRECEIVED→EXECUTE→APPLIEDの二段階。
            if phase == "RECEIVED", command == "SET_DUTY" {
                guard runID == operation.pendingDutyRunID else {
                    lastMessage = "IGNORE : SET_DUTY ACK FOR OLD RUN ID \(runID)"
                    return
                }
                sendCommand(PlarailBLECommand.executePendingDuty(runID: runID))
                lastMessage = "TX > COMMAND,\(runID),EXECUTE"
                return
            }

            if phase == "APPLIED",
               command == "SET_DUTY",
               runID == operation.pendingDutyRunID,
               let dutyText = details.first,
               let duty = Int(dutyText) {
                let appliedNotch = operation.pendingDutyNotch
                operation.pendingDutyRunID = nil
                operation.pendingDutyNotch = nil
                operation.driverCommandFeedback = ""
                operation.driverCommandFeedbackIsError = false

                if let appliedNotch {
                    operation.confirmedNotch = appliedNotch
                }

                startSpeedometerSlew(to: Double(duty))
                sendLatestQueuedDutyIfNeeded(appliedDuty: duty)
                return
            }

            if command == "SET_DUTY",
               phase == "REJECTED" || phase == "EXPIRED" {
                rejectPendingDutyCommand(
                    runID: runID,
                    reason: details.joined(separator: ",")
                )
                return
            }

            if command == "STOP_PROFILE", phase == "APPLIED" {
                stopSequence = .brakingToStop
                driveState = .progress
                return
            }

            if command == "STOP_PROFILE", phase == "REJECTED" {
                operation.pendingStopRunID = nil
                clearOperationAudioSequence()
                lastMessage = "STOP PROFILE REJECTED : \(details.joined(separator: ","))"
                return
            }

            if command == "EMERGENCY_RESET", phase == "REJECTED" {
                let reason = details.joined(separator: ",")
                lastMessage = "EMERGENCY RESET REJECTED : \(reason)"
            }
            
        case .unknown(let line):
            lastMessage = "RX < \(line)"
        }
    }
    
    func handleVehicleTelemetry(runID: UInt16, state: String) {
        guard runID == 0 || runID == activeRunID else {
            lastMessage = "IGNORE : OLD RUN ID \(runID)"
            return
        }
        
        guard let newState = VehicleControllerState(rawValue: state) else {
            lastMessage = "RECEIVE : UNKNOWN VEHICLE STATE \(state)"
            return
        }

        if newState == .ready,
           operation.pendingStopRunID == runID,
           pendingArrivalStation != nil,
           stopSequence == .brakingToStop {
            lastMessage = "RX < VEHICLE READY / WAIT \(AppConfig.Stop.stoppedStateDelayAfterZero)s AFTER 0km/h"
            return
        }
        
        vehicleState = newState
        lastMessage = "RECEIVE : VEHICLE \(state)"
        
        switch newState {
        case .aligning:
            if routePhase == .emergencyStopped {
                clearRouteAfterEmergencyRecovery()
            }
            driveState = .checking
            
        case .ready:
            if let arrivedStation = pendingArrivalStation,
               let currentStationIndex,
               let travelDirection {
                if arrivedStation == selectedDestination?.terminalStation {
                    self.currentStationIndex = arrivedStation.rawValue
                    pendingArrivalStation = nil
                    currentSpeed = 0
                    targetSpeed = 0
                    selectedNotch = .n
                    operation.confirmedNotch = .n
                    clearPendingDutyCommands(revertSelection: false)
                    operation.pendingStopRunID = nil
                    operation.pendingStopApproachTrack = nil
                    operation.pendingStopArrivalTrack = nil
                    operation.stopZeroReachedAt = nil
                    operation.departureDisplayWaitingForPostDepartureChime = false
                    stopSequence = .none
                    blankDisplayStartedAt = nil
                    announcementStartedAt = nil
                    driveState = .stop
                    terminalArrivalStationName = arrivedStation.title
                    routePhase = .arrived
                    resetRouteToManualMode()
                    showTerminalArrivalAlert = true
                    return
                }
                
                self.currentStationIndex = currentStationIndex + travelDirection.step
                pendingArrivalStation = nil
                routePhase = .stoppedAtStation
                currentSpeed = 0
                targetSpeed = 0
                selectedNotch = .n
                operation.confirmedNotch = .n
                clearPendingDutyCommands(revertSelection: false)
                operation.pendingStopRunID = nil
                operation.pendingStopApproachTrack = nil
                operation.pendingStopArrivalTrack = nil
                operation.stopZeroReachedAt = nil
                operation.departureDisplayWaitingForPostDepartureChime = false
                stopSequence = .none
                blankDisplayStartedAt = nil
                announcementStartedAt = nil
                driveState = .stop
            }
            
        case .running:
            if isRouteConfigured {
                routePhase = .running
            } else {
                routePhase = .unconfigured
            }
            finishDepartureAfterMotorStarted()
            
        case .stopSequence:
            routePhase = .approaching
            
        case .coasting:
            routePhase = .approaching
            driveState = .coasting
            
        case .arrivalAnnouncing:
            routePhase = .approaching
            
        case .arrived:
            if let arrivedStation = pendingArrivalStation,
               let currentStationIndex,
               let travelDirection {
                self.currentStationIndex = currentStationIndex + travelDirection.step
                terminalArrivalStationName = arrivedStation.title
                pendingArrivalStation = nil
            } else {
                terminalArrivalStationName = currentStation?.title ?? "終着駅"
            }
            
            currentSpeed = 0
            targetSpeed = 0
            selectedNotch = .n
            driveState = .stop
            resetRouteToManualMode()
            showTerminalArrivalAlert = true
            
        case .emergencyStopped, .lowBatteryStopping, .lowBatteryStopped:
            clearPendingDutyCommands(revertSelection: true)
            operation.pendingStopRunID = nil
            operation.pendingStopApproachTrack = nil
            operation.pendingStopArrivalTrack = nil
            stopSequence = .none
            routePhase = .emergencyStopped
            driveState = .fault
            
        case .departureSequence, .unknown:
            break
        }
    }
    
    func handleMotorTelemetry(
        runID: UInt16,
        state: String,
        dutyPermille: Int?
    ) {
        if runID != 0, runID != activeRunID {
            lastMessage = "IGNORE : OLD MOTOR RUN ID \(runID)"
            return
        }
        
        // Ignore alignment telemetry until the explicit CONNECTION=READY signal
        // has unlocked the app.
        if bleManager.isVehicleConnectionChecking {
            lastMessage = "RX < MOTOR \(state) / VEHICLE CHECKING"
            return
        }
        
        if let dutyPermille {
            lastMessage = "RECEIVE : MOTOR \(state) / DUTY \(dutyPermille)"
        } else {
            lastMessage = "RECEIVE : MOTOR \(state)"
        }
        
        switch state {
        case "STOPPED":
            driveState = .stop
            resetSpeedometerSlew(to: 0)
            currentSpeed = 0
            operation.confirmedNotch = .n
            if let stopRunID = operation.pendingStopRunID,
               pendingArrivalStation != nil {
                markStopZeroReached(runID: stopRunID)
            }
            
        case "ACCELERATION":
            driveState = .progress

            // Debug Mode 2は乙女の祈りFINISHED+1秒でローカル加速済み。
            // 5秒遅れの疑似RXでは速度計アニメーションを再スタートしない。
            if isDebugMode2, vehicleState == .departureSequence {
                return
            }

            // 発車シーケンスは実機の二段始動に同期する。
            // 0→400‰を0.5秒、400→700‰を6秒で上昇させる。
            // 700‰より上のノッチだけ、その後通常の変化率で継続上昇する。
            if vehicleState == .departureSequence {
                let duty = dutyPermille ?? 0
                let stageTolerance = AppConfig.Motor.telemetryStageDetectionTolerancePermille
                if duty <= stageTolerance {
                    resetSpeedometerSlew(to: 0)
                    startSpeedometerSlew(
                        to: AppConfig.Motor.startupFirstDuty,
                        durationOverride: AppConfig.Motor.startupTo400Duration
                    )
                } else if abs(duty - Int(AppConfig.Motor.startupFirstDuty)) <= stageTolerance {
                    startSpeedometerSlew(
                        to: AppConfig.Motor.startupSecondDuty,
                        durationOverride: AppConfig.Motor.startup400To700Duration
                    )
                } else if duty >= Int(AppConfig.Motor.startupSecondDuty) - stageTolerance,
                          let requestedNotch = pendingNotchAfterDeparture,
                          requestedNotch.dutyPermille > Int(AppConfig.Motor.startupSecondDuty) {
                    startSpeedometerSlew(
                        to: Double(requestedNotch.dutyPermille)
                    )
                }
            }
            
        case "DECELERATE":
            driveState = .progress

            // Debug Mode 2はSTOP_PROFILEのTX時点からローカル減速済み。
            // 5秒遅れの疑似RXでは減速アニメーションをやり直さない。
            if isDebugMode2, stopSequence == .brakingToStop {
                return
            }

            if vehicleState == .stopSequence ||
                vehicleState == .coasting ||
                routePhase == .approaching {
                stopSequence = .brakingToStop
                startSpeedometerSlew(
                    to: 0,
                    durationOverride: AppConfig.Stop.finalBrakeDisplayDuration
                )
            }
            
        case "STABLE":
            driveState = .stable

            // STABLE通知のDutyを最終的な実機値として速度計へ反映する。
            // 旧版は発車時の500‰だけを処理していたため、P3=700‰でも
            // 表示が70km/hに固定されていた。
            if let dutyPermille {
                resetSpeedometerSlew(to: Double(dutyPermille))
                currentSpeed = speedometerPresentation(at: Date()).displaySpeed

                if let confirmedNotch = AppConfig.Motor.notch(
                    forDutyPermille: dutyPermille
                ) {
                    operation.confirmedNotch = confirmedNotch
                }

                if let requestedNotch = pendingNotchAfterDeparture,
                   abs(dutyPermille - requestedNotch.dutyPermille) <=
                    AppConfig.Motor.telemetryStageDetectionTolerancePermille {
                    pendingNotchAfterDeparture = nil
                }
            }
            
        case "IRREGULAR":
            driveState = .fault
            clearPendingDutyCommands(revertSelection: true)
            
        default:
            break
        }
    }
    
    func updatePrediction(now: Date) {
        // TimelineView renders at 30 Hz. Keep this state in sync for code paths
        // that still refer to currentSpeed, but do not round or step the gauge here.
        speedometer.update(at: now)
        updateMarqueePlayback(now: now)
        updateOperationAudioSequence(now: now)

        // 最終減速中は速度計表示が0km/hへ到達した時点を停車判定の起点にする。
        // 実機STOPPED通知やDebug Mode 2の5秒疑似RXを待たない。
        if stopSequence == .brakingToStop,
           let stopRunID = operation.pendingStopRunID,
           pendingArrivalStation != nil,
           speedometerPresentation(at: now).displaySpeed <= AppConfig.Stop.zeroSpeedDetectionThreshold {
            markStopZeroReached(runID: stopRunID)
        }

        // 連続音声は前曲完了後の整定時間が過ぎた時点で次曲を送る。
        // finish通知直後には送らず、DFPlayerのコマンド取りこぼしを避ける。
        if currentQueuedAudioTrack == nil, !queuedAudioTracks.isEmpty {
            sendNextQueuedAudioIfPossible()
        }
    }
    
    func updateBatteryVoltage(_ voltage: Double) {
        batteryVoltage = voltage
        
        if voltage < 6.8, !lowVoltageWarningShown {
            lowVoltageWarningShown = true
            showChargeAlert = true
        }
        
        if voltage >= 6.8 {
            lowVoltageWarningShown = false
        }
        
        if voltage <= 6.6 {
            lastMessage = "RECEIVE : LOW BATTERY CRITICAL"
        }
    }
    
    func resetRouteToManualMode() {
        route.resetToManualMode()
        stopSequence = .none
        blankDisplayStartedAt = nil
        announcementStartedAt = nil
        pendingNotchAfterDeparture = nil
        operation.postDepartureAudioReservedAt = nil
        operation.postDepartureAudioPendingRequestRunID = nil
        audioQueue.clear()
        clearOperationAudioSequence()
        clearPendingDutyCommands(revertSelection: false)
        operation.pendingStopRunID = nil
        operation.pendingStopApproachTrack = nil
        operation.pendingStopArrivalTrack = nil
        operation.stopZeroReachedAt = nil
        operation.confirmedNotch = .n
        selectedNotch = .n
        targetSpeed = 0
        clearMarqueePlayback()
        clearPreDepartureAnnouncement()
        lastMessage = "TERMINAL ARRIVED : MANUAL MODE"
    }
    
}
