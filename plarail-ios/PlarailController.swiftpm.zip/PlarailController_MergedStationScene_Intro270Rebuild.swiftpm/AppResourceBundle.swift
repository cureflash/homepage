import Foundation

enum AppResourceBundle {
    static func audioURL(track: Int) -> URL? {
        let name = String(format: "%04d", track)
        let fileName = "\(name).mp3"

        var bundles: [Bundle] = [Bundle.main]
        bundles.append(contentsOf: Bundle.allBundles)
        bundles.append(contentsOf: Bundle.allFrameworks)

        for bundle in bundles {
            if let url = bundle.url(
                forResource: name,
                withExtension: "mp3",
                subdirectory: "shinkansen"
            ) {
                return url
            }

            if let url = bundle.url(
                forResource: name,
                withExtension: "mp3"
            ) {
                return url
            }

            if let resourceURL = bundle.resourceURL {
                let nestedURL = resourceURL
                    .appendingPathComponent("shinkansen", isDirectory: true)
                    .appendingPathComponent(fileName)
                if FileManager.default.fileExists(atPath: nestedURL.path) {
                    return nestedURL
                }
            }
        }

        return nil
    }
}
