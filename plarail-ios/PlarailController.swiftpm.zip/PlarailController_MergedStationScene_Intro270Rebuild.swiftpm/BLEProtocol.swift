import Foundation
import CoreBluetooth

/// App and ESP32 must use these UUIDs exactly.
enum PlarailBLEUUID {
    static let peripheralLocalName = AppConfig.BLE.peripheralLocalName
    static let service = CBUUID(string: AppConfig.BLE.serviceUUID)
    static let command = CBUUID(string: AppConfig.BLE.commandUUID)
    static let telemetry = CBUUID(string: AppConfig.BLE.telemetryUUID)
}

enum PlarailBLECommand {
    /// Requests that ESP32 explicitly prompt for the application password.
    /// This is sent only after Notify has been enabled.
    static func requestAuthentication() -> String {
        "AUTH,REQUEST"
    }
    
    static func authenticate(password: String) -> String {
        "AUTH,\(password)"
    }
    
    static func setDuty(runID: UInt16, dutyPermille: Int) -> String {
        "MOTOR,SET_DUTY,\(runID),\(dutyPermille)"
    }
    
    /// Sent automatically after ESP32 confirms receipt of a staged SET_DUTY command.
    static func executePendingDuty(runID: UInt16) -> String {
        "COMMAND,\(runID),EXECUTE"
    }
    
    static func emergencyStop(runID: UInt16) -> String {
        "MOTOR,EMERGENCY_STOP,\(runID)"
    }
    
    /// Clears only an emergency stop that was explicitly initiated by the app.
    /// Low-voltage stops and reconnect-failsafe stops remain power-cycle locked.
    static func emergencyReset(runID: UInt16) -> String {
        "MOTOR,EMERGENCY_RESET,\(runID)"
    }
    
    /// Cancels a normal departure/stop sequence and returns the controller to
    /// the 5.0% stopped READY state. Safety locks are deliberately excluded.
    static func resetOperation(runID: UInt16) -> String {
        "MOTOR,RESET_OPERATION,\(runID)"
    }
    
    static func departureSequence(runID: UInt16, firstTrack: Int, secondTrack: Int) -> String {
        "SEQUENCE,DEPARTURE,\(runID),\(firstTrack),\(secondTrack)"
    }
    
    static func stopSequence(
        runID: UInt16,
        chimeTrack: Int,
        approachTrack: Int,
        arrivalTrack: Int
    ) -> String {
        "SEQUENCE,STOP,\(runID),\(chimeTrack),\(approachTrack),\(arrivalTrack)"
    }
    
    static func playAudio(
        runID: UInt16,
        track: Int,
        minimumBusyDurationMs: Int? = nil
    ) -> String {
        if let minimumBusyDurationMs {
            return "AUDIO,PLAY,\(runID),\(track),MIN_BUSY_MS,\(minimumBusyDurationMs)"
        }
        return "AUDIO,PLAY,\(runID),\(track)"
    }

    /// ESP32が700‰到達時に要求した発車後音声へ、チャイムIDと車内放送IDを同時返答する。
    /// 0,0は「発車後音声なし」を表す。
    static func postDepartureAudio(
        runID: UInt16,
        chimeTrack: Int,
        announcementTrack: Int
    ) -> String {
        "AUDIO,POST_DEPARTURE,\(runID),\(chimeTrack),\(announcementTrack)"
    }

    /// 車内放送終了後に使う停車専用プロファイル。
    /// 現在Dutyから200‰まで7秒で滑らかに下げ、その直後に0‰へ落とす。
    static func stopProfile(runID: UInt16) -> String {
        "MOTOR,STOP_PROFILE,\(runID)"
    }
    
    static func stopAudio(runID: UInt16) -> String {
        "AUDIO,STOP,\(runID)"
    }
    
    static func requestState(runID: UInt16) -> String {
        "STATE,REQUEST,\(runID)"
    }
    
    static func heartbeat(runID: UInt16) -> String {
        "HEARTBEAT,\(runID)"
    }
}

enum PlarailTelemetry: Equatable {
    case authenticationRequired
    case authenticationOK
    case authenticationFailed
    case vehicle(runID: UInt16, state: String)
    /// ESP32 sends this dedicated state during post-authentication preparation.
    /// READY is sent only after LED/connection-horn preparation completes.
    case connection(runID: UInt16, state: String)
    case motor(runID: UInt16, state: String, dutyPermille: Int?)
    /// ESP32が700‰へ到達し、発車後チャイムと車内放送のIDを要求した。
    case postDepartureAudioRequest(runID: UInt16)
    case audioStarted(runID: UInt16, track: Int)
    case audioFinished(runID: UInt16, track: Int, durationMs: Int?)
    case audioError(runID: UInt16, track: Int?, reason: String, durationMs: Int?)
    case power(runID: UInt16, millivolts: Int)
    case command(runID: UInt16, phase: String, command: String, details: [String])
    case unknown(String)
    
    static func parse(_ line: String) -> PlarailTelemetry {
        let parts = line
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .split(separator: ",", omittingEmptySubsequences: false)
            .map(String.init)
        
        guard !parts.isEmpty else { return .unknown(line) }
        
        if parts.count == 2, parts[0] == "AUTH", parts[1] == "REQUIRED" {
            return .authenticationRequired
        }
        
        if parts.count == 2, parts[0] == "AUTH", parts[1] == "OK" {
            return .authenticationOK
        }
        
        if parts.count == 2, parts[0] == "AUTH", parts[1] == "FAIL" {
            return .authenticationFailed
        }
        
        if parts.count >= 4, parts[0] == "STATE",
           let runID = UInt16(parts[1]) {
            if parts[2] == "VEHICLE" {
                return .vehicle(runID: runID, state: parts[3])
            }
            
            if parts[2] == "CONNECTION" {
                return .connection(runID: runID, state: parts[3])
            }
            
            if parts[2] == "MOTOR" {
                let dutyIndex = parts.firstIndex(of: "DUTY")
                let duty = dutyIndex.flatMap { index in
                    parts.indices.contains(index + 1) ? Int(parts[index + 1]) : nil
                }
                return .motor(runID: runID, state: parts[3], dutyPermille: duty)
            }
        }
        
        if parts.count == 3,
           parts[0] == "REQUEST",
           let runID = UInt16(parts[1]),
           parts[2] == "POST_DEPARTURE_AUDIO" {
            return .postDepartureAudioRequest(runID: runID)
        }
        
        if parts.count >= 4, parts[0] == "AUDIO",
           let runID = UInt16(parts[1]) {
            let durationIndex = parts.firstIndex(of: "DURATION_MS")
            let durationMs = durationIndex.flatMap { index in
                parts.indices.contains(index + 1) ? Int(parts[index + 1]) : nil
            }

            switch parts[2] {
            case "STARTED":
                return .audioStarted(runID: runID, track: Int(parts[3]) ?? 0)
            case "FINISHED":
                return .audioFinished(
                    runID: runID,
                    track: Int(parts[3]) ?? 0,
                    durationMs: durationMs
                )
            case "ERROR":
                let track = Int(parts[3])
                let reasonEnd = durationIndex ?? parts.count
                let reason = parts[4..<reasonEnd].joined(separator: ",")
                return .audioError(
                    runID: runID,
                    track: track,
                    reason: reason,
                    durationMs: durationMs
                )
            default:
                return .unknown(line)
            }
        }
        
        if parts.count >= 4, parts[0] == "POWER",
           let runID = UInt16(parts[1]),
           parts[2] == "VOLTAGE_MV",
           let millivolts = Int(parts[3]) {
            return .power(runID: runID, millivolts: millivolts)
        }
        
        if parts.count >= 4, parts[0] == "COMMAND",
           let runID = UInt16(parts[1]) {
            return .command(
                runID: runID,
                phase: parts[2],
                command: parts[3],
                details: Array(parts.dropFirst(4))
            )
        }
        
        return .unknown(line)
    }
}
