import SwiftUI
import Combine
import UIKit
import Foundation
import CoreBluetooth
import AVFoundation
import Darwin

// Restored user-selected cabin UI with current BLE, authentication, log, and manual-departure behavior.

enum DriveState: String {
    case disconnected = "DISCONNECTED"
    case checking = "CHECKING"
    case stop = "STOP"
    case progress = "PROGRESS"
    case settling = "SETTLING"
    case stable = "STABLE"
    case coasting = "COASTING"
    case fault = "FAULT"
    
    var color: Color {
        switch self {
        case .disconnected: return .gray
        case .checking:     return .green
        case .stop:         return .white
        case .progress:     return .orange
        case .settling:     return .green
        case .stable:       return .green
        case .coasting:     return .cyan
        case .fault:        return .red
        }
    }
    
    var japanese: String {
        switch self {
        case .disconnected: return "通信未接続"
        case .checking:     return "接続確認中"
        case .stop:         return "停止中"
        case .progress:     return "速度変化中"
        case .settling:     return "安定通知待ち"
        case .stable:       return "速度安定"
        case .coasting:     return "惰行中"
        case .fault:        return "異常停止"
        }
    }
}

enum ModuleState: String {
    case active = "ACTIVE"
    case standby = "STANDBY"
    case offline = "OFFLINE"
    case fault = "FAULT"
    
    var color: Color {
        switch self {
        case .active:  return .green
        case .standby: return .orange
        case .offline: return .gray
        case .fault:   return .red
        }
    }
}

enum TrainService: String, CaseIterable {
    case nozomi
    case hikari
    case kodama
    
    var title: String {
        switch self {
        case .nozomi: return "のぞみ"
        case .hikari: return "ひかり"
        case .kodama: return "こだま"
        }
    }
    
    var code: String {
        switch self {
        case .nozomi: return "NOZOMI"
        case .hikari: return "HIKARI"
        case .kodama: return "KODAMA"
        }
    }
    
    var englishTitle: String {
        switch self {
        case .nozomi: return "Nozomi"
        case .hikari: return "Hikari"
        case .kodama: return "Kodama"
        }
    }
    
    var displayColor: Color {
        switch self {
        case .nozomi:
            return Color(red: 1.0, green: 0.78, blue: 0.0)
        case .hikari:
            return .red
        case .kodama:
            return .blue
        }
    }
}


enum ChimeType: String, CaseIterable, Identifiable {
    case hikari
    case nozomi
    case ambitiousJapan
    case ainiIkou
    case iiHiTabidachi
    
    var id: String { rawValue }
    
    var title: String {
        switch self {
        case .hikari: return "ひかりチャイム"
        case .nozomi: return "のぞみチャイム"
        case .ambitiousJapan: return "AMBITIOUS JAPAN!"
        case .ainiIkou: return "会いにいこう"
        case .iiHiTabidachi: return "いい日旅立ち"
        }
    }
    
    var intermediateTrack: Int {
        switch self {
        case .hikari: return AppConfig.Audio.hikariIntermediateTrack
        case .nozomi: return AppConfig.Audio.nozomiIntermediateTrack
        case .ambitiousJapan: return AppConfig.Audio.ambitiousIntermediateTrack
        case .ainiIkou: return AppConfig.Audio.ainiIkouIntermediateTrack
        case .iiHiTabidachi: return AppConfig.Audio.iiHiTabidachiIntermediateTrack
        }
    }
    
    var terminalTrack: Int {
        switch self {
        case .hikari: return AppConfig.Audio.hikariTerminalTrack
        case .nozomi: return AppConfig.Audio.nozomiTerminalTrack
        case .ambitiousJapan: return AppConfig.Audio.ambitiousTerminalTrack
        case .ainiIkou: return AppConfig.Audio.ainiIkouTerminalTrack
        case .iiHiTabidachi: return AppConfig.Audio.iiHiTabidachiTerminalTrack
        }
    }
    
    func trackNumber(isTerminal: Bool) -> Int {
        isTerminal ? terminalTrack : intermediateTrack
    }
}

struct ManualAudioItem: Identifiable, Hashable {
    let trackID: Int
    let title: String
    let category: String

    var id: Int { trackID }
}

enum ManualAudioLibrary {
    static let items: [ManualAudioItem] = [
        // 発車後案内
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["uo"]!, title: "発車後案内・上り・新大阪", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["uk"]!, title: "発車後案内・上り・京都", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["un"]!, title: "発車後案内・上り・名古屋", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["uy"]!, title: "発車後案内・上り・新横浜", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["us"]!, title: "発車後案内・上り・品川", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["ut"]!, title: "発車後案内・上り・東京", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["dt"]!, title: "発車後案内・下り・東京", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["ds"]!, title: "発車後案内・下り・品川", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["dy"]!, title: "発車後案内・下り・新横浜", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["dn"]!, title: "発車後案内・下り・名古屋", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["dk"]!, title: "発車後案内・下り・京都", category: "発車後案内"),
        .init(trackID: AppConfig.Audio.departureAnnouncementTracks["do"]!, title: "発車後案内・下り・新大阪", category: "発車後案内"),

        // 停車前案内
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["uo"]!, title: "停車前案内・上り・新大阪", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["uk"]!, title: "停車前案内・上り・京都", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["un"]!, title: "停車前案内・上り・名古屋", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["uy"]!, title: "停車前案内・上り・新横浜", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["us"]!, title: "停車前案内・上り・品川", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["ut"]!, title: "停車前案内・上り・東京", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["dt"]!, title: "停車前案内・下り・東京", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["ds"]!, title: "停車前案内・下り・品川", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["dy"]!, title: "停車前案内・下り・新横浜", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["dn"]!, title: "停車前案内・下り・名古屋", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["dk"]!, title: "停車前案内・下り・京都", category: "停車前案内"),
        .init(trackID: AppConfig.Audio.arrivalApproachTracks["do"]!, title: "停車前案内・下り・新大阪", category: "停車前案内"),

        // 駅到着案内
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.tokyo]!, title: "駅到着案内・東京", category: "駅到着案内"),
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.shinagawa]!, title: "駅到着案内・品川", category: "駅到着案内"),
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.shinYokohama]!, title: "駅到着案内・新横浜", category: "駅到着案内"),
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.nagoya]!, title: "駅到着案内・名古屋", category: "駅到着案内"),
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.kyoto]!, title: "駅到着案内・京都", category: "駅到着案内"),
        .init(trackID: AppConfig.Audio.stationArrivalTracks[.shinOsaka]!, title: "駅到着案内・新大阪", category: "駅到着案内"),

        // チャイム・発車音
        .init(trackID: AppConfig.Audio.hikariIntermediateTrack, title: "ひかりチャイム・途中駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.hikariTerminalTrack, title: "ひかりチャイム・終着駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.nozomiIntermediateTrack, title: "のぞみチャイム・途中駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.nozomiTerminalTrack, title: "のぞみチャイム・終着駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.ambitiousIntermediateTrack, title: "AMBITIOUS JAPAN!・途中駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.ambitiousTerminalTrack, title: "AMBITIOUS JAPAN!・終着駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.ainiIkouTrack, title: "会いにいこう（途中駅・終着駅共通）", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.otomeNoInoriTrack, title: "乙女の祈り", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.departureBellTrack, title: "発車ベル", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.iiHiTabidachiIntermediateTrack, title: "いい日旅立ち・途中駅", category: "チャイム・発車音"),
        .init(trackID: AppConfig.Audio.iiHiTabidachiTerminalTrack, title: "いい日旅立ち・終着駅", category: "チャイム・発車音"),

        // 操作・警告音
        .init(trackID: AppConfig.Audio.connectionHornTrack, title: "警笛／接続音", category: "操作・警告音"),
        .init(trackID: AppConfig.Audio.emergencyStopTrack, title: "非常停止音", category: "操作・警告音"),
        .init(trackID: AppConfig.Audio.lowVoltageStopTrack, title: "低電圧停止音", category: "操作・警告音"),
        .init(trackID: AppConfig.Audio.oldDoorChimeTrack, title: "ドアチャイム（旧仕様）", category: "操作・警告音"),
        .init(trackID: AppConfig.Audio.atcTrack, title: "ATC確認音", category: "操作・警告音")
    ]

    static let categories = [
        "発車後案内",
        "停車前案内",
        "駅到着案内",
        "チャイム・発車音",
        "操作・警告音"
    ]
}

enum AudioCatalog {
    static func departureAnnouncementTrack(routeCode: String) -> Int? {
        AppConfig.Audio.departureAnnouncementTracks[routeCode]
    }

    static func arrivalApproachTrack(routeCode: String) -> Int? {
        AppConfig.Audio.arrivalApproachTracks[routeCode]
    }

    static func stationArrivalTrack(station: Station) -> Int {
        AppConfig.Audio.stationArrivalTrack(for: station)
    }

    static let departureBellTrack = AppConfig.Audio.departureBellTrack
    static let otomeNoInoriTrack = AppConfig.Audio.otomeNoInoriTrack
    static let hornTrack = AppConfig.Audio.connectionHornTrack
    static let emergencyStopTrack = AppConfig.Audio.emergencyStopTrack
    static let lowVoltageStopTrack = AppConfig.Audio.lowVoltageStopTrack

    // ATC確認音。実機ではノッチ変更時にESP32側が直接再生する。
    // Debug Mode 2では同じTrackをiPad側で再生する。
    static let atcTrack = AppConfig.Audio.atcTrack

    // 0は音声再生なしを表す予約値。
    static let noAudioTrack = AppConfig.Audio.noAudioTrack
}

enum Destination: String, CaseIterable {
    case tokyo
    case shinOsaka
    case okayama
    case hiroshima
    case hakata
    
    var title: String {
        switch self {
        case .tokyo: return "東京"
        case .shinOsaka: return "新大阪"
        case .okayama: return "岡山"
        case .hiroshima: return "広島"
        case .hakata: return "博多"
        }
    }
    
    var code: String {
        switch self {
        case .tokyo: return "TOKYO"
        case .shinOsaka: return "SHIN-OSAKA"
        case .okayama: return "OKAYAMA"
        case .hiroshima: return "HIROSHIMA"
        case .hakata: return "HAKATA"
        }
    }
    
    var englishTitle: String {
        switch self {
        case .tokyo: return "Tokyo"
        case .shinOsaka: return "Shin-Osaka"
        case .okayama: return "Okayama"
        case .hiroshima: return "Hiroshima"
        case .hakata: return "Hakata"
        }
    }
}


extension Destination {
    var terminalStation: Station {
        switch self {
        case .tokyo: return .tokyo
        case .shinOsaka: return .shinOsaka
        case .okayama: return .okayama
        case .hiroshima: return .hiroshima
        case .hakata: return .hakata
        }
    }

    /// 始発駅が未設定のときだけ使う既定値。従来の東京―新大阪動作を維持する。
    var defaultOriginStation: Station {
        switch self {
        case .tokyo:
            return .shinOsaka
        case .shinOsaka, .okayama, .hiroshima, .hakata:
            return .tokyo
        }
    }
}

enum Station: Int, CaseIterable {
    // ROUTE MAPは西（博多）から東（東京）の順で保持する。
    case hakata
    case kokura
    case hiroshima
    case okayama
    case shinKobe
    case shinOsaka
    case kyoto
    case nagoya
    case shinYokohama
    case shinagawa
    case tokyo
    
    var title: String {
        switch self {
        case .hakata: return "博多"
        case .kokura: return "小倉"
        case .hiroshima: return "広島"
        case .okayama: return "岡山"
        case .shinKobe: return "新神戸"
        case .shinOsaka: return "新大阪"
        case .kyoto: return "京都"
        case .nagoya: return "名古屋"
        case .shinYokohama: return "新横浜"
        case .shinagawa: return "品川"
        case .tokyo: return "東京"
        }
    }
    
    var englishTitle: String {
        switch self {
        case .hakata: return "Hakata"
        case .kokura: return "Kokura"
        case .hiroshima: return "Hiroshima"
        case .okayama: return "Okayama"
        case .shinKobe: return "Shin-Kobe"
        case .shinOsaka: return "Shin-Osaka"
        case .kyoto: return "Kyoto"
        case .nagoya: return "Nagoya"
        case .shinYokohama: return "Shin-Yokohama"
        case .shinagawa: return "Shinagawa"
        case .tokyo: return "Tokyo"
        }
    }
    
    var audioCode: String {
        switch self {
        // 山陽区間も発車後案内・停車前案内のキーとして使用する。
        case .hakata: return "h"
        case .kokura: return "c"
        case .hiroshima: return "r"
        case .okayama: return "a"
        case .shinKobe: return "b"
        case .shinOsaka: return "o"
        case .kyoto: return "k"
        case .nagoya: return "n"
        case .shinYokohama: return "y"
        case .shinagawa: return "s"
        case .tokyo: return "t"
        }
    }
}

// MARK: - 走行中の通過駅表示

/// 主要停車駅間にある東海道新幹線の駅。
/// 電光掲示板では、この並びを進行方向順に一度ずつ使用する。
enum PassingStation: String {
    case odawara = "小田原"
    case atami = "熱海"
    case mishima = "三島"
    case shinFuji = "新富士"
    case shizuoka = "静岡"
    case kakegawa = "掛川"
    case hamamatsu = "浜松"
    case toyohashi = "豊橋"
    case mikawaAnjo = "三河安城"
    case gifuHashima = "岐阜羽島"
    case maibara = "米原"

    var passageMessage: String {
        // 「ただいま」の後ろは全角スペース。
        "ただいま　\(rawValue)駅を通過"
    }
}

/// 区間ごとのランダム案内と通過駅表示の並べ方。
enum PassageDisplayPattern {
    /// 通過駅表示を行わず、従来のランダム案内だけを繰り返す。
    case none

    /// 名古屋―新横浜用。
    /// ランダムの次は必ず通過駅、通過駅が2回続いた次は必ずランダム。
    case constrainedRandom

    /// 京都―名古屋用。
    /// ランダム、ランダム、通過駅の順を繰り返す。
    case twoRandomThenPassing
}

/// 現在表示している電光掲示板項目の描画方式。
enum MarqueeDisplayKind {
    case scrolling
    case routeProgress
    case passingStation
}

enum TravelDirection: String {
    case upbound = "UPBOUND"
    case downbound = "DOWNBOUND"
    
    var title: String {
        switch self {
        case .upbound: return "上り"
        case .downbound: return "下り"
        }
    }
    
    var routeArrow: String {
        switch self {
        case .upbound: return ">>>"
        case .downbound: return "<<<"
        }
    }
    
    var step: Int {
        switch self {
        case .upbound: return 1
        case .downbound: return -1
        }
    }
    
    static func from(origin: Station, destination: Destination) -> TravelDirection? {
        let terminal = destination.terminalStation
        guard origin != terminal else { return nil }
        return origin.rawValue < terminal.rawValue ? .upbound : .downbound
    }

    /// 旧呼び出し互換。始発駅未指定時の既定始発から方向を決める。
    static func from(destination: Destination) -> TravelDirection {
        from(origin: destination.defaultOriginStation, destination: destination) ?? .upbound
    }
}

enum RoutePhase: String {
    case unconfigured = "UNCONFIGURED"
    case stoppedAtStation = "STOPPED"
    case running = "RUNNING"
    case approaching = "APPROACHING"
    case emergencyStopped = "EMERGENCY_STOP"
    case arrived = "ARRIVED"
    
    var title: String {
        switch self {
        case .unconfigured: return "経路未設定"
        case .stoppedAtStation: return "駅停車中"
        case .running: return "駅間走行中"
        case .approaching: return "停車進入中"
        case .emergencyStopped: return "区間内非常停止"
        case .arrived: return "終着駅到着"
        }
    }
}

enum VehicleControllerState: String {
    case aligning = "ALIGNING"
    case ready = "READY"
    case departureSequence = "DEPARTURE_SEQUENCE"
    case running = "RUNNING"
    case stopSequence = "STOP_SEQUENCE"
    case coasting = "COASTING"
    case arrivalAnnouncing = "ARRIVAL_ANNOUNCING"
    case arrived = "ARRIVED"
    case emergencyStopped = "EMERGENCY_STOPPED"
    case lowBatteryStopping = "LOW_BATTERY_STOPPING"
    case lowBatteryStopped = "LOW_BATTERY_STOPPED"
    case unknown = "UNKNOWN"
}

/// アプリ主導の2曲音声シーケンス。
/// ESP32は現在の1曲だけを保持し、アプリが次の曲とモーター指令を管理する。
enum OperationAudioStage: String {
    case none
    case departureFirstWaitingStart
    case departureFirstPlaying
    case departureWaitingSecond
    case departureSecondWaitingStart
    case departureSecondPlaying
    case departureWaitingMotor
    case stopFirstWaitingStart
    case stopFirstPlaying
    case stopWaitingSecond
    case stopSecondWaitingStart
    case stopSecondPlaying
    case stopWaitingBrake
}

enum StopSequence: String {
    case none
    case blankingDisplay
    case reducingTo180
    case holdingAnnouncement
    case brakingToStop
    case completed
    
    var isActive: Bool {
        switch self {
        case .blankingDisplay, .reducingTo180, .holdingAnnouncement, .brakingToStop:
            return true
        case .none, .completed:
            return false
        }
    }
}

struct ModuleInfo: Identifiable {
    let name: String
    let state: ModuleState
    
    var id: String { name }
}

struct SpeedometerCalibrationPoint {
    let dutyPermille: Double
    let gaugeProgress: Double
    let displaySpeed: Double
}

struct SpeedometerSlew {
    let startDutyPermille: Double
    let targetDutyPermille: Double
    let startedAt: Date
    
    /// Used only for firmware-owned sequence ramps whose profile differs from
    /// the ordinary manual notch-to-notch ramp.
    let durationOverride: TimeInterval?
    
    init(
        startDutyPermille: Double,
        targetDutyPermille: Double,
        startedAt: Date,
        durationOverride: TimeInterval? = nil
    ) {
        self.startDutyPermille = startDutyPermille
        self.targetDutyPermille = targetDutyPermille
        self.startedAt = startedAt
        self.durationOverride = durationOverride
    }
}

struct SpeedometerPresentation {
    let dutyPermille: Double
    let gaugeProgress: Double
    let displaySpeed: Double
}

enum Notch: String {
    case n = "N"
    case p1 = "P1"
    case p2 = "P2"
    case p3 = "P3"
    case p4 = "P4"
    case p5 = "P5"
    case p6 = "P6"
    
    /// DCモーターへ送るPWM Dutyを‰単位で返す。
    /// 値は AppConfig.Motor に集約する。
    var dutyPermille: Int {
        AppConfig.Motor.dutyPermille(for: self)
    }

    /// 実速度センサーを付ける前の疑似速度表示。
    var targetSpeed: Double {
        Double(AppConfig.Motor.displaySpeed(for: self))
    }

    var speedometerStep: Int {
        AppConfig.Motor.gaugeStep(for: self)
    }

    var speedometerDisplaySpeed: Int {
        AppConfig.Motor.displaySpeed(for: self)
    }
}

