import SwiftUI
import UIKit
import Foundation

extension ContentView {
    var isRouteConfigured: Bool {
        route.isConfigured
    }
    
    /// Debug Mode 2 mirrors a fully-ready link in every UI and route-state
    /// path. The only difference is that BLE traffic is suppressed.
    var isAppOperationAvailable: Bool {
        isDebugMode2 || (connected && bleManager.isReady)
    }
    
    var isSimulatedOrPhysicalLinkReady: Bool {
        isDebugMode2 || connected
    }
    
    var batteryDisplayColor: Color {
        guard let batteryVoltage else { return .gray }
        
        if batteryVoltage < 6.8 {
            return .red
        }
        
        if batteryVoltage < 7.2 {
            return .yellow
        }
        
        return .green
    }
    
    var batteryDisplayText: String {
        if isDebugMode2 {
            return "SIM 7.4 V"
        }
        
        guard let batteryVoltage else { return "--- V" }
        return String(format: "%.1f V", batteryVoltage)
    }
    
    var speedometerSelectedStep: Int {
        guard isAppOperationAvailable, !speedometerShowsStop else { return 0 }
        return selectedNotch.speedometerStep
    }
    
    var speedometerStableStep: Int? {
        guard isAppOperationAvailable,
              driveState == .stable,
              speedometerSelectedStep > 0 else {
            return nil
        }
        
        return speedometerSelectedStep
    }
    
    var speedometerShowsStop: Bool {
        driveState == .stop ||
        vehicleState == .emergencyStopped ||
        vehicleState == .lowBatteryStopped
    }
    
    func speedometerSlewDuration(
        from start: Double,
        to target: Double
    ) -> TimeInterval {
        speedometer.slewDuration(from: start, to: target)
    }
    
    func speedometerPresentation(at date: Date) -> SpeedometerPresentation {
        speedometer.presentation(at: date)
    }
    
    func startSpeedometerSlew(
        to requestedDuty: Double,
        durationOverride: TimeInterval? = nil
    ) {
        speedometer.startSlew(
            to: requestedDuty,
            durationOverride: durationOverride
        )
    }
    
    func resetSpeedometerSlew(to duty: Double = 0) {
        speedometer.reset(to: duty)
    }
    
    // IRREGULARは現状DriveState.faultへ変換される。
    // ALL GREENは、BLE接続・電圧6.6V以上・モーター異常なしの3条件を満たす時だけ。
    var systemAllGreen: Bool {
        if isDebugMode2 {
            return driveState != .fault
        }
        
        guard let batteryVoltage else { return false }
        return connected && batteryVoltage >= 6.6 && driveState != .fault
    }
    
    var systemStatusTitle: String {
        systemAllGreen ? "SYSTEM ALL GREEN" : "SYSTEM RED"
    }
    
    var systemStatusDetail: String {
        systemAllGreen ? "OPERATION ENABLED" : "OPERATION LOCKED"
    }
    
    var vehicleStatusColor: Color {
        systemAllGreen ? .green : .red
    }
    
    // 車両制御の内部状態は READY のまま維持し、駅停車時だけ表示を NOW BOARDING にする。
    var vehicleStatusText: String {
        if routePhase == .stoppedAtStation, vehicleState == .ready {
            return "NOW BOARDING"
        }
        return vehicleState.rawValue
    }
    
    var motorStatusColor: Color {
        switch driveState {
        case .fault:
            return .red
        case .checking, .settling, .stable:
            return .green
        default:
            return driveState.color
        }
    }
    
    /// Motor and route operations are unlocked only after the dedicated ESP32
    /// CONNECTION=READY notification is received.
    var vehicleOperationEnabled: Bool {
        isDebugMode2 || (bleManager.isReady && !bleManager.isVehicleConnectionChecking)
    }
    
    var connectionCheckingActive: Bool {
        !isDebugMode2 && (
            bleManager.isVehicleConnectionChecking ||
            bleManager.connectionPhase == .awaitingReady
        )
    }
    
    var bleStatusTitle: String {
        if isDebugMode2 {
            return "SIM READY"
        }
        
        switch bleManager.connectionPhase {
        case .ready:
            return "接続"
        case .awaitingReady:
            return "接続確認中"
        case .scanning, .connecting, .discovering, .awaitingPassword,
                .authenticating:
            return "接続中"
        case .bluetoothUnavailable, .idle, .failed:
            return "未接続"
        }
    }
    
    var bleStatusColor: Color {
        if isDebugMode2 {
            return .orange
        }
        
        switch bleManager.connectionPhase {
        case .ready:
            return .green
        case .scanning:
            return Color(red: 1.0, green: 0.0, blue: 1.0)
        case .connecting, .discovering, .awaitingPassword,
                .authenticating, .awaitingReady:
            return .green
        case .bluetoothUnavailable, .idle, .failed:
            return .orange
        }
    }
    
    var connectionControlLabel: String {
        if isDebugMode2 {
            return "EXIT DEBUG"
        }
        
        switch bleManager.connectionPhase {
        case .idle, .failed, .bluetoothUnavailable:
            return "CONNECT"
        case .scanning, .connecting, .discovering, .awaitingPassword,
                .authenticating, .awaitingReady:
            return "CANCEL"
        case .ready:
            return "DISCONNECT"
        }
    }
    
    var connectionControlColor: Color {
        if isDebugMode2 {
            return .orange
        }
        
        switch bleManager.connectionPhase {
        case .idle, .failed, .bluetoothUnavailable:
            return .orange
        case .scanning, .connecting, .discovering, .awaitingPassword,
                .authenticating, .awaitingReady, .ready:
            return .green
        }
    }
    
    var connectionControlIsDisabled: Bool {
        false
    }
    
    var routeCode: String? {
        route.routeCode
    }
    
    var nextStationIsTerminal: Bool {
        route.nextStationIsTerminal
    }
    
    var selectedChimeTrack: Int {
        selectedChime.trackNumber(isTerminal: nextStationIsTerminal)
    }

    /// 発車後チャイムは東京・新大阪発だけ終着駅用を使う。
    var postDepartureChimeTrack: Int {
        guard let currentStation else {
            return selectedChime.intermediateTrack
        }

        if currentStation == .tokyo || currentStation == .shinOsaka {
            return selectedChime.terminalTrack
        }

        return selectedChime.intermediateTrack
    }

    /// 電光掲示板は従来の1.5倍速で流す。
    /// 元の設定値は残し、表示側だけ倍率を掛ける。
    var effectiveMarqueeScrollSpeed: CGFloat {
        marqueeScrollSpeed * AppConfig.Marquee.dashboardSpeedMultiplier
    }
    
    var remainingStations: [Station] {
        route.remainingStations
    }
    
    var japaneseRemainingStopsMessage: String {
        let stopNames = remainingStations.map { station in
            station == selectedDestination?.terminalStation
            ? "終点\(station.title)"
            : station.title
        }
        
        guard !stopNames.isEmpty else {
            return "途中の停車駅はありません。"
        }
        
        return "途中の停車駅は\(stopNames.joined(separator: "、"))です。"
    }
    
    var englishStationList: String {
        let stopNames = Array(remainingStations.dropLast()).map(\.englishTitle)
        
        switch stopNames.count {
        case 0:
            return "no stations"
        case 1:
            return stopNames[0]
        case 2:
            return "\(stopNames[0]) and \(stopNames[1])"
        default:
            return "\(stopNames.dropLast().joined(separator: ", ")) and \(stopNames.last!)"
        }
    }
    
    var englishStationWord: String {
        Array(remainingStations.dropLast()).count == 1 ? "station" : "stations"
    }
    
    var englishDepartureAnnouncement: String {
        guard let service = selectedService,
              let destination = selectedDestination else {
            return ""
        }
        
        return "Welcome to the Shinkansen. This is the \(service.code) Super Express bound for \(destination.englishTitle). We will be stopping at \(englishStationList) \(englishStationWord) before arriving at \(destination.englishTitle) terminal."
    }
    
    var departureMarqueeMessages: [String] {
        guard let service = selectedService,
              let destination = selectedDestination else {
            return []
        }

        let intermediateStops = Array(remainingStations.dropLast())
        let japaneseStops: String
        if intermediateStops.isEmpty {
            japaneseStops = "途中の停車駅はありません。"
        } else {
            japaneseStops = "途中の停車駅は、\(intermediateStops.map(\.title).joined(separator: "、"))です。"
        }

        let japanese =
            "今日も新幹線をご利用くださいまして、ありがとうございます。" +
            "この電車は\(service.title)号 \(destination.title)ゆきです。" +
            japaneseStops

        let english = englishDepartureAnnouncement
        return ["\(japanese)\(english)"]
    }

    /// 現在走行している主要駅間の通過駅を、進行方向順に返す。
    var currentSectionPassingStations: [PassingStation] {
        guard let currentStation,
              let nextStation else {
            return []
        }

        switch (currentStation, nextStation) {
        case (.nagoya, .shinYokohama):
            return [
                .mikawaAnjo, .toyohashi, .hamamatsu, .kakegawa,
                .shizuoka, .shinFuji, .mishima, .atami, .odawara
            ]

        case (.shinYokohama, .nagoya):
            return [
                .odawara, .atami, .mishima, .shinFuji,
                .shizuoka, .kakegawa, .hamamatsu, .toyohashi, .mikawaAnjo
            ]

        case (.kyoto, .nagoya):
            return [.maibara, .gifuHashima]

        case (.nagoya, .kyoto):
            return [.gifuHashima, .maibara]

        default:
            return []
        }
    }

    /// 現在区間で使うランダム案内と通過駅表示の並べ方。
    var currentPassageDisplayPattern: PassageDisplayPattern {
        guard let currentStation,
              let nextStation else {
            return .none
        }

        switch (currentStation, nextStation) {
        case (.nagoya, .shinYokohama),
             (.shinYokohama, .nagoya):
            return .constrainedRandom

        case (.kyoto, .nagoya),
             (.nagoya, .kyoto):
            return .twoRandomThenPassing

        default:
            return .none
        }
    }

    var randomMarqueeCandidates: [String] {
        let safetyMessage = "JRからのお知らせです。不審なものや行為にお気づきの場合は、乗務員または駅係員までお知らせください。"
        let noSmokingMessage = "この電車は、全席禁煙となっております。車内でお煙草はお吸いいただけません。"
        let mobilePhoneMessage = "携帯電話はマナーモードに切り替えるなど、周りのお客様のご迷惑とならないように、ご協力をお願いいたします。"

        var candidates = [
            safetyMessage,
            noSmokingMessage,
            mobilePhoneMessage
        ]

        // 停車駅案内は出発時案内から分離し、通常のランダム候補へ入れる。
        if let nextStation {
            let nextStopMessage = nextStationIsTerminal
                ? "次は終点\(nextStation.title)です。"
                : "次は\(nextStation.title)に止まります。"

            candidates.append(
                "\(japaneseRemainingStopsMessage) \(nextStopMessage)"
            )
        }

        // 現在駅―次駅表示はランダム候補に含めない。
        // 通過案内を2回流した直後だけ、MarqueeManagerが強制表示する。
        return candidates
    }

    func showPreDepartureAnnouncementIfReady() {
        marquee.setPreDepartureAnnouncement(
            departureMarqueeMessages.first
        )
    }
    
    func clearPreDepartureAnnouncement() {
        marquee.clearPreDepartureAnnouncement()
    }
    
    func startDepartureMarqueeSequence() {
        marquee.startDeparture(
            messages: departureMarqueeMessages,
            passingStations: currentSectionPassingStations,
            passageDisplayPattern: currentPassageDisplayPattern
        )
        showNextMarqueeMessage()
    }
    
    func showNextMarqueeMessage() {
        guard routePhase == .running else {
            marquee.clear()
            return
        }
        
        marquee.nextMessage(
            randomCandidates: randomMarqueeCandidates,
            routeProgressToken: routeProgressDisplayToken,
            scrollSpeed: effectiveMarqueeScrollSpeed
        )
    }
    
    func updateMarqueePlayback(now: Date) {
        guard routePhase == .running else { return }
        
        if marquee.shouldAdvance(
            at: now,
            sequenceActive: stopSequence.isActive
        ) {
            showNextMarqueeMessage()
        }
    }
    
    func clearMarqueePlayback() {
        marquee.clear()
    }
    
    // MARK: - Header
    
    var header: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 1) {
                Text("300系新幹線電車制御システム")
                    .font(.system(size: 24, weight: .black, design: .serif))
                    .tracking(-1.2)
                    .scaleEffect(x: 0.88, y: 1.0, anchor: .leading)
                    .foregroundColor(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Text("300 SERIES SHINKANSEN ELECTRIC TRAIN CONTROL SYSTEM")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundColor(.green.opacity(0.65))

            }
            
            Spacer()
            
            // 上部は時計を主役にし、SYSTEM/BLE表示は各専用パネルへ集約する。
            VStack(alignment: .trailing, spacing: 1) {
                Text("SYSTEM TIME")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundColor(.green.opacity(0.6))
                
                Text(systemTime, style: .time)
                    .font(.system(size: 24, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
            }
            
            Menu {
                Section("始発駅") {
                    ForEach(Station.allCases, id: \.self) { station in
                        Button {
                            selectOriginStation(station)
                        } label: {
                            Text(station == selectedOriginStation ? "✓ \(station.title)" : station.title)
                        }
                    }
                }
            } label: {
                Image(systemName: "tram.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.green)
                    .frame(width: UILayoutConfig.Header.buttonSize, height: UILayoutConfig.Header.buttonSize)
                    .background(Color.green.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(.green.opacity(0.75), lineWidth: 0.7)
                    )
            }
            .menuStyle(.borderlessButton)
            .buttonStyle(.plain)
            .disabled(connectionCheckingActive || routeDisplayUpdatePending)
            .accessibilityLabel("始発駅設定")

            Button {
                showManualAudioLibrary = true
            } label: {
                Image(systemName: "music.note.list")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.cyan)
                    .frame(width: UILayoutConfig.Header.buttonSize, height: UILayoutConfig.Header.buttonSize)
                    .background(Color.cyan.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(.cyan.opacity(0.75), lineWidth: 0.7)
                    )
            }
            .buttonStyle(.plain)
            .accessibilityLabel("音声ライブラリ")

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: UILayoutConfig.Header.iconSize, weight: .semibold))
                    .foregroundColor(.orange)
                    .frame(width: UILayoutConfig.Header.buttonSize, height: UILayoutConfig.Header.buttonSize)
                    .background(Color.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 4))
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(.orange.opacity(0.75), lineWidth: 0.7)
                    )
            }
            .buttonStyle(.plain)
            .accessibilityLabel("設定")
        }
        .hudPanel()
    }
    
    // MARK: - 速度計・電源・列車設定
    
    var drivePanel: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: false)) { timeline in
            let presentation = speedometerPresentation(at: timeline.date)
            RailwayCabSpeedometer(
                activeProgress: speedometerShowsStop ? 0 : presentation.gaugeProgress,
                stableStep: speedometerStableStep,
                showsStop: speedometerShowsStop,
                isConnected: isAppOperationAvailable,
                displaySpeed: speedometerShowsStop ? 0 : presentation.displaySpeed,
                notchTitle: selectedNotch.rawValue
            )
        }
        .hudPanel()
    }
    
    var powerMonitorPanel: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("MONITOR")
                    .font(.system(size: 10, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
                
                Text("POWER")
                    .font(.system(size: 7, weight: .bold, design: .monospaced))
                    .foregroundColor(.green.opacity(0.65))
                
                HStack(spacing: 5) {
                    Image(systemName: batteryVoltage == nil ? "battery.0percent" : "battery.75percent")
                        .font(.system(size: 16))
                        .foregroundColor(batteryDisplayColor)
                    
                    Text(batteryDisplayText)
                        .font(.system(size: 18, weight: .black, design: .monospaced))
                        .foregroundColor(batteryDisplayColor)
                        .lineLimit(1)
                }
                
                Text(
                    isDebugMode2
                    ? "SIMULATED TELEMETRY / BLE SUPPRESSED"
                    : (batteryVoltage == nil ? (connected ? "WAITING" : "BLE OFFLINE") : "ADC TELEMETRY")
                )
                .font(.system(size: 7, design: .monospaced))
                .foregroundColor(isDebugMode2 ? .orange : (batteryVoltage == nil ? .gray : .green.opacity(0.65)))
                .lineLimit(1)
                .minimumScaleFactor(0.70)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(alignment: .leading, spacing: 7) {
                StatusReadout(
                    title: "TRAIN",
                    value: vehicleStatusText,
                    color: vehicleStatusColor,
                    valueFontSize: 17,
                    titleFontSize: 8
                )
                
                StatusReadout(
                    title: "MOTOR",
                    value: driveState.rawValue,
                    color: motorStatusColor,
                    valueFontSize: 17,
                    titleFontSize: 8
                )
            }
            .frame(width: 138, alignment: .leading)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color.green.opacity(0.025))
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke(.green.opacity(0.35), lineWidth: 0.7)
        )
    }
    
    var systemStatusPanel: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(alignment: .firstTextBaseline) {
                Text("SYSTEM")
                    .font(.system(size: 14, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
                
                Spacer(minLength: 0)
                
                Text(systemStatusDetail)
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundColor((systemAllGreen ? Color.green : Color.red).opacity(0.80))
            }
            
            Text(systemStatusTitle)
                .font(.system(size: 24, weight: .black, design: .monospaced))
                .foregroundColor(systemAllGreen ? .green : .red)
                .lineLimit(1)
                .minimumScaleFactor(0.55)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background((systemAllGreen ? Color.green : Color.red).opacity(0.045))
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke((systemAllGreen ? Color.green : Color.red).opacity(0.60), lineWidth: 0.85)
        )
    }
    
    var vehicleMotorStatusPanel: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("TRAIN / MOTOR")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.green)
            
            StatusReadout(
                title: "TRAIN",
                value: vehicleStatusText,
                color: vehicleStatusColor
            )
            
            StatusReadout(
                title: "MOTOR",
                value: driveState.rawValue,
                color: motorStatusColor
            )
            
            Spacer(minLength: 0)
        }
        .hudPanel()
    }
    
    var trainPanel: some View {
        // 上段右側は列車識別と運行情報に専念させる。
        vehicleIdentityPanel
            .hudPanel()
    }
    
    var vehicleIdentityPanel: some View {
        VStack(alignment: .leading, spacing: UILayoutConfig.TrainIdentity.panelSpacing) {
            HStack {
                Text("TRAIN IDENTITY")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(.green)
                
                Spacer()
                
                Text(isDebugMode2 ? "DEBUG MODE 2 / READY" : (connected ? "LINKED" : "OFFLINE"))
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundColor(isDebugMode2 ? .orange : (connected ? .green : .gray))
            }
            
            // 方向幕はパネル全幅を使い、横長に表示する。
            destinationDisplay
                .frame(maxWidth: .infinity)
                .frame(height: UILayoutConfig.TrainIdentity.destinationHeight)
            
            // CHIME → BLE LINK → MONITOR → SYSTEM の順で、各状態を独立表示する。
            chimeSelector
                .frame(height: UILayoutConfig.TrainIdentity.chimeHeight)
            
            bleLinkCompactPanel
                .frame(height: UILayoutConfig.TrainIdentity.bleLinkHeight)
            
            powerMonitorPanel
                .frame(height: UILayoutConfig.TrainIdentity.powerMonitorHeight)
            
            systemStatusPanel
                .frame(height: UILayoutConfig.TrainIdentity.systemStatusHeight)
            
            Spacer(minLength: 0)
        }
        .padding(UILayoutConfig.TrainIdentity.panelPadding)
        .background(Color.green.opacity(0.025))
        .overlay(
            CutPanelShape()
                .stroke(.green.opacity(0.48), lineWidth: 0.75)
        )
    }
    
    // 左上の走行シーンはDRIVER OPERATIONのノッチ値ではなく、
    // 速度計に現在表示されている数値へ直接追従する。
    // BLE / MCU送信処理には触れず、表示用アニメーションだけを連携する。
    var speedometerPlaceholderPanel: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: false)) { timeline in
            let presentation = speedometerPresentation(at: timeline.date)
            RunningScenePanel(
                displaySpeed: speedometerShowsStop ? 0 : presentation.displaySpeed,
                remainingStopTravel: CGFloat(
                    speedometer.remainingFinalBrakeSceneTravel(at: timeline.date)
                ),
                passingStation: marquee.currentPassingStation,
                passingStationEventID: marquee.passingStationEventID,
                currentStation: currentStation,
                nextStation: nextStation,
                pendingArrivalStation: pendingArrivalStation,
                routePhase: routePhase,
                stopSequence: stopSequence,
                selectedService: selectedService,
                selectedDestination: selectedDestination,
                selectedOriginStation: selectedOriginStation
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .hudPanel()
    }
    
    // ROUTE MAPはDRIVER OPERATIONの直下に同じ横幅で配置する。
    var routeMapPanel: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("ROUTE MAP")
                    .font(.system(size: 19, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
                
                Spacer()
                
                Text(travelDirection?.title ?? "未設定")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundColor(.orange)
            }
            
            stationRouteStrip
                .frame(maxHeight: .infinity)
        }
        .hudPanel()
    }
    
    var bleLinkCompactPanel: some View {
        HStack(spacing: 8) {
            Text("BLE LINK")
                .font(.system(size: 10, weight: .black, design: .monospaced))
                .foregroundColor(.green)
            
            Circle()
                .fill(bleStatusColor)
                .frame(width: 8, height: 8)
            
            Text(bleStatusTitle)
                .font(.system(size: 13, weight: .black, design: .monospaced))
                .foregroundColor(bleStatusColor)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
            
            if isDebugMode2 {
                Text("MODE 2")
                    .font(.system(size: 8, weight: .black, design: .monospaced))
                    .foregroundColor(.orange)
            }
            
            Spacer(minLength: 0)

            Button { enableQuickDebugMode2() } label: {
                Text("DEBUG")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundColor(.black)
                    .frame(width: 58, height: UILayoutConfig.TrainIdentity.connectionButtonHeight)
                    .background(Color.orange)
                    .clipShape(RoundedRectangle(cornerRadius: 3))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Debug Mode 2")
            
            Button { connectionControlTapped() } label: {
                Text(connectionControlLabel)
                    .font(.system(size: UILayoutConfig.TrainIdentity.connectionButtonFontSize, weight: .black, design: .monospaced))
                    .foregroundColor(.black)
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
                    .frame(
                        width: UILayoutConfig.TrainIdentity.connectionButtonWidth,
                        height: UILayoutConfig.TrainIdentity.connectionButtonHeight
                    )
                    .background(connectionControlColor)
                    .clipShape(RoundedRectangle(cornerRadius: 3))
            }
            .buttonStyle(.plain)
            .disabled(connectionControlIsDisabled)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Color.green.opacity(0.03))
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke(.green.opacity(0.35), lineWidth: 0.7)
        )
    }
    
    // BLE接続の状態表示と接続開始だけを担当する下段パネル。
    var bleLinkPanel: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("BLE LINK")
                    .font(.system(size: 12, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
                
                Spacer(minLength: 0)
                
                Circle()
                    .fill(bleStatusColor)
                    .frame(width: 8, height: 8)
            }
            
            Text(bleStatusTitle)
                .font(.system(size: 15, weight: .black, design: .monospaced))
                .foregroundColor(bleStatusColor)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
            
            Button { connectionControlTapped() } label: {
                Text(connectionControlLabel)
                    .font(.system(size: 13, weight: .black, design: .monospaced))
                    .frame(maxWidth: .infinity, minHeight: 38)
            }
            .buttonStyle(CompactHUDButtonStyle(color: connectionControlColor))
            .disabled(connectionControlIsDisabled)
            
            Spacer(minLength: 0)
        }
        .hudPanel()
    }
    
    // CHIMEカード自体を押すと、設定画面を開かずに直接変更できる。
    var chimeSelector: some View {
        Menu {
            Section("発車・停車チャイム") {
                ForEach(ChimeType.allCases) { chime in
                    Button {
                        selectedChime = chime
                        lastMessage = "CHIME SET : \(chime.title)"
                    } label: {
                        Text(chime == selectedChime ? "✓ \(chime.title)" : chime.title)
                    }
                }
            }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "music.note")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 1.0, green: 0.0, blue: 1.0))
                
                VStack(alignment: .leading, spacing: 1) {
                    Text("CHIME")
                        .font(.system(size: 7, design: .monospaced))
                        .foregroundColor(.green.opacity(0.65))
                    
                    Text(selectedChime.title)
                        .font(.system(size: 18, weight: .bold, design: .monospaced))
                        .foregroundColor(Color(red: 1.0, green: 0.0, blue: 1.0))
                        .lineLimit(1)
                        .minimumScaleFactor(0.65)
                }
                
                Spacer()
                
                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(Color(red: 1.0, green: 0.0, blue: 1.0))
            }
            .padding(.horizontal, 9)
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(Color(red: 1.0, green: 0.0, blue: 1.0).opacity(0.06))
            .overlay(
                CutPanelShape()
                    .stroke(Color(red: 1.0, green: 0.0, blue: 1.0).opacity(0.75), lineWidth: 0.8)
            )
        }
        .menuStyle(.borderlessButton)
        .buttonStyle(.plain)
        .disabled(connectionCheckingActive)
    }
    
    // MARK: - 車両表示
    
    var trainDisplayBoard: some View {
        VStack(spacing: 8) {
            destinationDisplay
                .frame(maxHeight: .infinity)
        }
    }
    
    var destinationDisplay: some View {
        VStack(spacing: 4) {
            // 「東京 停車中」などの運行状態は、右パネル最上部で大きく見せる。
            RouteDisplay(
                routeText: routeSectionText,
                directionText: travelDirection?.title ?? "方向未設定",
                phaseText: operation.departureDisplayWaitingForPostDepartureChime
                    ? ""
                    : (routePhase == .running ? "" : routePhase.title),
                isApproaching: routePhase == .approaching
            )
            .frame(height: 24)
            
            HStack(spacing: 5) {
                Menu {
                    ForEach(TrainService.allCases, id: \.self) { service in
                        Button {
                            selectTrainService(service)
                        } label: {
                            Text(service == selectedService ? "✓ \(service.title)" : service.title)
                        }
                    }
                } label: {
                    DirectionSegment(
                        text: selectedService?.title ?? "種別",
                        subtext: selectedService?.code ?? "SERVICE",
                        backgroundColor: selectedService?.displayColor ?? Color.white,
                        textColor: {
                            switch selectedService {
                            case .nozomi, nil:
                                return Color.black
                            case .hikari, .kodama:
                                return Color.white
                            }
                        }()
                    )
                    .frame(maxWidth: .infinity, minHeight: 62)
                }
                .menuStyle(.borderlessButton)
                .buttonStyle(.plain)
                .disabled(connectionCheckingActive || routeDisplayUpdatePending)
                
                Menu {
                    ForEach(Destination.allCases, id: \.self) { destination in
                        Button {
                            selectDestination(destination)
                        } label: {
                            Text(destination == selectedDestination ? "✓ \(destination.title)" : destination.title)
                        }
                    }
                } label: {
                    DirectionSegment(
                        text: selectedDestination?.title ?? "行先",
                        subtext: selectedDestination?.code ?? "DESTINATION",
                        backgroundColor: Color.white,
                        textColor: Color(red: 0.025, green: 0.075, blue: 0.18)
                    )
                    .frame(maxWidth: .infinity, minHeight: 62)
                }
                .menuStyle(.borderlessButton)
                .buttonStyle(.plain)
                .disabled(connectionCheckingActive || routeDisplayUpdatePending)
            }
            
            largeLEDDisplay
                .frame(height: 48)
        }
        .padding(5)
        .background(.black)
        .clipShape(RoundedRectangle(cornerRadius: 5))
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(.orange.opacity(0.85), lineWidth: 0.9)
                .allowsHitTesting(false)
        )
    }
    
    // 駅間走行中は、現在駅と次駅の間のハイフン接続だけを強く発光させる。
    // ROUTE MAPは常に始発駅を左、終着駅を右に置く。
    // 駅間走行中は出発駅を通常表示へ戻し、次駅の輪郭と駅間ハイフンだけを発光させる。
    var stationRouteStrip: some View {
        GeometryReader { geo in
            let baseStations = stations
            let displayedStations: [Station] = {
                guard let travelDirection else { return baseStations }
                return travelDirection == .upbound ? baseStations : Array(baseStations.reversed())
            }()
            let isInterstationMovement = routePhase == .running || routePhase == .approaching
            let currentVisualIndex = currentStation.flatMap { displayedStations.firstIndex(of: $0) }
            let nextVisualIndex = nextStation.flatMap { displayedStations.firstIndex(of: $0) }
            let activeSegmentIndex: Int? = {
                guard isInterstationMovement,
                      let currentVisualIndex,
                      let nextVisualIndex else {
                    return nil
                }
                return min(currentVisualIndex, nextVisualIndex)
            }()
            let connectorWidth = max(
                UILayoutConfig.RouteMap.connectorMinimumWidth,
                geo.size.width * UILayoutConfig.RouteMap.connectorWidthRatio
            )
            let totalConnectorWidth = connectorWidth * CGFloat(max(displayedStations.count - 1, 0))
            let stationWidth = max(
                UILayoutConfig.RouteMap.stationMinimumWidth,
                (geo.size.width - totalConnectorWidth) / CGFloat(max(displayedStations.count, 1))
            )
            
            HStack(spacing: 0) {
                ForEach(Array(displayedStations.enumerated()), id: \.offset) { index, station in
                    let isStoppedCurrent = !isInterstationMovement && station == currentStation
                    let isUpcomingStation = isInterstationMovement && station == nextStation
                    let nodeColor: Color = (isStoppedCurrent || isUpcomingStation) ? .green : .green.opacity(0.34)
                    let nodeDiameter: CGFloat = isStoppedCurrent ? 16 : (isUpcomingStation ? 14 : 10)
                    
                    VStack(spacing: 4) {
                        Circle()
                            .fill(isStoppedCurrent ? Color.green : Color.black)
                            .frame(width: nodeDiameter, height: nodeDiameter)
                            .overlay(
                                Circle()
                                    .stroke(nodeColor, lineWidth: (isStoppedCurrent || isUpcomingStation) ? 1.7 : 0.9)
                            )
                            .shadow(
                                color: (isStoppedCurrent || isUpcomingStation) ? Color.green.opacity(0.95) : .clear,
                                radius: 5
                            )
                        
                        Text(station.title.map { String($0) }.joined(separator: "\n"))
                            .font(.system(size: 15, weight: (isStoppedCurrent || isUpcomingStation) ? .black : .bold, design: .monospaced))
                            .foregroundColor((isStoppedCurrent || isUpcomingStation) ? .green : .white.opacity(0.82))
                            .multilineTextAlignment(.center)
                            .lineSpacing(-1)
                    }
                    .frame(width: stationWidth)
                    
                    if index < displayedStations.count - 1 {
                        RouteMapHyphenConnector(isActive: activeSegmentIndex == index)
                            .frame(width: connectorWidth)
                            .padding(.bottom, 33)
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        }
        .frame(minHeight: 96)
        .padding(.horizontal, 4)
        .padding(.vertical, 2)
        .background(Color.green.opacity(0.025))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(.green.opacity(0.34), lineWidth: 0.6)
        )
    }
    
    var largeLEDDisplay: some View {
        Group {
            if operation.departureDisplayWaitingForPostDepartureChime {
                LEDBlankDisplay(textColor: .orange)
            } else if stopSequence == .blankingDisplay {
                LEDBlankDisplay(textColor: .orange)
            } else if let fixedDisplayMessage {
                LEDStaticDisplay(message: fixedDisplayMessage, textColor: .orange)
            } else if marquee.currentDisplayKind == .routeProgress,
                      let currentStation,
                      let nextStation {
                RouteProgressDisplay(
                    previousStation: currentStation.title,
                    nextStation: nextStation.title,
                    textColor: .orange
                )
                .id(marqueeSessionID)
            } else if marquee.currentDisplayKind == .passingStation,
                      let currentMarqueeMessage {
                PassingStationMarquee(
                    message: currentMarqueeMessage,
                    scrollSpeed: effectiveMarqueeScrollSpeed
                )
                .id(marqueeSessionID)
            } else if let currentMarqueeMessage {
                LEDMarquee(
                    message: currentMarqueeMessage,
                    textColor: .orange,
                    scrollSpeed: effectiveMarqueeScrollSpeed
                )
                .id(marqueeSessionID)
            } else if let preDepartureAnnouncement {
                LEDMarquee(
                    message: preDepartureAnnouncement,
                    textColor: .orange,
                    scrollSpeed: effectiveMarqueeScrollSpeed
                )
                .id(preDepartureAnnouncementSessionID)
            } else {
                LEDBlankDisplay(textColor: .orange)
            }
        }
    }
    
    // MARK: - システム図
    
    var systemDiagram: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("SYSTEM ARCHITECTURE")
                    .font(.system(size: 12, weight: .black, design: .monospaced))
                    .foregroundColor(.green)

                Spacer()

                Text("MODULE ACTIVITY")
                    .font(.system(size: 7, design: .monospaced))
                    .foregroundColor(.green.opacity(0.55))
            }

            HStack(spacing: 3) {
                CompactSystemNode(
                    name: "APP",
                    icon: "iphone",
                    state: moduleState("APP")
                )

                TinyArrow(state: architectureLinkState("APP", "BLE"))

                CompactSystemNode(
                    name: "BLE",
                    icon: "antenna.radiowaves.left.and.right",
                    state: moduleState("BLE")
                )

                TinyArrow(state: architectureLinkState("BLE", "ESP32"))

                CompactSystemNode(
                    name: "ESP32",
                    icon: "cpu",
                    state: moduleState("ESP32")
                )

                TinyArrow(state: architectureLinkState("ESP32", "PWM"))

                CompactSystemNode(
                    name: "PWM",
                    icon: "waveform.path",
                    state: moduleState("PWM")
                )

                TinyArrow(state: architectureLinkState("PWM", "DRIVER"))

                CompactSystemNode(
                    name: "DRIVER",
                    icon: "bolt.fill",
                    state: moduleState("DRIVER")
                )

                TinyArrow(state: architectureLinkState("DRIVER", "MOTOR"))

                CompactSystemNode(
                    name: "MOTOR",
                    icon: "gearshape.2",
                    state: moduleState("MOTOR")
                )
            }

            HStack(spacing: 4) {
                CompactSystemNode(
                    name: "SENSOR",
                    icon: "circle.dotted",
                    state: moduleState("SENSOR")
                )

                TinyArrow(state: architectureLinkState("SENSOR", "ADC"))

                CompactSystemNode(
                    name: "ADC",
                    icon: "battery.75percent",
                    state: moduleState("ADC")
                )

                Spacer(minLength: 8)

                CompactSystemNode(
                    name: "AUDIO",
                    icon: "music.note",
                    state: moduleState("AUDIO")
                )

                TinyArrow(state: architectureLinkState("AUDIO", "SPEAKER"))

                CompactSystemNode(
                    name: "SPEAKER",
                    icon: "speaker.wave.3",
                    state: moduleState("SPEAKER")
                )

                Spacer(minLength: 8)

                Text("BLE NOTIFY → APP")
                    .font(.system(size: 8, design: .monospaced))
                    .foregroundColor(
                        architectureLinkState("BLE", "APP").color
                    )
                    .shadow(
                        color: architectureLinkState("BLE", "APP") == .active
                            ? architectureLinkState("BLE", "APP").color.opacity(0.9)
                            : .clear,
                        radius: 4
                    )
            }
        }
        .hudPanel()
    }

    // MARK: - 操作部
    
    var controlPanel: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("DRIVER OPERATION")
                    .font(.system(size: 21, weight: .black, design: .monospaced))
                    .foregroundColor(.green)
                
                Spacer()
                
                Text(driverOperationStatusText)
                    .font(.system(size: 17, weight: .bold, design: .monospaced))
                    .foregroundColor(driverOperationStatusColor)
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
            }
            
            HStack(spacing: 4) {
                CompactNotch(
                    title: "N",
                    color: .gray,
                    isSelected: isNotchSelected(.n),
                    isPending: isNotchPending(.n)
                ) { selectNeutral() }
                CompactNotch(
                    title: "P1",
                    color: .green.opacity(0.55),
                    isSelected: isNotchSelected(.p1),
                    isPending: isNotchPending(.p1)
                ) { setPowerNotch(.p1) }
                CompactNotch(
                    title: "P2",
                    color: .green.opacity(0.65),
                    isSelected: isNotchSelected(.p2),
                    isPending: isNotchPending(.p2)
                ) { setPowerNotch(.p2) }
                CompactNotch(
                    title: "P3",
                    color: .green.opacity(0.75),
                    isSelected: isNotchSelected(.p3),
                    isPending: isNotchPending(.p3)
                ) { setPowerNotch(.p3) }
                CompactNotch(
                    title: "P4",
                    color: .green.opacity(0.88),
                    isSelected: isNotchSelected(.p4),
                    isPending: isNotchPending(.p4)
                ) { setPowerNotch(.p4) }
                CompactNotch(
                    title: "P5",
                    color: .green,
                    isSelected: isNotchSelected(.p5),
                    isPending: isNotchPending(.p5)
                ) { setPowerNotch(.p5) }
                CompactNotch(
                    title: "P6",
                    color: .green.opacity(0.90),
                    isSelected: isNotchSelected(.p6),
                    isPending: isNotchPending(.p6)
                ) { setPowerNotch(.p6) }
            }
            
            HStack(spacing: 6) {
                Button { requestDeparture(requestedNotch: AppConfig.Motor.defaultDepartureNotch) } label: {
                    Label("発車", systemImage: "play.fill")
                }
                .buttonStyle(CompactHUDButtonStyle(color: .green))
                
                Button { requestStopAtNextStation() } label: {
                    Label("停車", systemImage: "mappin.and.ellipse")
                }
                .buttonStyle(CompactHUDButtonStyle(color: .yellow))
                
                Button { sendSound("HORN") } label: {
                    Label("警笛", systemImage: "speaker.wave.3.fill")
                }
                .buttonStyle(CompactHUDButtonStyle(color: .blue))
                
                if vehicleState == .emergencyStopped {
                    Button { emergencyReset() } label: {
                        Label("復帰", systemImage: "arrow.counterclockwise.circle.fill")
                    }
                    .buttonStyle(CompactHUDButtonStyle(color: .orange))
                } else {
                    Button { emergencyStop() } label: {
                        Label("非常停止", systemImage: "exclamationmark.octagon.fill")
                    }
                    .buttonStyle(CompactHUDButtonStyle(color: .red))
                }
            }
        }
        .disabled(!vehicleOperationEnabled)
        .opacity(vehicleOperationEnabled ? 1.0 : 0.55)
        .hudPanel()
    }
    
    // MARK: - ログ
    
    var voltageTelemetryPanel: some View {
        HStack(spacing: 6) {
            Text("VOLTAGE")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.cyan.opacity(0.75))

            Circle()
                .fill(voltageTelemetryIsHealthy ? Color.green : Color.red)
                .frame(width: 6, height: 6)

            VStack(alignment: .leading, spacing: 0) {
                Text(voltageTelemetryValueText)
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundColor(voltageTelemetryColor)
                    .lineLimit(1)

                Text(voltageTelemetryStatusText)
                    .font(.system(size: 7, weight: .bold, design: .monospaced))
                    .foregroundColor(voltageTelemetryColor.opacity(0.85))
                    .lineLimit(1)
                    .minimumScaleFactor(0.60)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .hudPanel()
    }

    var voltageTelemetryIsHealthy: Bool {
        if isDebugMode2 { return true }
        guard isSimulatedOrPhysicalLinkReady else { return false }
        guard let receivedAt = bleManager.lastVoltageTelemetryAt else { return false }
        return systemTime.timeIntervalSince(receivedAt) <= AppConfig.BLE.voltageTelemetryHealthyAge
    }

    var voltageTelemetryColor: Color {
        if isDebugMode2 { return .orange }
        guard voltageTelemetryIsHealthy else { return .red }
        guard let millivolts = bleManager.lastVoltageMillivolts else { return .gray }
        return millivolts < AppConfig.Voltage.warningMillivolts ? .orange : .green
    }

    var voltageTelemetryValueText: String {
        if isDebugMode2 {
            return batteryDisplayText
        }

        guard let millivolts = bleManager.lastVoltageMillivolts else {
            return "--.-- V"
        }

        return String(format: "%.2f V", Double(millivolts) / 1000.0)
    }

    var voltageTelemetryStatusText: String {
        if isDebugMode2 {
            return "SIMULATED"
        }

        guard let receivedAt = bleManager.lastVoltageTelemetryAt else {
            return isSimulatedOrPhysicalLinkReady ? "RX WAIT" : "BLE OFFLINE"
        }

        let age = max(0, systemTime.timeIntervalSince(receivedAt))
        let runText = bleManager.lastVoltageRunID.map { " R\($0)" } ?? ""
        return String(format: "RX %.0fs%@", age, runText)
    }

    var heartbeatPanel: some View {
        HStack(spacing: 6) {
            Text("HEARTBEAT")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.cyan.opacity(0.75))

            Circle()
                .fill(heartbeatIsHealthy ? Color.green : Color.red)
                .frame(width: 6, height: 6)

            Text(heartbeatStatusText)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(heartbeatIsHealthy ? .green : .red)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .hudPanel()
    }

    var heartbeatIsHealthy: Bool {
        guard isSimulatedOrPhysicalLinkReady else { return false }
        guard let sentAt = bleManager.lastHeartbeatSentAt else { return false }
        return systemTime.timeIntervalSince(sentAt) <= AppConfig.BLE.heartbeatHealthyAge
    }

    var heartbeatStatusText: String {
        if isDebugMode2 {
            return "APP-ONLY"
        }

        guard let sentAt = bleManager.lastHeartbeatSentAt else {
            return "WAIT"
        }

        let age = max(0, systemTime.timeIntervalSince(sentAt))
        let runText = bleManager.lastHeartbeatRunID.map { " R\($0)" } ?? ""
        return String(format: "TX %.0fs%@", age, runText)
    }

    var logPanel: some View {
        HStack(alignment: .center, spacing: 8) {
            Text("SYSTEM LOG")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.green.opacity(0.65))
                .frame(width: 70, alignment: .leading)
            
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 5) {
                    Text("TX >")
                        .foregroundColor(.orange)
                    
                    Text(
                        isDebugMode2
                        ? lastMessage
                        : (bleManager.lastRawCommandSent.isEmpty ? "---" : bleManager.lastRawCommandSent)
                    )
                    .foregroundColor(.orange)
                    .lineLimit(1)
                    .truncationMode(.middle)
                }
                
                HStack(spacing: 5) {
                    Text("RX <")
                        .foregroundColor(.green)
                    
                    Text(
                        isDebugMode2
                        ? "APP-ONLY / BLE WRITE SUPPRESSED"
                        : (bleManager.lastRawTelemetry.isEmpty ? "---" : bleManager.lastRawTelemetry)
                    )
                    .foregroundColor(.green)
                    .lineLimit(1)
                    .truncationMode(.middle)
                }
            }
            .font(.system(size: 9, design: .monospaced))
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Text(driveState.rawValue)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(driveState.color)
                .frame(width: 78, alignment: .trailing)
            
            Button {
                showBLETransportLog = true
            } label: {
                Text("LOG")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundColor(.cyan)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 3)
                            .stroke(.cyan.opacity(0.75), lineWidth: 0.7)
                    )
            }
            .buttonStyle(.plain)
        }
        .hudPanel()
    }
    
}
