import Foundation
import AVFoundation

final class DebugAudioPlayer: NSObject, AVAudioPlayerDelegate {
    static let shared = DebugAudioPlayer()

    private var player: AVAudioPlayer?
    private var finishedHandler: ((Int) -> Void)?
    private var expectedDurationMs = 0

    private override init() {
        super.init()
    }

    @discardableResult
    func play(
        track: Int,
        onStarted: @escaping () -> Void,
        onFinished: @escaping (Int) -> Void
    ) -> Bool {
        stop()

        guard let url = AppResourceBundle.audioURL(track: track) else {
            return false
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)

            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.delegate = self
            newPlayer.prepareToPlay()

            expectedDurationMs = Int((newPlayer.duration * 1000).rounded())
            finishedHandler = onFinished
            player = newPlayer

            guard newPlayer.play() else {
                player = nil
                finishedHandler = nil
                expectedDurationMs = 0
                return false
            }

            onStarted()
            return true
        } catch {
            player = nil
            finishedHandler = nil
            expectedDurationMs = 0
            return false
        }
    }

    func stop() {
        player?.stop()
        player = nil
        finishedHandler = nil
        expectedDurationMs = 0
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        let durationMs = expectedDurationMs
        let handler = finishedHandler

        self.player = nil
        finishedHandler = nil
        expectedDurationMs = 0

        guard flag else { return }
        handler?(durationMs)
    }
}
