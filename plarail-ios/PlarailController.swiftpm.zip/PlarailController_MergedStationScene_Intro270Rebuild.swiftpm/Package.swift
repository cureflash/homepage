// swift-tools-version: 5.7

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "PlarailController",
    platforms: [
        .iOS("16.0")
    ],
    products: [
        .iOSApplication(
            name: "PlarailController",
            targets: ["AppModule"],
            bundleIdentifier: "local.plarail.controller",
            teamIdentifier: "",
            displayVersion: "1.0",
            bundleVersion: "1",
            supportedDeviceFamilies: [
                .pad
            ],
            supportedInterfaceOrientations: [
                .landscapeRight,
                .landscapeLeft
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            resources: [
                .copy("Resources/shinkansen")
            ]
        )
    ]
)
