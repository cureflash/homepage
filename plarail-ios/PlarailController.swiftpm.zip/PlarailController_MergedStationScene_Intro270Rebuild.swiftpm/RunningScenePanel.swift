import SwiftUI
import UIKit
import Combine

private enum SceneBundleImage {
    private static var cache: [String: UIImage] = [:]

    static func load(_ fileName: String) -> UIImage? {
        if let cached = cache[fileName] { return cached }

        let ns = fileName as NSString
        let base = ns.deletingPathExtension
        let ext = ns.pathExtension.isEmpty ? nil : ns.pathExtension

        var bundles: [Bundle] = [Bundle.main]
        bundles.append(contentsOf: Bundle.allBundles)
        bundles.append(contentsOf: Bundle.allFrameworks)

        for bundle in bundles {
            if let url = bundle.url(
                forResource: base,
                withExtension: ext,
                subdirectory: "shinkansen"
            ), let image = UIImage(contentsOfFile: url.path) {
                cache[fileName] = image
                return image
            }

            if let resourceURL = bundle.resourceURL {
                let fallback = resourceURL
                    .appendingPathComponent("shinkansen", isDirectory: true)
                    .appendingPathComponent(fileName)
                if let image = UIImage(contentsOfFile: fallback.path) {
                    cache[fileName] = image
                    return image
                }
            }
        }
        return nil
    }
}

private struct SceneImage: View {
    let fileName: String

    var body: some View {
        Group {
            if let uiImage = SceneBundleImage.load(fileName) {
                Image(uiImage: uiImage)
                    .resizable()
            } else {
                Color.clear.overlay(
                    Text(fileName)
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundColor(.red)
                )
            }
        }
    }
}

struct RunningScenePanel: View {
    let displaySpeed: Double
    /// Exact remaining scene travel until the speedometer reaches 0 during final braking.
    let remainingStopTravel: CGFloat
    let passingStation: PassingStation?
    let passingStationEventID: UUID
    let currentStation: Station?
    let nextStation: Station?
    let pendingArrivalStation: Station?
    let routePhase: RoutePhase
    let stopSequence: StopSequence
    let selectedService: TrainService?
    let selectedDestination: Destination?
    let selectedOriginStation: Station?

    private let canvasWidth: CGFloat = 1366
    private let canvasHeight: CGFloat = 1024

    private let sceneOffsetX: CGFloat = 0
    private let sceneOffsetY: CGFloat = -30
    private let sceneScalePercent: CGFloat = 80

    private let midRatio: CGFloat = 0.50
    private let farRatio: CGFloat = 0.10

    private let nearY: CGFloat = 700
    private let nearWidth: CGFloat = 2000
    private let nearPhaseDiff: CGFloat = 1000
    private let midY: CGFloat = 700
    private let midWidth: CGFloat = 170
    private let farY: CGFloat = 600
    private let farWidth: CGFloat = 5000

    private let stationX: CGFloat = 480
    private let stationY: CGFloat = 680
    private let stationWidth: CGFloat = 1300
    private let stationTextOffsetX: CGFloat = 0
    private let stationTextOffsetY: CGFloat = -201
    private let stationTextSize: CGFloat = 88

    private let trainX: CGFloat = 351
    private let trainY: CGFloat = 682
    private let trainWidth: CGFloat = 900
    private let infraY: CGFloat = 754
    private let infraUnitWidth: CGFloat = 520

    private let maxGaugeSpeed: Double = 300
    private let maxAnimationSpeed: Double = 2000
    private let zeroSpeedThreshold: Double = AppConfig.Stop.zeroSpeedDetectionThreshold

    // Route selection intro: this sequence is intentionally independent from
    // the normal speedometer/operation state. After the horn lead, the train
    // enters while the scenery is already moving at 270 km/h equivalent,
    // cruises for 3 seconds without stopping, then linearly brakes into the
    // origin station. The braking duration is derived so the station travels
    // from fully off-screen right to stationX with no positional snap.
    private let initialApproachHornLead: TimeInterval = 1.00
    private let initialApproachCruiseDuration: TimeInterval = 3.00
    private let initialApproachCruiseGaugeSpeed: Double = 270.0
    private var initialApproachCruiseSceneSpeed: CGFloat {
        CGFloat(initialApproachCruiseGaugeSpeed / maxGaugeSpeed * maxAnimationSpeed)
    }
    private var initialApproachBrakeDistance: CGFloat {
        max(1, arrivalSpawnX - stationX)
    }
    private var initialApproachBrakeDuration: TimeInterval {
        // Linear deceleration from v0 to 0: distance = 0.5 * v0 * T.
        TimeInterval((2 * initialApproachBrakeDistance) / max(initialApproachCruiseSceneSpeed, 1))
    }

    @State private var nearTravel: CGFloat = 0
    @State private var lastMotionTick = Date()
    @State private var trainVisible = false
    @State private var trainEntered = false

    // 停車中に左側へ置く駅。初期状態では駅を表示しない。
    @State private var parkedStationName = ""
    @State private var stationIsParked = false

    // 種別＋行先が確定した時だけ、始発駅を右から流して所定位置へ止める。
    @State private var initialApproachActive = false
    @State private var initialApproachName: String?
    @State private var initialApproachStartsAt: Date?
    @State private var initialApproachLaunched = false
    @State private var initialApproachAppliedTravel: CGFloat = 0
    @State private var handledRouteSelectionKey: String?

    // 発車駅。速度が0→正になった瞬間に一度だけ切り離し、近景と同速で左へ流す。
    @State private var departureStationName: String?
    @State private var departureStartTravel: CGFloat = 0
    @State private var departedThisCycle = false

    // 通過駅。掲示板イベント発生時の nearTravel を基準に、近景と完全に同じ移動量を使う。
    @State private var activePassingStationName: String?
    @State private var passingStartTravel: CGFloat = 0
    @State private var lastHandledPassingStationEventID: UUID?

    // 到着駅。停車要求時の次駅名を固定保持し、最終減速では近景と同じ移動量だけ動かす。
    @State private var activeArrivalStationName: String?
    @State private var arrivalVisible = false
    @State private var arrivalStartTravel: CGFloat = 0
    @State private var arrivalWorldX: CGFloat = 0
    @State private var arrivalLockedAtPlatform = false
    // 到着完了時に確定した駅名。RouteManager側のcurrentStation更新順に
    // 影響されないよう、同じ駅名への同期が確認できるまで保持する。
    @State private var committedArrivalStationName: String?
    @State private var previousStopSequence: StopSequence = .none

    private let motionTimer = Timer.publish(
        every: 1.0 / 60.0,
        on: .main,
        in: .common
    ).autoconnect()

    private var animationPixelsPerSecond: CGFloat {
        let clamped = min(max(displaySpeed, 0), maxGaugeSpeed)
        return CGFloat(clamped / maxGaugeSpeed * maxAnimationSpeed)
    }

    private var arrivalSpawnX: CGFloat {
        canvasWidth + stationWidth / 2
    }

    private var routeSelectionKey: String? {
        guard let selectedService,
              let selectedDestination,
              let selectedOriginStation else { return nil }
        return "\(selectedService.rawValue)|\(selectedDestination.rawValue)|\(selectedOriginStation.rawValue)"
    }

    private func beginInitialApproach() {
        guard let selectedOriginStation else { return }

        // A fresh route configuration owns the station presentation from here.
        departureStationName = nil
        activePassingStationName = nil
        activeArrivalStationName = nil
        arrivalVisible = false
        arrivalLockedAtPlatform = false
        committedArrivalStationName = nil
        departedThisCycle = false
        stationIsParked = false
        parkedStationName = ""

        initialApproachName = selectedOriginStation.title
        initialApproachStartsAt = Date().addingTimeInterval(initialApproachHornLead)
        initialApproachActive = true
        initialApproachLaunched = false
        initialApproachAppliedTravel = 0

        // Keep the train hidden during the horn lead. It appears only when the
        // 270 km/h-equivalent approach actually begins, so there is no visual pause.
        trainVisible = false
        trainEntered = false
    }

    private func clearStationForUnconfiguredRoute() {
        initialApproachActive = false
        initialApproachName = nil
        initialApproachStartsAt = nil
        initialApproachLaunched = false
        initialApproachAppliedTravel = 0
        departureStationName = nil
        activePassingStationName = nil
        activeArrivalStationName = nil
        arrivalVisible = false
        arrivalLockedAtPlatform = false
        stationIsParked = false
        parkedStationName = ""
        departedThisCycle = false
        committedArrivalStationName = nil
        trainVisible = false
        trainEntered = false
    }

    var body: some View {
        GeometryReader { geo in
            let baseScale = geo.size.width / canvasWidth
            let appliedScale = sceneScalePercent / 100 * baseScale

            ZStack(alignment: .topLeading) {
                SceneImage(fileName: "far_bg_extended.png")
                    .scaledToFill()
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

                sceneCanvas
                    .frame(width: canvasWidth, height: canvasHeight, alignment: .topLeading)
                    .scaleEffect(appliedScale, anchor: .topLeading)
                    .offset(x: sceneOffsetX, y: sceneOffsetY)
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .topLeading)
            .clipped()
            .background(Color.black.opacity(0.12))
        }
        .clipped()
        .onAppear {
            lastMotionTick = Date()
            nearTravel = 0
            parkedStationName = ""
            stationIsParked = false
            initialApproachActive = false
            initialApproachName = nil
            initialApproachStartsAt = nil
            initialApproachLaunched = false
            initialApproachAppliedTravel = 0
            handledRouteSelectionKey = routeSelectionKey
            departureStationName = nil
            departedThisCycle = false
            activePassingStationName = nil
            lastHandledPassingStationEventID = passingStationEventID
            activeArrivalStationName = nil
            arrivalVisible = false
            arrivalStartTravel = 0
            arrivalWorldX = 0
            arrivalLockedAtPlatform = false
            committedArrivalStationName = nil
            previousStopSequence = stopSequence
            trainVisible = false
            trainEntered = false

            // If the view is recreated after the route was already selected,
            // reproduce the same intro instead of suddenly showing the station.
            if routeSelectionKey != nil {
                beginInitialApproach()
            }

        }
        .onReceive(motionTimer) { now in
            let dt = max(0, min(now.timeIntervalSince(lastMotionTick), 0.1))
            lastMotionTick = now

            var delta = animationPixelsPerSecond * CGFloat(dt)

            if initialApproachActive, let introStart = initialApproachStartsAt {
                if now < introStart {
                    delta = 0
                } else {
                    if !initialApproachLaunched {
                        initialApproachLaunched = true
                        trainVisible = true
                        trainEntered = false
                        DispatchQueue.main.async {
                            withAnimation(.linear(duration: 0.35)) {
                                trainEntered = true
                            }
                        }
                    }

                    let elapsed = max(0, now.timeIntervalSince(introStart))
                    let cruiseDistance = initialApproachCruiseSceneSpeed * CGFloat(initialApproachCruiseDuration)
                    let desiredTravel: CGFloat

                    if elapsed <= initialApproachCruiseDuration {
                        desiredTravel = initialApproachCruiseSceneSpeed * CGFloat(elapsed)
                    } else {
                        let brakeElapsed = min(
                            max(elapsed - initialApproachCruiseDuration, 0),
                            initialApproachBrakeDuration
                        )
                        let t = CGFloat(brakeElapsed)
                        let T = CGFloat(initialApproachBrakeDuration)
                        let v0 = initialApproachCruiseSceneSpeed
                        let brakingDistance = v0 * t - 0.5 * (v0 / max(T, 0.001)) * t * t
                        desiredTravel = cruiseDistance + brakingDistance
                    }

                    delta = max(0, desiredTravel - initialApproachAppliedTravel)
                    initialApproachAppliedTravel = desiredTravel

                    if elapsed >= initialApproachCruiseDuration + initialApproachBrakeDuration,
                       let name = initialApproachName {
                        parkedStationName = name
                        stationIsParked = true
                        initialApproachActive = false
                        initialApproachName = nil
                        initialApproachStartsAt = nil
                        initialApproachLaunched = false
                        initialApproachAppliedTravel = 0
                    }
                }
            }

            nearTravel += delta

            // 通過駅イベントはonChangeだけに依存せず、60 Hz側でもID差分を拾う。
            // これで電光掲示板側の更新タイミングとSwiftUI再描画が重なっても取りこぼさない。
            if lastHandledPassingStationEventID != passingStationEventID {
                lastHandledPassingStationEventID = passingStationEventID
                if let passingStation {
                    activePassingStationName = passingStation.rawValue
                    passingStartTravel = nearTravel
                }
            }

            // 停車シーケンス中は、pendingArrivalStationを最優先で到着駅名として固定する。
            if stopSequence.isActive, activeArrivalStationName == nil,
               let target = pendingArrivalStation ?? nextStation {
                activeArrivalStationName = target.title
            }

            // routePhase がRUNNINGになる前でも、速度計が動き始めた時点で駅を発車させる。
            if displaySpeed > zeroSpeedThreshold,
               stationIsParked,
               !initialApproachActive,
               !departedThisCycle,
               !stopSequence.isActive {
                departureStationName = parkedStationName
                departureStartTravel = nearTravel
                departedThisCycle = true
                stationIsParked = false
                committedArrivalStationName = nil
            }

            if let name = departureStationName {
                let x = stationX - (nearTravel - departureStartTravel)
                if x <= -stationWidth / 2 || name.isEmpty {
                    departureStationName = nil
                }
            }

            if activePassingStationName != nil {
                let x = arrivalSpawnX - (nearTravel - passingStartTravel)
                if x <= -stationWidth / 2 {
                    activePassingStationName = nil
                }
            }

            // 停車シーケンスが終了した瞬間は、RouteManagerのcurrentStationではなく
            // 停車要求時に固定した到着駅名を表示駅として確定する。
            if previousStopSequence.isActive, !stopSequence.isActive {
                if let arrivedName = activeArrivalStationName {
                    parkedStationName = arrivedName
                    stationIsParked = true
                    committedArrivalStationName = arrivedName
                }
                departureStationName = nil
                departedThisCycle = false
                arrivalVisible = false
                arrivalLockedAtPlatform = true
                activeArrivalStationName = nil
            }
            previousStopSequence = stopSequence

            if nearTravel > 10_000_000 {
                nearTravel.formTruncatingRemainder(dividingBy: 1_000_000)
                if departureStationName != nil {
                    departureStartTravel.formTruncatingRemainder(dividingBy: 1_000_000)
                }
                if activePassingStationName != nil {
                    passingStartTravel.formTruncatingRemainder(dividingBy: 1_000_000)
                }
                if arrivalVisible {
                    arrivalStartTravel.formTruncatingRemainder(dividingBy: 1_000_000)
                }
            }
        }
        .onChange(of: passingStationEventID) { newID in
            guard let passingStation else { return }
            lastHandledPassingStationEventID = newID
            activePassingStationName = passingStation.rawValue
            passingStartTravel = nearTravel
        }
        .onChange(of: stopSequence) { newValue in
            // 最初に停車対象を固定。以後currentStationの変化では書き換えない。
            if newValue.isActive, activeArrivalStationName == nil,
               let target = pendingArrivalStation ?? nextStation {
                activeArrivalStationName = target.title
            }

            // 最終減速開始時に到着駅を表示する。位置は予測値を固定せず、
            // SpeedometerModel が計算する「0 km/hまでの残り積分距離」を毎フレーム使う。
            // これにより駅と背景の相対速度が最後まで一致し、早着して右へずれて見えない。
            if newValue == .brakingToStop, let activeArrivalStationName {
                arrivalStartTravel = nearTravel
                arrivalWorldX = stationX + remainingStopTravel
                arrivalVisible = true
                arrivalLockedAtPlatform = false
                _ = activeArrivalStationName
            }
        }
        .onChange(of: routePhase) { newValue in
            if newValue == .running,
               stationIsParked,
               !initialApproachActive,
               !departedThisCycle {
                departureStationName = parkedStationName
                departureStartTravel = nearTravel
                departedThisCycle = true
                stationIsParked = false
                committedArrivalStationName = nil
            }
        }
        .onChange(of: currentStation?.rawValue) { _ in
            guard let currentStation else { return }

            if let committedArrivalStationName {
                // 到着処理の途中で一つ前のcurrentStationが通知されても無視する。
                // RouteManagerが実際の到着駅へ追いついた時だけ同期を解除する。
                if currentStation.title == committedArrivalStationName {
                    parkedStationName = currentStation.title
                    self.committedArrivalStationName = nil
                }
                return
            }

            if stationIsParked,
               !initialApproachActive,
               !stopSequence.isActive,
               !departedThisCycle,
               displaySpeed <= zeroSpeedThreshold {
                parkedStationName = currentStation.title
            }
        }
        .onChange(of: routeSelectionKey) { newKey in
            guard newKey != handledRouteSelectionKey else { return }
            handledRouteSelectionKey = newKey

            if newKey == nil {
                clearStationForUnconfiguredRoute()
            } else {
                beginInitialApproach()
            }
        }
        .onChange(of: pendingArrivalStation?.rawValue) { _ in
            // 停車要求の最初に一度だけ固定する。途中の状態更新で駅名を書き換えない。
            if stopSequence.isActive, activeArrivalStationName == nil,
               let target = pendingArrivalStation ?? nextStation {
                activeArrivalStationName = target.title
            }
        }
    }

    private var sceneCanvas: some View {
        ZStack {
            SceneLoopingObject(
                fileName: "fuji.png",
                travel: nearTravel * farRatio,
                y: farY,
                objectWidth: farWidth,
                opacity: 0.92
            )

            SceneLoopingObject(
                fileName: "sign727.png",
                travel: nearTravel * midRatio,
                y: midY,
                objectWidth: midWidth,
                opacity: 0.98
            )

            SceneRepeatingStrip(
                fileName: "near2.png",
                travel: nearTravel,
                y: nearY,
                imageWidth: nearWidth,
                phase: nearPhaseDiff,
                opacity: 0.98
            )

            SceneRepeatingStrip(
                fileName: "near1.png",
                travel: nearTravel,
                y: nearY,
                imageWidth: nearWidth,
                phase: 0,
                opacity: 0.98
            )

            // The origin station does not appear during the 3-second cruise.
            // It starts exactly at the right edge when braking begins and then
            // shares the same analytically integrated braking distance as the scenery.
            if initialApproachActive,
               let initialApproachName,
               let introStart = initialApproachStartsAt,
               Date() >= introStart {
                let elapsed = max(0, Date().timeIntervalSince(introStart))
                if elapsed >= initialApproachCruiseDuration {
                    let brakeElapsed = min(
                        max(elapsed - initialApproachCruiseDuration, 0),
                        initialApproachBrakeDuration
                    )
                    let t = CGFloat(brakeElapsed)
                    let T = CGFloat(initialApproachBrakeDuration)
                    let v0 = initialApproachCruiseSceneSpeed
                    let brakingDistance = v0 * t - 0.5 * (v0 / max(T, 0.001)) * t * t
                    let movingX = arrivalSpawnX - brakingDistance

                    StationSceneAsset(
                        name: initialApproachName,
                        x: movingX,
                        y: stationY,
                        width: stationWidth,
                        textOffsetX: stationTextOffsetX,
                        textOffsetY: stationTextOffsetY,
                        textSize: stationTextSize
                    )
                }
            }

            // 停車中の駅。発車駅・到着駅が動いている間は重複表示しない。
            if stationIsParked,
               !initialApproachActive,
               departureStationName == nil,
               !arrivalVisible,
               displaySpeed <= zeroSpeedThreshold {
                StationSceneAsset(
                    name: parkedStationName,
                    x: stationX,
                    y: stationY,
                    width: stationWidth,
                    textOffsetX: stationTextOffsetX,
                    textOffsetY: stationTextOffsetY,
                    textSize: stationTextSize
                )
            }

            // 発車駅。速度が上がった瞬間から近景と同じ移動量で左へ抜ける。
            if let departureStationName {
                let x = stationX - (nearTravel - departureStartTravel)
                StationSceneAsset(
                    name: departureStationName,
                    x: x,
                    y: stationY,
                    width: stationWidth,
                    textOffsetX: stationTextOffsetX,
                    textOffsetY: stationTextOffsetY,
                    textSize: stationTextSize
                )
            }

            // 通過駅。掲示板イベントの瞬間に右外へ生成し、近景と同速で完全通過させる。
            if let activePassingStationName {
                let x = arrivalSpawnX - (nearTravel - passingStartTravel)
                StationSceneAsset(
                    name: activePassingStationName,
                    x: x,
                    y: stationY,
                    width: stationWidth,
                    textOffsetX: stationTextOffsetX,
                    textOffsetY: stationTextOffsetY,
                    textSize: stationTextSize
                )
            }

            // 停車駅。最終減速中は「停止までの残り積分距離」をそのままX位置へ加える。
            // 0 km/hで remainingStopTravel が0になるため、stationXへ連続的に到達する。
            if arrivalVisible,
               let activeArrivalStationName {
                let x = stationX + max(0, remainingStopTravel)
                StationSceneAsset(
                    name: activeArrivalStationName,
                    x: x,
                    y: stationY,
                    width: stationWidth,
                    textOffsetX: stationTextOffsetX,
                    textOffsetY: stationTextOffsetY,
                    textSize: stationTextSize
                )
            }

            if trainVisible {
                SceneImage(fileName: "train300.png")
                    .scaledToFit()
                    .frame(width: trainWidth)
                    .scaleEffect(x: -1, y: 1)
                    .position(
                        x: trainEntered ? trainX : -trainWidth * 0.55,
                        y: trainY
                    )
                    .allowsHitTesting(false)
            }

            SceneMirroredInfraStrip(
                travel: nearTravel,
                y: infraY,
                unitWidth: infraUnitWidth
            )
            .allowsHitTesting(false)
        }
    }
}

private struct StationSceneAsset: View {
    let name: String
    let x: CGFloat
    let y: CGFloat
    let width: CGFloat
    let textOffsetX: CGFloat
    let textOffsetY: CGFloat
    let textSize: CGFloat

    var body: some View {
        ZStack {
            SceneImage(fileName: "station.png")
                .scaledToFit()
                .frame(width: width)
                .position(x: x, y: y)

            Text(name)
                .font(.system(size: textSize, weight: .bold))
                .foregroundColor(.black)
                .lineLimit(1)
                .minimumScaleFactor(0.2)
                .position(
                    x: x + textOffsetX,
                    y: y + textOffsetY
                )
        }
        .allowsHitTesting(false)
    }
}

private struct SceneRepeatingStrip: View {
    let fileName: String
    let travel: CGFloat
    let y: CGFloat
    let imageWidth: CGFloat
    let phase: CGFloat
    let opacity: Double

    var body: some View {
        GeometryReader { geo in
            let w = max(imageWidth, 1)
            let copies = max(8, Int(ceil(geo.size.width / w)) + 6)
            let offset = -travel.truncatingRemainder(dividingBy: w)

            ZStack(alignment: .leading) {
                ForEach(-2..<copies, id: \.self) { i in
                    SceneImage(fileName: fileName)
                        .scaledToFit()
                        .frame(width: w)
                        .position(
                            x: CGFloat(i) * w + offset + phase + w / 2,
                            y: y
                        )
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .opacity(opacity)
        }
    }
}

private struct SceneLoopingObject: View {
    let fileName: String
    let travel: CGFloat
    let y: CGFloat
    let objectWidth: CGFloat
    let opacity: Double

    var body: some View {
        GeometryReader { geo in
            let w = max(objectWidth, 1)
            let startX = geo.size.width + w / 2
            let endX = -w / 2
            let distance = max(1, startX - endX)
            let phase = travel.truncatingRemainder(dividingBy: distance)
            let x = startX - phase

            SceneImage(fileName: fileName)
                .scaledToFit()
                .frame(width: w)
                .position(x: x, y: y)
                .opacity(opacity)
        }
    }
}

private struct SceneMirroredInfraStrip: View {
    let travel: CGFloat
    let y: CGFloat
    let unitWidth: CGFloat

    var body: some View {
        GeometryReader { geo in
            let copies = max(8, Int(ceil(geo.size.width / unitWidth)) + 6)
            let cycle = unitWidth * 2
            let offset = -travel.truncatingRemainder(dividingBy: cycle)

            ZStack(alignment: .leading) {
                ForEach(-2..<copies, id: \.self) { i in
                    SceneImage(fileName: "infra_unit_clear.png")
                        .scaledToFit()
                        .frame(width: unitWidth)
                        .scaleEffect(x: i.isMultiple(of: 2) ? 1 : -1, y: 1)
                        .position(
                            x: CGFloat(i) * unitWidth + offset + unitWidth / 2,
                            y: y
                        )
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }
}
