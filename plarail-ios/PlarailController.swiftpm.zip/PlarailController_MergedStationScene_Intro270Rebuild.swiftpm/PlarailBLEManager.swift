import Foundation
import CoreBluetooth
import Combine

enum PlarailBLEConnectionPhase: Equatable {
    case bluetoothUnavailable
    case idle
    case scanning
    case connecting
    case discovering
    case awaitingPassword
    case authenticating
    case awaitingReady
    case ready
    case failed(String)
    
    var title: String {
        switch self {
        case .bluetoothUnavailable: return "BLUETOOTH OFF"
        case .idle: return "OFFLINE"
        case .scanning: return "SCANNING"
        case .connecting: return "CONNECTING"
        case .discovering: return "DISCOVERING"
        case .awaitingPassword: return "PASSWORD REQUIRED"
        case .authenticating: return "AUTHENTICATING"
        case .awaitingReady: return "WAITING STATUS"
        case .ready: return "ONLINE"
        case .failed: return "ERROR"
        }
    }
}

struct PlarailBLELogEntry: Identifiable {
    enum Direction: Equatable {
        case tx
        case rx
    }
    
    let id = UUID()
    let timestamp: Date
    let direction: Direction
    let message: String
}

/// CoreBluetooth client for the prarail-controller ESP32 peripheral.
/// The password exchange is application-level authentication, not BLE pairing.
final class PlarailBLEManager: NSObject, ObservableObject {
    static let heartbeatInterval = AppConfig.BLE.heartbeatInterval
    static let voltageTelemetryInterval = AppConfig.BLE.voltageTelemetryInterval
    static let voltageTelemetryMissLimit = AppConfig.BLE.voltageTelemetryMissLimit
    private static let maximumTransportLogEntries = AppConfig.BLE.maximumTransportLogEntries
    
    @Published private(set) var connectionPhase: PlarailBLEConnectionPhase = .idle
    @Published private(set) var telemetryEvent: PlarailTelemetry?
    @Published private(set) var lastRawTelemetry = ""
    /// Latest outbound command for the TX log. AUTH credentials are masked.
    @Published private(set) var lastRawCommandSent = ""
    /// Ordered RX/TX history. The oldest entry is removed after 300 lines.
    @Published private(set) var transportLog: [PlarailBLELogEntry] = []
    @Published private(set) var authenticationMessage: String?
    @Published private(set) var peripheralName = ""
    /// Heartbeat is kept out of the normal RX/TX log and shown in its own panel.
    @Published private(set) var lastHeartbeatSentAt: Date?
    @Published private(set) var lastHeartbeatRunID: UInt16?
    
    /// POWER telemetry has a dedicated monitor and is kept out of SYSTEM LOG.
    @Published private(set) var lastVoltageTelemetryAt: Date?
    @Published private(set) var lastVoltageMillivolts: Int?
    @Published private(set) var lastVoltageRunID: UInt16?

    /// Non-nil once when two consecutive 5-second POWER notifications are absent.
    /// It is cleared automatically by the next valid POWER notification or disconnect.
    @Published private(set) var voltageTelemetryAlertMessage: String?
    
    var isReady: Bool {
        connectionPhase == .ready
    }
    
    /// True after AUTH,OK while the app is waiting for CONNECTION,READY.
    /// ContentView uses this to present the existing "接続確認中" state.
    var isVehicleConnectionChecking: Bool {
        connectionPhase == .awaitingReady
    }
    
    var isLinkActive: Bool {
        switch connectionPhase {
        case .scanning, .connecting, .discovering, .awaitingPassword,
                .authenticating, .awaitingReady, .ready:
            return true
        case .bluetoothUnavailable, .idle, .failed:
            return false
        }
    }
    
    private var central: CBCentralManager!
    private var peripheral: CBPeripheral?
    private var commandCharacteristic: CBCharacteristic?
    private var telemetryCharacteristic: CBCharacteristic?
    
    private var writeQueue: [Data] = []
    private var isWriteInFlight = false
    private var telemetryBuffer = Data()
    private var disconnectRequested = false
    
    private var voltageMonitoringStartedAt: Date?
    private var voltageTelemetryAlertRaised = false
    
    override init() {
        super.init()
        central = CBCentralManager(
            delegate: self,
            queue: .main,
            options: [CBCentralManagerOptionShowPowerAlertKey: true]
        )
    }
    
    func connect() {
        guard central.state == .poweredOn else {
            connectionPhase = .bluetoothUnavailable
            return
        }
        
        guard !isLinkActive else { return }
        
        disconnectRequested = false
        resetTransport(keepPhase: true)
        connectionPhase = .scanning
        
        central.scanForPeripherals(
            withServices: [PlarailBLEUUID.service],
            options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
        )
    }
    
    func disconnect() {
        disconnectRequested = true
        central.stopScan()
        
        if let peripheral {
            central.cancelPeripheralConnection(peripheral)
        }
        
        resetTransport(keepPhase: false)
        connectionPhase = .idle
    }
    
    /// Sends operational commands only after AUTH,OK and CONNECTION,READY.
    func send(_ command: String) {
        guard isReady else {
            connectionPhase = .failed("車両はまだ操作可能状態ではありません。")
            return
        }
        
        enqueueLine(command)
    }

    /// Debug Mode 2用。実際には書き込まず、通常送信と同じTXログだけを残す。
    func recordSimulatedTransmission(_ command: String) {
        let isHeartbeat = command.hasPrefix("HEARTBEAT,")
        let sanitizedLine = sanitizedCommandForLog(command)

        if isHeartbeat {
            lastHeartbeatSentAt = Date()
            lastHeartbeatRunID = command
                .split(separator: ",")
                .dropFirst()
                .first
                .flatMap { UInt16($0) }
        } else {
            lastRawCommandSent = sanitizedLine
            appendTransportLog(direction: .tx, message: sanitizedLine)
        }
    }

    /// Debug Mode 2用。疑似受信行を通常受信と同じ経路へ流す。
    func receiveSimulatedTelemetry(_ line: String) {
        handleTelemetryLine(line)
    }
    
    func authenticate(password: String) {
        guard connectionPhase == .awaitingPassword else { return }
        guard !password.isEmpty else {
            authenticationMessage = "パスワードを入力してください。"
            return
        }
        
        authenticationMessage = nil
        connectionPhase = .authenticating
        enqueueLine(PlarailBLECommand.authenticate(password: password))
    }
    
    /// Call once per second from the UI. The heartbeat period is exactly five seconds.
    /// POWER is expected every five seconds; ten seconds without POWER is two missed intervals.
    func performPeriodicMaintenance(runID: UInt16, now: Date = Date()) {
        guard connectionPhase == .ready else { return }
        
        if lastHeartbeatSentAt == nil ||
            now.timeIntervalSince(lastHeartbeatSentAt ?? now) >= Self.heartbeatInterval {
            enqueueLine(PlarailBLECommand.heartbeat(runID: runID))
            lastHeartbeatSentAt = now
        }
        
        let referenceDate = lastVoltageTelemetryAt ?? voltageMonitoringStartedAt
        let lossLimit = Self.voltageTelemetryInterval * TimeInterval(Self.voltageTelemetryMissLimit)
        
        if let referenceDate,
           !voltageTelemetryAlertRaised,
           now.timeIntervalSince(referenceDate) >= lossLimit {
            voltageTelemetryAlertRaised = true
            voltageTelemetryAlertMessage =
            "電圧監視信号を10秒間受信していません。車両との通信状態を確認してください。"
        }
    }
    
    private func enqueueLine(_ line: String) {
        // Heartbeat is periodic maintenance telemetry. Keep it out of SYSTEM LOG
        // and the scrollable RX/TX history so operational commands remain visible.
        let isHeartbeat = line.hasPrefix("HEARTBEAT,")
        let sanitizedLine = sanitizedCommandForLog(line)

        if isHeartbeat {
            lastHeartbeatSentAt = Date()
            lastHeartbeatRunID = line.split(separator: ",").dropFirst().first.flatMap { UInt16($0) }
        } else {
            lastRawCommandSent = sanitizedLine
            appendTransportLog(direction: .tx, message: sanitizedLine)
        }
        
        guard let peripheral, commandCharacteristic != nil else {
            connectionPhase = .failed("Command Characteristicが利用できません。")
            return
        }
        
        let payload = Data((line + "\n").utf8)
        let maximumLength = max(
            peripheral.maximumWriteValueLength(for: .withResponse),
            1
        )
        
        var offset = 0
        while offset < payload.count {
            let end = min(offset + maximumLength, payload.count)
            writeQueue.append(payload.subdata(in: offset..<end))
            offset = end
        }
        
        writeNextChunkIfPossible()
    }
    
    private func sanitizedCommandForLog(_ command: String) -> String {
        if command == PlarailBLECommand.requestAuthentication() {
            return command
        }
        
        if command.hasPrefix("AUTH,") {
            return "AUTH,********"
        }
        return command
    }
    
    private func appendTransportLog(
        direction: PlarailBLELogEntry.Direction,
        message: String
    ) {
        transportLog.append(
            PlarailBLELogEntry(
                timestamp: Date(),
                direction: direction,
                message: message
            )
        )
        
        if transportLog.count > Self.maximumTransportLogEntries {
            transportLog.removeFirst(
                transportLog.count - Self.maximumTransportLogEntries
            )
        }
    }
    
    private func writeNextChunkIfPossible() {
        guard !isWriteInFlight,
              !writeQueue.isEmpty,
              let peripheral,
              let commandCharacteristic else {
            return
        }
        
        let nextChunk = writeQueue.removeFirst()
        isWriteInFlight = true
        peripheral.writeValue(nextChunk, for: commandCharacteristic, type: .withResponse)
    }
    
    private func beginReadyMaintenanceWindow(at date: Date) {
        lastHeartbeatSentAt = date
        voltageMonitoringStartedAt = date
        lastVoltageTelemetryAt = nil
        lastVoltageMillivolts = nil
        lastVoltageRunID = nil
        voltageTelemetryAlertRaised = false
        voltageTelemetryAlertMessage = nil
    }
    
    private func resetMaintenanceState() {
        lastHeartbeatSentAt = nil
        lastHeartbeatRunID = nil
        voltageMonitoringStartedAt = nil
        lastVoltageTelemetryAt = nil
        lastVoltageMillivolts = nil
        lastVoltageRunID = nil
        voltageTelemetryAlertRaised = false
        voltageTelemetryAlertMessage = nil
    }
    
    private func resetTransport(keepPhase: Bool) {
        peripheral?.delegate = nil
        peripheral = nil
        commandCharacteristic = nil
        telemetryCharacteristic = nil
        writeQueue = []
        isWriteInFlight = false
        telemetryBuffer = Data()
        peripheralName = ""
        authenticationMessage = nil
        resetMaintenanceState()
        
        if !keepPhase {
            telemetryEvent = nil
            lastRawTelemetry = ""
            lastRawCommandSent = ""
        }
    }
    
    private func handleTelemetryLine(_ line: String) {
        let event = PlarailTelemetry.parse(line)
        let now = Date()
        let isPowerTelemetry: Bool

        if case .power(let runID, let millivolts) = event {
            isPowerTelemetry = true
            lastVoltageTelemetryAt = now
            lastVoltageMillivolts = millivolts
            lastVoltageRunID = runID
            voltageTelemetryAlertRaised = false
            voltageTelemetryAlertMessage = nil
        } else {
            isPowerTelemetry = false
        }

        // POWER is periodic maintenance telemetry. Keep it out of SYSTEM LOG and
        // the scrollable RX/TX history; update the dedicated VOLTAGE monitor.
        if !isPowerTelemetry {
            appendTransportLog(direction: .rx, message: line)
        }
        
        switch event {
        case .authenticationOK:
            connectionPhase = .awaitingReady
            authenticationMessage = nil
            
        case .authenticationFailed:
            connectionPhase = .awaitingPassword
            authenticationMessage = "パスワードが違います。"
            
        case .connection(_, let state):
            if state == "READY", connectionPhase == .awaitingReady {
                connectionPhase = .ready
                beginReadyMaintenanceWindow(at: now)
            } else if state == "LOCKED" {
                connectionPhase = .failed(
                    "車両は安全停止でロックされています。電源と電池電圧を確認してください。"
                )
            }
            
        default:
            break
        }
        
        if !isPowerTelemetry {
            lastRawTelemetry = line
        }
        telemetryEvent = event
    }
}

extension PlarailBLEManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            if connectionPhase == .bluetoothUnavailable {
                connectionPhase = .idle
            }
        case .poweredOff, .unauthorized, .unsupported, .resetting, .unknown:
            central.stopScan()
            resetTransport(keepPhase: false)
            connectionPhase = .bluetoothUnavailable
        @unknown default:
            central.stopScan()
            resetTransport(keepPhase: false)
            connectionPhase = .bluetoothUnavailable
        }
    }
    
    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        let advertisedName = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let candidateName = advertisedName ?? peripheral.name ?? ""
        
        guard candidateName == PlarailBLEUUID.peripheralLocalName else { return }
        
        central.stopScan()
        self.peripheral = peripheral
        peripheralName = candidateName
        connectionPhase = .connecting
        central.connect(peripheral, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        self.peripheral = peripheral
        peripheral.delegate = self
        connectionPhase = .discovering
        peripheral.discoverServices([PlarailBLEUUID.service])
    }
    
    func centralManager(
        _ central: CBCentralManager,
        didFailToConnect peripheral: CBPeripheral,
        error: Error?
    ) {
        resetTransport(keepPhase: false)
        connectionPhase = .failed(error?.localizedDescription ?? "ESP32へ接続できませんでした。")
    }
    
    func centralManager(
        _ central: CBCentralManager,
        didDisconnectPeripheral peripheral: CBPeripheral,
        error: Error?
    ) {
        let requested = disconnectRequested
        disconnectRequested = false
        resetTransport(keepPhase: false)
        
        if requested {
            connectionPhase = .idle
        } else {
            let reason = error?.localizedDescription ?? "BLE接続が切断されました。"
            connectionPhase = .failed(reason)
        }
    }
}

extension PlarailBLEManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error {
            connectionPhase = .failed(error.localizedDescription)
            return
        }
        
        guard let service = peripheral.services?.first(where: { $0.uuid == PlarailBLEUUID.service }) else {
            connectionPhase = .failed("TrainControl Serviceが見つかりません。")
            return
        }
        
        peripheral.discoverCharacteristics(
            [PlarailBLEUUID.command, PlarailBLEUUID.telemetry],
            for: service
        )
    }
    
    func peripheral(
        _ peripheral: CBPeripheral,
        didDiscoverCharacteristicsFor service: CBService,
        error: Error?
    ) {
        if let error {
            connectionPhase = .failed(error.localizedDescription)
            return
        }
        
        guard let characteristics = service.characteristics else {
            connectionPhase = .failed("Characteristicを取得できません。")
            return
        }
        
        commandCharacteristic = characteristics.first { $0.uuid == PlarailBLEUUID.command }
        telemetryCharacteristic = characteristics.first { $0.uuid == PlarailBLEUUID.telemetry }
        
        guard let commandCharacteristic,
              commandCharacteristic.properties.contains(.write),
              let telemetryCharacteristic,
              telemetryCharacteristic.properties.contains(.notify) else {
            connectionPhase = .failed("Command/Telemetry Characteristicの設定が不正です。")
            return
        }
        
        peripheral.setNotifyValue(true, for: telemetryCharacteristic)
    }
    
    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateNotificationStateFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            connectionPhase = .failed(error.localizedDescription)
            return
        }
        
        guard characteristic.uuid == PlarailBLEUUID.telemetry,
              characteristic.isNotifying else {
            return
        }
        
        connectionPhase = .awaitingPassword
        enqueueLine(PlarailBLECommand.requestAuthentication())
    }
    
    func peripheral(
        _ peripheral: CBPeripheral,
        didWriteValueFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        isWriteInFlight = false
        
        if let error {
            connectionPhase = .failed("書き込み失敗: \(error.localizedDescription)")
            return
        }
        
        writeNextChunkIfPossible()
    }
    
    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateValueFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        if let error {
            connectionPhase = .failed("Telemetry受信失敗: \(error.localizedDescription)")
            return
        }
        
        guard characteristic.uuid == PlarailBLEUUID.telemetry,
              let value = characteristic.value else {
            return
        }
        
        telemetryBuffer.append(value)
        
        while let newlineIndex = telemetryBuffer.firstIndex(of: 0x0A) {
            let lineData = telemetryBuffer.prefix(upTo: newlineIndex)
            telemetryBuffer.removeSubrange(...newlineIndex)
            
            if let line = String(data: lineData, encoding: .utf8) {
                handleTelemetryLine(line)
            }
        }
    }
}
