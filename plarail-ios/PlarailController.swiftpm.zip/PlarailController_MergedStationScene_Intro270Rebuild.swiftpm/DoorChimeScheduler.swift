﻿import Foundation
import Combine
import AVFoundation
import Darwin

/// Schedules the local door chime from an in-memory PCM CAF buffer.
/// The display update is delayed to the same planned audio-output time instead
/// of using a fixed MP3 startup delay.
final class DoorChimeScheduler: ObservableObject {
    struct PlaybackTiming {
        let displayDelay: TimeInterval
    }
    
    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private var buffer: AVAudioPCMBuffer?
    private var graphConfigured = false
    private(set) var errorMessage: String?
    
    func prepare() -> Bool {
        if buffer != nil, engine.isRunning {
            return true
        }
        
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setPreferredSampleRate(48_000)
            try session.setPreferredIOBufferDuration(0.005)
            try session.setActive(true)
            
            if buffer == nil {
                guard let url = Bundle.main.url(forResource: "DoorChime", withExtension: "caf") else {
                    errorMessage = "DoorChime.caf がアプリに追加されていません。Target Membershipを有効にしてください。"
                    return false
                }
                
                let file = try AVAudioFile(forReading: url)
                guard let loadedBuffer = AVAudioPCMBuffer(
                    pcmFormat: file.processingFormat,
                    frameCapacity: AVAudioFrameCount(file.length)
                ) else {
                    errorMessage = "DoorChime.caf のPCMバッファを確保できません。"
                    return false
                }
                try file.read(into: loadedBuffer)
                buffer = loadedBuffer
            }
            
            guard let buffer else {
                errorMessage = "DoorChime.caf を読み込めません。"
                return false
            }
            
            if !graphConfigured {
                engine.attach(player)
                engine.connect(player, to: engine.mainMixerNode, format: buffer.format)
                graphConfigured = true
            }
            
            engine.prepare()
            if !engine.isRunning {
                try engine.start()
            }
            
            errorMessage = nil
            return true
        } catch {
            errorMessage = "DoorChime.caf を準備できません。\n\(error.localizedDescription)"
            return false
        }
    }
    
    func schedulePlayback() -> PlaybackTiming? {
        guard prepare(), let buffer else { return nil }
        
        do {
            if !engine.isRunning {
                try engine.start()
            }
        } catch {
            errorMessage = "DoorChime.caf の再生エンジンを開始できません。\n\(error.localizedDescription)"
            return nil
        }
        
        let session = AVAudioSession.sharedInstance()
        let schedulingLeadTime = max(0.050, session.ioBufferDuration * 3.0)
        let hostTime = mach_absolute_time() &+ AVAudioTime.hostTime(forSeconds: schedulingLeadTime)
        let startTime = AVAudioTime(hostTime: hostTime)
        
        player.stop()
        player.scheduleBuffer(buffer, at: startTime, options: [.interrupts])
        player.play(at: startTime)
        
        // The visual update lands just before the first audible sample rather
        // than 0.45 seconds after the button action.
        let outputDelay = max(0, session.ioBufferDuration + session.outputLatency)
        let displayDelay = max(0, schedulingLeadTime + outputDelay - (1.0 / 120.0))
        return PlaybackTiming(displayDelay: displayDelay)
    }
}
