import SwiftUI

/// 画面上の位置・比率・大きさだけをまとめた設定。
/// 特に速度計の配置は Speedometer 内で一括調整できる。
enum UILayoutConfig {
    struct NormalizedPoint {
        let x: CGFloat
        let y: CGFloat

        func point(width: CGFloat, height: CGFloat) -> CGPoint {
            CGPoint(x: width * x, y: height * y)
        }
    }

    struct SpeedScaleLabel {
        let text: String
        let point: NormalizedPoint
    }

    enum Dashboard {
        static let outerPadding: CGFloat = 7
        static let sectionSpacing: CGFloat = 6

        static let headerHeightRatio: CGFloat = 0.075
        static let upperSectionHeightRatio: CGFloat = 0.47
        static let lowerSectionHeightRatio: CGFloat = 0.17
        static let architectureHeightRatio: CGFloat = 0.21
        static let footerHeightRatio: CGFloat = 0.04

        static let drivePanelWidthRatio: CGFloat = 0.665
        static let routePanelWidthRatio: CGFloat = 0.42
        static let voltagePanelWidthRatio: CGFloat = 0.20
        static let heartbeatPanelWidthRatio: CGFloat = 0.18
    }

    enum Header {
        static let iconSize: CGFloat = 19
        static let buttonSize: CGFloat = 34
    }

    enum TrainIdentity {
        static let panelSpacing: CGFloat = 5
        static let destinationHeight: CGFloat = 152
        static let chimeHeight: CGFloat = 32
        static let bleLinkHeight: CGFloat = 44
        static let powerMonitorHeight: CGFloat = 84
        static let systemStatusHeight: CGFloat = 68
        static let panelPadding: CGFloat = 5

        static let connectionButtonWidth: CGFloat = 96
        static let connectionButtonHeight: CGFloat = 30
        static let connectionButtonFontSize: CGFloat = 10
    }

    enum RouteMap {
        // DRIVER OPERATIONと同じ横幅に11駅を収める。
        static let connectorMinimumWidth: CGFloat = 8
        static let connectorWidthRatio: CGFloat = 0.014
        static let stationMinimumWidth: CGFloat = 34
    }

    enum LEDBoard {
        static let mainFontSize: CGFloat = 38
        static let marqueeStartGap: CGFloat = 24
        static let marqueeEndGap: CGFloat = 48
    }

    enum Speedometer {
        // MARK: 全体形状
        static let panelCornerRadius: CGFloat = 7
        static let nodeDiameterWidthRatio: CGFloat = 0.078
        static let nodeDiameterHeightRatio: CGFloat = 0.21

        // MARK: LED折れ線の基準点（親ビューに対する正規化座標）
        static let gaugePointRatios: [NormalizedPoint] = [
            .init(x: 0.09, y: 0.80),
            .init(x: 0.165, y: 0.705),
            .init(x: 0.265, y: 0.575),
            .init(x: 0.370, y: 0.445),
            .init(x: 0.500, y: 0.31),
            .init(x: 0.650, y: 0.31),
            .init(x: 0.790, y: 0.31),
            .init(x: 0.940, y: 0.31)
        ]

        // MARK: 目盛数字の位置
        static let scaleLabels: [SpeedScaleLabel] = [
            .init(text: "0", point: .init(x: 0.080, y: 0.89)),
            .init(text: "50", point: .init(x: 0.208, y: 0.765)),
            .init(text: "100", point: .init(x: 0.362, y: 0.635)),
            .init(text: "150", point: .init(x: 0.535, y: 0.45)),
            .init(text: "200", point: .init(x: 0.650, y: 0.39)),
            .init(text: "250", point: .init(x: 0.790, y: 0.39)),
            .init(text: "300", point: .init(x: 0.925, y: 0.39))
        ]
        static let scaleLabelFontMinimum: CGFloat = 8
        static let scaleLabelFontWidthRatio: CGFloat = 0.030

        // MARK: ノッチ丸表示の位置
        static let nodeTitles = ["×", "20", "70", "100", "180", "230", "270", "300"]
        static let stopNodePoint = NormalizedPoint(x: 0.065, y: 0.84)
        static let nodeMinimumYRatio: CGFloat = 0.08
        static let lowerNodeLiftRatio: CGFloat = 0.13
        static let upperNodeLiftRatio: CGFloat = 0.12
        /// index 1=20、2=70。正値は右・下方向。
        static let specialNodeOffsets: [Int: NormalizedPoint] = [
            1: .init(x: -0.026, y: 0.030),
            2: .init(x: -0.022, y: 0.026)
        ]
        static let nodeTextFontMinimum: CGFloat = 8
        static let nodeTextFontDiameterRatio: CGFloat = 0.38

        // MARK: NOTCH・デジタル速度表示の位置
        static let readoutCenter = NormalizedPoint(x: 0.70, y: 0.78)
        static let readoutScale: CGFloat = 0.86
        static let readoutGroupSpacing: CGFloat = 12
        static let notchInnerSpacing: CGFloat = 5
        static let notchLabelFontMinimum: CGFloat = 8
        static let notchLabelFontWidthRatio: CGFloat = 0.014
        static let notchValueFontMinimum: CGFloat = 20
        static let notchValueFontWidthRatio: CGFloat = 0.040
        static let speedValueFontMinimum: CGFloat = 24
        static let speedValueFontWidthRatio: CGFloat = 0.064
        static let speedUnitFontMinimum: CGFloat = 10
        static let speedUnitFontWidthRatio: CGFloat = 0.019
        static let speedGroupSpacing: CGFloat = 7
        static let readoutHorizontalPadding: CGFloat = 12
        static let readoutVerticalPadding: CGFloat = 7

        // MARK: LED列
        static let upperSegmentStartIndex = 4
        static let lowerSegmentLEDCount = 7
        static let upperSegmentLEDCount = 10
    }
}
