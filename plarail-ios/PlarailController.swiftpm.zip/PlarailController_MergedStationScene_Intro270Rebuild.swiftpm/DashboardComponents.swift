import SwiftUI
import Foundation

// MARK: - 背景

struct GridBackground: View {
    var body: some View {
        GeometryReader { _ in
            Canvas { context, size in
                let interval: CGFloat = 26
                
                for x in stride(from: 0, through: size.width, by: interval) {
                    var line = Path()
                    line.move(to: CGPoint(x: x, y: 0))
                    line.addLine(to: CGPoint(x: x, y: size.height))
                    
                    context.stroke(
                        line,
                        with: .color(.green.opacity(0.045)),
                        lineWidth: 1
                    )
                }
                
                for y in stride(from: 0, through: size.height, by: interval) {
                    var line = Path()
                    line.move(to: CGPoint(x: 0, y: y))
                    line.addLine(to: CGPoint(x: size.width, y: y))
                    
                    context.stroke(
                        line,
                        with: .color(.green.opacity(0.045)),
                        lineWidth: 1
                    )
                }
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - 方向幕

struct RouteDisplay: View {
    let routeText: String
    let directionText: String
    let phaseText: String
    let isApproaching: Bool
    
    var body: some View {
        HStack(spacing: 5) {
            Text(routeText)
                .font(.system(size: 17, weight: .black, design: .monospaced))
                .foregroundColor(isApproaching ? .orange : .green)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            
            Spacer(minLength: 2)
            
            VStack(alignment: .trailing, spacing: 0) {
                Text(directionText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                
                if !phaseText.isEmpty {
                    Text(phaseText)
                        .font(.system(size: 9, design: .monospaced))
                }
            }
            .foregroundColor(isApproaching ? .orange : .green.opacity(0.72))
        }
        .padding(.horizontal, 6)
        .background(Color.green.opacity(0.06))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(
                    (isApproaching ? Color.orange : Color.green).opacity(0.75),
                    lineWidth: 0.7
                )
        )
    }
}

struct DirectionSegment: View {
    let text: String
    let subtext: String
    let backgroundColor: Color
    let textColor: Color
    
    // 既存の2引数呼び出しと、色を指定する4引数呼び出しの両方に対応する。
    init(
        text: String,
        subtext: String,
        backgroundColor: Color = Color.white,
        textColor: Color = Color(red: 0.025, green: 0.075, blue: 0.18)
    ) {
        self.text = text
        self.subtext = subtext
        self.backgroundColor = backgroundColor
        self.textColor = textColor
    }
    
    var body: some View {
        ZStack {
            backgroundColor
            
            VStack(spacing: 0) {
                Text(text)
                    .font(.system(size: 33, weight: .black, design: .rounded))
                    .foregroundColor(textColor)
                    .minimumScaleFactor(0.55)
                
                Text(subtext)
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundColor(textColor.opacity(0.88))
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
            }
            
            VStack {
                Spacer()
                
                HStack {
                    Spacer()
                    
                    Image(systemName: "chevron.down")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundColor(textColor.opacity(0.85))
                        .padding(4)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .contentShape(Rectangle())
        .overlay(
            RoundedRectangle(cornerRadius: 2)
                .stroke(textColor.opacity(0.75), lineWidth: 0.8)
                .allowsHitTesting(false)
        )
    }
}

struct BLETransportLogView: View {
    @ObservedObject var manager: PlarailBLEManager
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                if manager.transportLog.isEmpty {
                    Text("RX / TX LOG EMPTY")
                        .font(.system(size: 18, weight: .bold, design: .monospaced))
                        .foregroundColor(.gray)
                } else {
                    ScrollViewReader { proxy in
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 5) {
                                ForEach(manager.transportLog) { entry in
                                    HStack(alignment: .top, spacing: 8) {
                                        Text(
                                            entry.timestamp.formatted(
                                                date: .omitted,
                                                time: .standard
                                            )
                                        )
                                        .foregroundColor(.gray)
                                        .frame(width: 112, alignment: .leading)
                                        
                                        Text(entry.direction == .tx ? "TX >" : "RX <")
                                            .foregroundColor(
                                                entry.direction == .tx
                                                ? .orange
                                                : .green
                                            )
                                            .frame(width: 48, alignment: .leading)
                                        
                                        Text(entry.message)
                                            .foregroundColor(
                                                entry.direction == .tx
                                                ? .orange
                                                : .green
                                            )
                                            .textSelection(.enabled)
                                            .frame(
                                                maxWidth: .infinity,
                                                alignment: .leading
                                            )
                                    }
                                    .font(.system(size: 16, design: .monospaced))
                                    .id(entry.id)
                                }
                            }
                            .padding(12)
                        }
                        .onAppear {
                            scrollToLatest(using: proxy)
                        }
                        .onChange(of: manager.transportLog.count) { _ in
                            scrollToLatest(using: proxy)
                        }
                    }
                }
            }
            .navigationTitle("BLE RX / TX LOG")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("閉じる") {
                        dismiss()
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
    
    private func scrollToLatest(using proxy: ScrollViewProxy) {
        guard let lastEntry = manager.transportLog.last else { return }
        proxy.scrollTo(lastEntry.id, anchor: .bottom)
    }
}

// MARK: - 電光掲示板
struct LEDBlankDisplay: View {
    let textColor: Color
    
    var body: some View {
        ZStack {
            Color.black
            LEDDotGrid()
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(textColor.opacity(0.35), lineWidth: 0.7)
        )
    }
}

struct LEDStaticDisplay: View {
    let message: String
    let textColor: Color
    
    private var displayMessage: String {
        message
            .replacingOccurrences(of: "【", with: "")
            .replacingOccurrences(of: "】", with: "")
    }
    
    var body: some View {
        ZStack {
            Color.black
            
            LEDDotGrid()
            
            Text(displayMessage)
                .font(.system(size: LEDTypography.mainSize, weight: .bold, design: .monospaced))
                .foregroundColor(textColor)
                .lineLimit(1)
                .minimumScaleFactor(0.32)
                .shadow(color: textColor.opacity(0.85), radius: 2)
                .padding(.horizontal, 4)
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(textColor.opacity(0.75), lineWidth: 0.7)
        )
    }
}

struct RouteProgressDisplay: View {
    let previousStation: String
    let nextStation: String
    let textColor: Color
    
    private let frameDuration: TimeInterval = 0.5
    private let cycleFrameCount = 4
    private let displayFont = Font.system(size: LEDTypography.mainSize, weight: .bold, design: .monospaced)
    private let arrowCellWidth: CGFloat = 24
    
    @State private var startedAt = Date()
    
    private func filledArrowCount(at date: Date) -> Int {
        let elapsed = max(0, date.timeIntervalSince(startedAt))
        return Int(elapsed / frameDuration) % cycleFrameCount
    }
    
    var body: some View {
        TimelineView(.periodic(from: .now, by: frameDuration)) { timeline in
            let filledArrowCount = filledArrowCount(at: timeline.date)
            
            ZStack {
                Color.black
                
                LEDDotGrid()
                
                HStack(spacing: 0) {
                    Text(previousStation)
                    
                    ForEach(0..<3, id: \.self) { index in
                        Text(index < filledArrowCount ? "▶" : "▷")
                            .frame(width: arrowCellWidth, alignment: .center)
                    }
                    
                    Text(nextStation)
                }
                .font(displayFont)
                .foregroundColor(textColor)
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
                .shadow(color: textColor.opacity(0.85), radius: 2)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.horizontal, 4)
            }
        }
        .onAppear {
            startedAt = Date()
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(textColor.opacity(0.75), lineWidth: 0.7)
        )
    }
}

enum LEDTypography {
    static let mainSize = UILayoutConfig.LEDBoard.mainFontSize
}

struct LEDMarquee: View {
    let message: String
    let textColor: Color
    let scrollSpeed: CGFloat
    
    private var displayMessage: String {
        message
            .replacingOccurrences(of: "【", with: "")
            .replacingOccurrences(of: "】", with: "")
    }
    
    private let startGap = UILayoutConfig.LEDBoard.marqueeStartGap
    private let endGap = UILayoutConfig.LEDBoard.marqueeEndGap
    
    @State private var startDate = Date()
    
    private var textWidth: CGFloat {
        let font = UIFont.monospacedSystemFont(
            ofSize: LEDTypography.mainSize,
            weight: .bold
        )
        
        return (displayMessage as NSString).size(
            withAttributes: [.font: font]
        ).width
    }
    
    var body: some View {
        GeometryReader { geo in
            TimelineView(
                .animation(
                    minimumInterval: 1.0 / 30.0,
                    paused: false
                )
            ) { timeline in
                let elapsed = timeline.date.timeIntervalSince(startDate)
                
                // 文字の左端を右端の外から開始する
                let initialX = geo.size.width + startGap
                
                // The parent controls the next message after this one has fully left.
                
                let movedDistance =
                CGFloat(elapsed) * scrollSpeed
                
                // Do not wrap while the parent is waiting for this message to
                // finish. Once the final character has left the left edge, hold
                // it outside until ContentView selects the next message.
                let x = max(initialX - movedDistance, -textWidth - endGap)
                
                ZStack(alignment: .leading) {
                    Color.black
                    
                    LEDDotGrid()
                    
                    marqueeText
                        .offset(x: x)
                }
                .clipped()
            }
        }
        .onAppear {
            startDate = Date()
        }
        .onChange(of: message) { _ in
            startDate = Date()
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(textColor.opacity(0.75), lineWidth: 0.7)
        )
    }
    
    private var marqueeText: some View {
        Text(displayMessage)
            .font(.system(size: LEDTypography.mainSize, weight: .bold, design: .monospaced))
            .foregroundColor(textColor)
            .lineLimit(1)
            .fixedSize()
            .shadow(color: textColor.opacity(0.85), radius: 2)
    }
}


/// 通過駅案内専用のスクロール表示。
/// 「ただいま　」と「を通過」は白、駅名部分はオレンジで描画する。
struct PassingStationMarquee: View {
    let message: String
    let scrollSpeed: CGFloat

    private let prefix = "ただいま　"
    private let suffix = "を通過"
    private let startGap = UILayoutConfig.LEDBoard.marqueeStartGap
    private let endGap = UILayoutConfig.LEDBoard.marqueeEndGap

    @State private var startDate = Date()

    private var stationText: String {
        guard message.hasPrefix(prefix),
              message.hasSuffix(suffix) else {
            return message
        }

        let start = message.index(
            message.startIndex,
            offsetBy: prefix.count
        )
        let end = message.index(
            message.endIndex,
            offsetBy: -suffix.count
        )
        return String(message[start..<end])
    }

    private var textWidth: CGFloat {
        let font = UIFont.monospacedSystemFont(
            ofSize: LEDTypography.mainSize,
            weight: .bold
        )

        return (message as NSString).size(
            withAttributes: [.font: font]
        ).width
    }

    var body: some View {
        GeometryReader { geo in
            TimelineView(
                .animation(
                    minimumInterval: 1.0 / 30.0,
                    paused: false
                )
            ) { timeline in
                let elapsed = timeline.date.timeIntervalSince(startDate)
                let initialX = geo.size.width + startGap
                let movedDistance = CGFloat(elapsed) * scrollSpeed
                let x = max(
                    initialX - movedDistance,
                    -textWidth - endGap
                )

                ZStack(alignment: .leading) {
                    Color.black
                    LEDDotGrid()

                    HStack(spacing: 0) {
                        Text(prefix)
                            .foregroundColor(.white)
                            .shadow(
                                color: Color.white.opacity(0.82),
                                radius: 2
                            )

                        Text(stationText)
                            .foregroundColor(.orange)
                            .shadow(
                                color: Color.orange.opacity(0.88),
                                radius: 2
                            )

                        Text(suffix)
                            .foregroundColor(.white)
                            .shadow(
                                color: Color.white.opacity(0.82),
                                radius: 2
                            )
                    }
                    .font(
                        .system(
                            size: LEDTypography.mainSize,
                            weight: .bold,
                            design: .monospaced
                        )
                    )
                    .lineLimit(1)
                    .fixedSize()
                    .offset(x: x)
                }
                .clipped()
            }
        }
        .onAppear {
            startDate = Date()
        }
        .onChange(of: message) { _ in
            startDate = Date()
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
        .overlay(
            RoundedRectangle(cornerRadius: 3)
                .stroke(Color.orange.opacity(0.75), lineWidth: 0.7)
        )
    }
}

struct LEDDotGrid: View {
    var body: some View {
        GeometryReader { _ in
            Canvas { context, size in
                let interval: CGFloat = 5
                let radius: CGFloat = 0.65
                
                for x in stride(from: 1, through: size.width, by: interval) {
                    for y in stride(from: 1, through: size.height, by: interval) {
                        let rect = CGRect(
                            x: x - radius,
                            y: y - radius,
                            width: radius * 2,
                            height: radius * 2
                        )
                        
                        context.fill(
                            Path(ellipseIn: rect),
                            with: .color(.white.opacity(0.11))
                        )
                    }
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - 任意音声ライブラリ

struct ManualAudioLibraryView: View {
    @ObservedObject var audioQueue: AudioQueueManager

    let isOperational: Bool
    let sequenceLocked: Bool
    let onPlayTrack: (Int) -> Void
    let onPlaySequence: ([Int]) -> Void
    let onStop: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var selectedTrackIDs: [Int] = []
    @State private var customTrackText = ""

    private var customTrackID: Int? {
        guard let value = Int(customTrackText),
              (1...2999).contains(value) else {
            return nil
        }
        return value
    }

    private var playbackEnabled: Bool {
        isOperational && !sequenceLocked && !audioQueue.isBusy
    }

    var body: some View {
        NavigationStack {
            List {
                Section("再生状態") {
                    LabeledContent("再生中ID") {
                        Text(audioQueue.currentTrack.map(String.init) ?? "なし")
                            .font(.body.monospaced())
                    }

                    LabeledContent("待機キュー") {
                        Text(
                            audioQueue.queuedTracks.isEmpty
                            ? "なし"
                            : audioQueue.queuedTracks.map(String.init).joined(separator: " → ")
                        )
                        .font(.caption.monospaced())
                        .multilineTextAlignment(.trailing)
                    }

                    if sequenceLocked {
                        Label("発車・停車シーケンス中は手動再生できません", systemImage: "lock.fill")
                            .foregroundStyle(.orange)
                    } else if !isOperational {
                        Label("BLE接続と認証が必要です", systemImage: "antenna.radiowaves.left.and.right.slash")
                            .foregroundStyle(.orange)
                    }
                }

                Section("任意のTrack ID") {
                    HStack {
                        TextField("1〜2999", text: $customTrackText)
                            .keyboardType(.numberPad)
                            .font(.body.monospaced())

                        Button("再生") {
                            guard let customTrackID else { return }
                            onPlayTrack(customTrackID)
                        }
                        .disabled(customTrackID == nil || !playbackEnabled)

                        Button("連続へ追加") {
                            guard let customTrackID else { return }
                            selectedTrackIDs.append(customTrackID)
                            customTrackText = ""
                        }
                        .disabled(customTrackID == nil)
                    }

                    Text("SDカード上のmp3フォルダ番号を直接指定します。同じIDを複数回追加できます。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                ForEach(ManualAudioLibrary.categories, id: \.self) { category in
                    Section(category) {
                        ForEach(
                            ManualAudioLibrary.items.filter { $0.category == category }
                        ) { item in
                            audioRow(item)
                        }
                    }
                }
            }
            .navigationTitle("音声ライブラリ")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("閉じる") { dismiss() }
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 8) {
                    if !selectedTrackIDs.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 5) {
                                Text("連続順")
                                    .font(.caption.bold())
                                ForEach(Array(selectedTrackIDs.enumerated()), id: \.offset) { index, track in
                                    Text("\(index + 1):\(track)")
                                        .font(.caption.monospaced())
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 3)
                                        .background(.thinMaterial)
                                        .clipShape(Capsule())
                                }
                            }
                            .padding(.horizontal)
                        }
                    }

                    HStack(spacing: 10) {
                        Button {
                            selectedTrackIDs.removeAll()
                        } label: {
                            Label("選択解除", systemImage: "xmark.circle")
                        }
                        .buttonStyle(.bordered)
                        .disabled(selectedTrackIDs.isEmpty)

                        Button {
                            onStop()
                        } label: {
                            Label("停止", systemImage: "stop.fill")
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.red)
                        .disabled(!isOperational || sequenceLocked)

                        Button {
                            onPlaySequence(selectedTrackIDs)
                        } label: {
                            Label("連続再生", systemImage: "play.square.stack.fill")
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(selectedTrackIDs.isEmpty || !playbackEnabled)
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical, 10)
                .background(.regularMaterial)
            }
        }
    }

    @ViewBuilder
    private func audioRow(_ item: ManualAudioItem) -> some View {
        let selectedIndex = selectedTrackIDs.firstIndex(of: item.trackID)

        HStack(spacing: 10) {
            Button {
                if let selectedIndex {
                    selectedTrackIDs.remove(at: selectedIndex)
                } else {
                    selectedTrackIDs.append(item.trackID)
                }
            } label: {
                Image(systemName: selectedIndex == nil ? "circle" : "checkmark.circle.fill")
                    .foregroundColor(selectedIndex == nil ? Color.gray : Color.cyan)
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 3) {
                Text(item.title)
                    .font(.body)

                Text("Track ID  \(item.trackID)")
                    .font(.caption.monospaced())
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if let selectedIndex {
                Text("\(selectedIndex + 1)")
                    .font(.caption.bold().monospaced())
                    .frame(width: 24, height: 24)
                    .background(Color.cyan.opacity(0.18))
                    .clipShape(Circle())
            }

            Button("再生") {
                onPlayTrack(item.trackID)
            }
            .buttonStyle(.bordered)
            .disabled(!playbackEnabled)
        }
    }
}

// MARK: - 設定画面

struct ControlSettingsView: View {
    @Binding var selectedChime: ChimeType
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            Form {
                Section("音響") {
                    Picker("車内放送チャイム", selection: $selectedChime) {
                        ForEach(ChimeType.allCases) { chime in
                            Text(chime.title).tag(chime)
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 3) {
                        Text("現在の選択")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        
                        Text(selectedChime.title)
                            .font(.headline)
                        
                        Text(
                            "途中駅 \(selectedChime.intermediateTrack) / 終着駅 \(selectedChime.terminalTrack)"
                        )
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                }
                
                Section("今後追加する設定") {
                    SettingsPlaceholderRow(
                        title: "停車駅設定",
                        detail: "列車種別ごとの停車駅を設定"
                    )
                    
                    SettingsPlaceholderRow(
                        title: "自動音響",
                        detail: "発車・停車・次駅案内ごとの有効／無効"
                    )
                    
                    SettingsPlaceholderRow(
                        title: "表示設定",
                        detail: "電光掲示板・方向幕の表示内容"
                    )
                }
                
                Section("音声ファイル仕様") {
                    Text("iPadはplayMp3Folder()用の番号を送信し、ESP32はその番号の音声を再生する。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("設定")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完了") {
                        dismiss()
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}


struct BLEPasswordEntrySheet: View {
    @ObservedObject var manager: PlarailBLEManager
    let onPasswordSubmitted: (String) -> Void
    let onCancelled: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var password = ""
    @FocusState private var passwordFieldFocused: Bool
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Text("車両に接続")
                    .font(.title2.bold())
                
                Text("\(PlarailBLEUUID.peripheralLocalName) に接続するためのパスワードを入力します。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                
                Text("パスワード入力後に車両の検索・接続を開始します。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                
                SecureField("パスワード", text: $password)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textContentType(.password)
                    .focused($passwordFieldFocused)
                    .submitLabel(.go)
                    .onSubmit {
                        submitPassword()
                    }
                
                if let message = manager.authenticationMessage {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red)
                }
                
                if manager.connectionPhase == .scanning ||
                    manager.connectionPhase == .connecting ||
                    manager.connectionPhase == .discovering {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("車両を検索・接続中")
                    }
                } else if manager.connectionPhase == .authenticating {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("認証中")
                    }
                } else if manager.isVehicleConnectionChecking {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("接続確認中")
                    }
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("BLE認証")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("中止") {
                        passwordFieldFocused = false
                        onCancelled()
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("接続") {
                        submitPassword()
                    }
                    .disabled(password.isEmpty || manager.connectionPhase == .authenticating || manager.isVehicleConnectionChecking)
                }
            }
            .onAppear {
                focusPasswordField()
            }
            .onChange(of: manager.connectionPhase) { phase in
                switch phase {
                case .ready:
                    passwordFieldFocused = false
                    dismiss()
                    
                case .awaitingPassword:
                    // Re-acquire focus after AUTH,FAIL so an external keyboard can
                    // immediately retry without detaching the Magic Keyboard.
                    focusPasswordField()
                    
                case .authenticating:
                    passwordFieldFocused = false
                    
                default:
                    break
                }
            }
        }
        .presentationDetents([.medium])
    }
    
    private func submitPassword() {
        guard !password.isEmpty,
              manager.connectionPhase != .authenticating else {
            return
        }
        
        passwordFieldFocused = false
        onPasswordSubmitted(password)
    }
    
    private func focusPasswordField() {
        // A sheet can appear before its SecureField has joined the responder chain.
        // Deferring focus makes physical keyboard input target this field reliably.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.20) {
            passwordFieldFocused = true
        }
    }
}

struct SettingsPlaceholderRow: View {
    let title: String
    let detail: String
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            Text("未実装")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

// MARK: - UI部品

struct RailwayCabSpeedometer: View {
    /// 0 = 停車×、1...7 = N...P6 の位置。小数を許し、LED列を徐々に移動させる。
    let activeProgress: Double
    /// ESP32からMOTOR,STABLEを受信した時だけ、対応する丸表示を明るく点灯する。
    let stableStep: Int?
    let showsStop: Bool
    let isConnected: Bool
    let displaySpeed: Double
    let notchTitle: String
    
    private let nodeTitles = UILayoutConfig.Speedometer.nodeTitles
    private let scaleLabels = UILayoutConfig.Speedometer.scaleLabels
    
    private let darkRed = Color(red: 0.42, green: 0.035, blue: 0.025)
    private let ledRed = Color(red: 1.0, green: 0.15, blue: 0.05)
    private let ledOrange = Color(red: 1.0, green: 0.39, blue: 0.02)
    private let darkOrange = Color(red: 0.25, green: 0.075, blue: 0.0)
    
    var body: some View {
        GeometryReader { geo in
            let width = max(geo.size.width, 1)
            let height = max(geo.size.height, 1)
            let nodeDiameter = min(
                width * UILayoutConfig.Speedometer.nodeDiameterWidthRatio,
                height * UILayoutConfig.Speedometer.nodeDiameterHeightRatio
            )
            let points = scalePoints(width: width, height: height)
            
            ZStack {
                RoundedRectangle(cornerRadius: UILayoutConfig.Speedometer.panelCornerRadius)
                    .fill(Color.black.opacity(0.88))
                
                // LED列はノッチ変更時に一段ずつ跳ばず、Duty比に応じて徐々に点灯する。
                ForEach(0..<(points.count - 1), id: \.self) { index in
                    let fillFraction = min(
                        max(activeProgress - Double(index), 0),
                        1
                    )
                    
                    OrangeLEDGaugeSegment(
                        start: points[index],
                        end: points[index + 1],
                        fillFraction: isConnected ? fillFraction : 0,
                        onColor: ledOrange,
                        offColor: darkOrange,
                        ledCount: index >= UILayoutConfig.Speedometer.upperSegmentStartIndex
                        ? UILayoutConfig.Speedometer.upperSegmentLEDCount
                        : UILayoutConfig.Speedometer.lowerSegmentLEDCount
                    )
                }
                
                // 各速度表示はLEDのすぐ下側に配置する。
                ForEach(scaleLabels.indices, id: \.self) { index in
                    let label = scaleLabels[index]
                    Text(label.text)
                        .font(
                            .system(
                                size: max(
                                    UILayoutConfig.Speedometer.scaleLabelFontMinimum,
                                    width * UILayoutConfig.Speedometer.scaleLabelFontWidthRatio
                                ),
                                weight: .bold,
                                design: .monospaced
                            )
                        )
                        .foregroundColor(.white)
                        .position(label.point.point(width: width, height: height))
                }
                
                // ノッチ段階。変化中は暗赤色、STABLE通知を受けた段だけLED赤で点灯する。
                ForEach(nodeTitles.indices, id: \.self) { index in
                    let nodePoint = nodeCenter(for: index, points: points, width: width, height: height)
                    let isStable = stableStep == index
                    let isStopNode = index == 0
                    let isLit = isStable || (isStopNode && showsStop)
                    let color = isLit ? ledRed : darkRed
                    
                    ZStack {
                        Circle()
                            .fill(isLit ? color.opacity(0.27) : Color.black)
                        
                        Circle()
                            .stroke(color, lineWidth: isLit ? 2.6 : 1.3)
                        
                        Text(nodeTitles[index])
                            .font(.system(size: max(
                                    UILayoutConfig.Speedometer.nodeTextFontMinimum,
                                    nodeDiameter * UILayoutConfig.Speedometer.nodeTextFontDiameterRatio
                                ), weight: .black, design: .monospaced))
                            .foregroundColor(color)
                    }
                    .frame(width: nodeDiameter, height: nodeDiameter)
                    .shadow(color: isLit ? color.opacity(0.90) : .clear, radius: 6)
                    .position(nodePoint)
                }
                
                // NOTCHを速度LCDの左に配置する。
                HStack(
                    alignment: .center,
                    spacing: UILayoutConfig.Speedometer.readoutGroupSpacing
                ) {
                    HStack(spacing: UILayoutConfig.Speedometer.notchInnerSpacing) {
                        Text("NOTCH")
                            .font(.system(size: max(
                                UILayoutConfig.Speedometer.notchLabelFontMinimum,
                                width * UILayoutConfig.Speedometer.notchLabelFontWidthRatio
                            ), weight: .bold, design: .monospaced))
                            .foregroundColor(.white)
                        
                        Text(notchTitle)
                            .font(.system(size: max(
                                UILayoutConfig.Speedometer.notchValueFontMinimum,
                                width * UILayoutConfig.Speedometer.notchValueFontWidthRatio
                            ), weight: .black, design: .monospaced))
                            .foregroundColor(isConnected ? .orange : .gray)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.90))
                    .overlay(
                        RoundedRectangle(cornerRadius: 3)
                            .stroke(.orange.opacity(0.35), lineWidth: 0.7)
                    )
                    
                    HStack(
                        alignment: .lastTextBaseline,
                        spacing: UILayoutConfig.Speedometer.speedGroupSpacing
                    ) {
                        Text(String(format: "%03.0f", displaySpeed))
                            .font(.system(size: max(
                                UILayoutConfig.Speedometer.speedValueFontMinimum,
                                width * UILayoutConfig.Speedometer.speedValueFontWidthRatio
                            ), weight: .black, design: .monospaced))
                            .foregroundColor(ledRed)
                            .shadow(color: ledRed.opacity(0.80), radius: 3)
                            .padding(.horizontal, UILayoutConfig.Speedometer.readoutHorizontalPadding)
                            .padding(.vertical, UILayoutConfig.Speedometer.readoutVerticalPadding)
                            .background(Color(red: 0.22, green: 0.0, blue: 0.0).opacity(0.80))
                            .overlay(
                                RoundedRectangle(cornerRadius: 3)
                                    .stroke(ledRed.opacity(0.55), lineWidth: 0.8)
                            )
                        
                        Text("km/h")
                            .font(.system(size: max(
                                UILayoutConfig.Speedometer.speedUnitFontMinimum,
                                width * UILayoutConfig.Speedometer.speedUnitFontWidthRatio
                            ), weight: .bold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                }
                // Keep the full NOTCH / speed readout inside the gauge on iPad landscape layouts.
                .scaleEffect(UILayoutConfig.Speedometer.readoutScale, anchor: .center)
                .position(
                    UILayoutConfig.Speedometer.readoutCenter.point(
                        width: width,
                        height: height
                    )
                )
            }
            .overlay(
                RoundedRectangle(cornerRadius: UILayoutConfig.Speedometer.panelCornerRadius)
                    .stroke(.green.opacity(0.60), lineWidth: 0.8)
            )
        }
    }
    
    private func scalePoints(width: CGFloat, height: CGFloat) -> [CGPoint] {
        // 0〜150の部分は一直線の斜めLED列。150以降だけ水平へ折れ曲がる。
        UILayoutConfig.Speedometer.gaugePointRatios.map {
            $0.point(width: width, height: height)
        }
    }
    
    private func nodeCenter(
        for index: Int,
        points: [CGPoint],
        width: CGFloat,
        height: CGFloat
    ) -> CGPoint {
        if index == 0 {
            return UILayoutConfig.Speedometer.stopNodePoint.point(
                width: width,
                height: height
            )
        }

        let point = points[index]
        let liftRatio = index >= UILayoutConfig.Speedometer.upperSegmentStartIndex
            ? UILayoutConfig.Speedometer.upperNodeLiftRatio
            : UILayoutConfig.Speedometer.lowerNodeLiftRatio
        let lift = height * liftRatio
        var position = CGPoint(
            x: point.x,
            y: max(
                height * UILayoutConfig.Speedometer.nodeMinimumYRatio,
                point.y - lift
            )
        )

        if let offset = UILayoutConfig.Speedometer.specialNodeOffsets[index] {
            position.x += width * offset.x
            position.y += height * offset.y
        }
        return position
    }
}

struct RouteMapHyphenConnector: View {
    let isActive: Bool
    
    var body: some View {
        Text("- - -")
            .font(.system(size: 19, weight: .black, design: .monospaced))
            .tracking(-0.6)
            .foregroundColor(isActive ? .green : .green.opacity(0.34))
            .shadow(color: isActive ? Color.green.opacity(0.98) : .clear, radius: isActive ? 7 : 0)
            .lineLimit(1)
            .minimumScaleFactor(0.70)
    }
}

private struct OrangeLEDGaugeSegment: View {
    let start: CGPoint
    let end: CGPoint
    /// 0...1: how far this individual gauge segment has filled.
    let fillFraction: Double
    let onColor: Color
    let offColor: Color
    let ledCount: Int
    
    var body: some View {
        let dx = end.x - start.x
        let dy = end.y - start.y
        let length = max(sqrt(dx * dx + dy * dy), 1)
        let angle = Angle(radians: Double(atan2(dy, dx)))
        // 実車寄りに、細かすぎない太い長方形LEDへする。
        let ledLength = max(14, length / CGFloat(ledCount) - 4)
        
        ZStack {
            ForEach(0..<ledCount, id: \.self) { index in
                let fraction = (CGFloat(index) + 0.5) / CGFloat(ledCount)
                let position = CGPoint(
                    x: start.x + dx * fraction,
                    y: start.y + dy * fraction
                )
                // A single LED fades from dark to bright before the next LED
                // starts. The bar therefore gains LEDs progressively instead of
                // switching an entire segment at one threshold.
                let brightness = min(
                    max(fillFraction * Double(ledCount) - Double(index), 0),
                    1
                )
                
                ZStack {
                    RoundedRectangle(cornerRadius: 2.5)
                        .fill(offColor)
                    
                    RoundedRectangle(cornerRadius: 2.5)
                        .fill(onColor.opacity(brightness))
                }
                .frame(width: ledLength, height: 12)
                .rotationEffect(angle)
                .shadow(
                    color: onColor.opacity(0.90 * brightness),
                    radius: 3.5 * brightness
                )
                .position(position)
            }
        }
    }
}

struct CutPanelShape: Shape {
    func path(in rect: CGRect) -> Path {
        let cut: CGFloat = 10
        
        var path = Path()
        path.move(to: CGPoint(x: rect.minX + cut, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - cut))
        path.addLine(to: CGPoint(x: rect.maxX - cut, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + cut))
        path.closeSubpath()
        
        return path
    }
}

struct HUDPanelModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(8)
            .background(Color.black.opacity(0.72))
            .overlay(
                CutPanelShape()
                    .stroke(.green.opacity(0.62), lineWidth: 0.8)
                    .allowsHitTesting(false)
            )
    }
}

extension View {
    func hudPanel() -> some View {
        modifier(HUDPanelModifier())
    }
}

struct MiniLamp: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(title)
                .font(.system(size: 7, design: .monospaced))
                .foregroundColor(.green.opacity(0.6))
            
            HStack(spacing: 4) {
                Circle()
                    .fill(color)
                    .frame(width: 7, height: 7)
                
                Text(value)
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundColor(color)
            }
        }
    }
}

struct SmallReadout: View {
    let title: String
    let value: String
    let unit: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(title)
                .font(.system(size: 7, design: .monospaced))
                .foregroundColor(.green.opacity(0.6))
            
            HStack(alignment: .lastTextBaseline, spacing: 2) {
                Text(value)
                    .font(.system(size: 16, weight: .bold, design: .monospaced))
                    .foregroundColor(color)
                
                Text(unit)
                    .font(.system(size: 7, design: .monospaced))
                    .foregroundColor(.green.opacity(0.6))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .hudPanel()
    }
}

struct StatusReadout: View {
    let title: String
    let value: String
    let color: Color
    var valueFontSize: CGFloat = 12
    var titleFontSize: CGFloat = 7
    
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(title)
                .font(.system(size: titleFontSize, weight: .bold, design: .monospaced))
                .foregroundColor(.green.opacity(0.65))
            
            Text(value)
                .font(.system(size: valueFontSize, weight: .black, design: .monospaced))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.55)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
}

struct VehicleStatusTile: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 7, design: .monospaced))
                .foregroundColor(.green.opacity(0.6))
            
            Text(value)
                .font(.system(size: 19, weight: .bold, design: .monospaced))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.55)
        }
        .frame(maxWidth: .infinity, minHeight: 52, alignment: .leading)
        .padding(6)
        .background(Color.green.opacity(0.035))
        .overlay(
            CutPanelShape()
                .stroke(color.opacity(0.65), lineWidth: 0.7)
        )
    }
}

struct VehicleInfo: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(title)
                .font(.system(size: 6, design: .monospaced))
                .foregroundColor(.green.opacity(0.55))
            
            Text(value)
                .font(.system(size: 7, weight: .bold, design: .monospaced))
                .foregroundColor(.green)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct CompactModuleCell: View {
    let module: ModuleInfo
    
    var body: some View {
        HStack(spacing: 3) {
            Circle()
                .fill(module.state.color)
                .frame(width: 6, height: 6)
            
            VStack(alignment: .leading, spacing: 1) {
                Text(module.name)
                    .font(.system(size: 7, weight: .bold, design: .monospaced))
                    .foregroundColor(.green)
                    .lineLimit(1)
                
                Text(module.state.rawValue)
                    .font(.system(size: 6, design: .monospaced))
                    .foregroundColor(module.state.color)
            }
            
            Spacer(minLength: 0)
        }
        .padding(4)
        .background(Color.green.opacity(0.04))
        .overlay(
            CutPanelShape()
                .stroke(module.state.color.opacity(0.7), lineWidth: 0.6)
        )
    }
}

struct CompactSystemNode: View {
    let name: String
    let icon: String
    let state: ModuleState

    private var isGlowing: Bool {
        state == .active || state == .fault
    }

    var body: some View {
        VStack(spacing: 2) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(state.color)
                .shadow(
                    color: isGlowing ? state.color.opacity(0.95) : .clear,
                    radius: isGlowing ? 6 : 0
                )

            Text(name)
                .font(.system(size: 6, weight: .bold, design: .monospaced))
                .foregroundColor(
                    state == .offline ? Color.gray : state.color
                )

            Text(state.rawValue)
                .font(.system(size: 5, design: .monospaced))
                .foregroundColor(state.color)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 47)
        .background(
            state.color.opacity(
                state == .active ? 0.16 :
                state == .fault ? 0.18 :
                state == .standby ? 0.07 : 0.025
            )
        )
        .overlay(
            CutPanelShape()
                .stroke(
                    state.color.opacity(isGlowing ? 0.95 : 0.42),
                    lineWidth: isGlowing ? 1.15 : 0.6
                )
        )
        .shadow(
            color: isGlowing ? state.color.opacity(0.55) : .clear,
            radius: isGlowing ? 5 : 0
        )
    }
}

struct TinyArrow: View {
    let state: ModuleState

    var body: some View {
        Image(systemName: "chevron.right")
            .font(.system(size: 8, weight: .bold))
            .foregroundColor(state.color)
            .shadow(
                color: state == .active
                    ? state.color.opacity(0.95)
                    : .clear,
                radius: state == .active ? 4 : 0
            )
    }
}

struct CompactNotch: View {
    let title: String
    let color: Color
    var isSelected = false
    var isPending = false
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            ZStack {
                Text(title)
                    .font(.system(size: 18, weight: .black, design: .monospaced))
                    .foregroundColor(.black)

                if isPending {
                    ProgressView()
                        .controlSize(.mini)
                        .tint(.black)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .padding(.trailing, 5)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(color)
            .clipShape(RoundedRectangle(cornerRadius: 3))
            .overlay(
                RoundedRectangle(cornerRadius: 3)
                    .stroke(
                        isSelected ? Color.white : Color.clear,
                        lineWidth: isSelected ? 3 : 0
                    )
            )
            .shadow(
                color: isPending ? Color.orange.opacity(0.95) : .clear,
                radius: isPending ? 6 : 0
            )
        }
        .buttonStyle(.plain)
    }
}

struct CompactHUDButtonStyle: ButtonStyle {
    let color: Color
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 17, weight: .black))
            .foregroundColor(.black)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(color.opacity(configuration.isPressed ? 0.55 : 1.0))
            .clipShape(RoundedRectangle(cornerRadius: 3))
    }
}
