import SwiftUI
import Combine
import UIKit
import Foundation
import CoreBluetooth
import AVFoundation
import Darwin

// Restored user-selected cabin UI with current BLE, authentication, log, and manual-departure behavior.

struct ContentView: View {
    @StateObject var bleManager = PlarailBLEManager()
    @StateObject var operation = TrainOperationViewModel()
    @StateObject var route = RouteManager()
    @StateObject var audioQueue = AudioQueueManager()
    @StateObject var speedometer = SpeedometerModel()
    @StateObject var marquee = MarqueeManager()
    @StateObject var debugSimulation = DebugSimulationManager()
    
    @State var showPasswordSheet = false
    @State var showBLEErrorAlert = false
    @State var bleErrorMessage = ""
    @State var showVoltageTelemetryAlert = false
    @State var voltageTelemetryAlertMessage = ""
    @State var showOfflineOperationAlert = false
    @State var offlineOperationName = ""
    @State var showBLETransportLog = false
    @State var showManualAudioLibrary = false
    
    static let debugMode2Passcode = AppConfig.Debug.mode2Passcode
    // Accept the previous misspelling once so existing test notes still work.
    static let legacyDebugMode2Passcode = AppConfig.Debug.legacyMode2Passcode
    
    @State var showSettings = false
    @State var showChargeAlert = false
    @State var lowVoltageWarningShown = false
    @State var showTerminalArrivalAlert = false
    @State var terminalArrivalStationName = ""
    
    // ランダム表示のうち、駅間進行表示だけはスクロールさせない。
    let routeProgressDisplayToken = AppConfig.Marquee.routeProgressDisplayToken
    
    // 値は AppConfig.Marquee に集約する。
    let marqueeScrollSpeed: CGFloat = AppConfig.Marquee.baseScrollSpeed
    
    // 走行・停車・掲示板のシミュレーションだけを10 Hzで更新する。
    let simulationTimer = Timer.publish(
        every: AppConfig.Refresh.simulationInterval,
        on: .main,
        in: .common
    )
        .autoconnect()
    
    // BLE監視・Heartbeat・画面時刻更新を1 Hzで実行する。
    let clockTimer = Timer.publish(
        every: AppConfig.Refresh.clockInterval,
        on: .main,
        in: .common
    )
        .autoconnect()
    
    var connected: Bool {
        get { operation.connected }
        nonmutating set { operation.connected = newValue }
    }
    
    var isDebugMode2: Bool {
        get { debugSimulation.isEnabled }
        nonmutating set { debugSimulation.isEnabled = newValue }
    }
    
    var pendingBLEPassword: String? {
        get { debugSimulation.pendingPassword }
        nonmutating set { debugSimulation.pendingPassword = newValue }
    }
    
    var debugSimulationID: UUID {
        get { debugSimulation.sessionID }
        nonmutating set { debugSimulation.sessionID = newValue }
    }
    
    var activeRunID: UInt16 {
        get { operation.activeRunID }
        nonmutating set { operation.activeRunID = newValue }
    }
    
    var vehicleState: VehicleControllerState {
        get { operation.vehicleState }
        nonmutating set { operation.vehicleState = newValue }
    }
    
    var pendingArrivalStation: Station? {
        get { route.pendingArrivalStation }
        nonmutating set { route.pendingArrivalStation = newValue }
    }
    
    var shouldQueuePostDepartureAnnouncement: Bool {
        get { audioQueue.shouldQueuePostDepartureAnnouncement }
        nonmutating set {
            audioQueue.shouldQueuePostDepartureAnnouncement = newValue
        }
    }
    
    var pendingNotchAfterDeparture: Notch? {
        get { operation.pendingNotchAfterDeparture }
        nonmutating set { operation.pendingNotchAfterDeparture = newValue }
    }
    
    var queuedAudioTracks: [Int] {
        audioQueue.queuedTracks
    }

    var currentQueuedAudioTrack: Int? {
        audioQueue.currentTrack
    }
    
    var driveState: DriveState {
        get { operation.driveState }
        nonmutating set { operation.driveState = newValue }
    }
    
    var selectedNotch: Notch {
        get { operation.selectedNotch }
        nonmutating set { operation.selectedNotch = newValue }
    }
    
    var currentSpeed: Double {
        get { speedometer.currentSpeed }
        nonmutating set { speedometer.currentSpeed = newValue }
    }
    
    var targetSpeed: Double {
        get { speedometer.targetSpeed }
        nonmutating set { speedometer.targetSpeed = newValue }
    }
    
    var batteryVoltage: Double? {
        get { operation.batteryVoltage }
        nonmutating set { operation.batteryVoltage = newValue }
    }
    
    var selectedService: TrainService? {
        get { route.selectedService }
        nonmutating set { route.selectedService = newValue }
    }
    
    var selectedDestination: Destination? {
        get { route.selectedDestination }
        nonmutating set { route.selectedDestination = newValue }
    }

    var selectedOriginStation: Station? {
        get { route.selectedOriginStation }
        nonmutating set { route.selectedOriginStation = newValue }
    }
    
    var routeDisplayUpdatePending: Bool {
        get { route.displayUpdatePending }
        nonmutating set { route.displayUpdatePending = newValue }
    }
    
    var selectedChime: ChimeType {
        get { operation.selectedChime }
        nonmutating set { operation.selectedChime = newValue }
    }
    
    var travelDirection: TravelDirection? {
        get { route.travelDirection }
        nonmutating set { route.travelDirection = newValue }
    }
    
    var currentStationIndex: Int? {
        get { route.currentStationIndex }
        nonmutating set { route.currentStationIndex = newValue }
    }
    
    var routePhase: RoutePhase {
        get { route.phase }
        nonmutating set { route.phase = newValue }
    }
    
    var stopSequence: StopSequence {
        get { operation.stopSequence }
        nonmutating set { operation.stopSequence = newValue }
    }
    
    var blankDisplayStartedAt: Date? {
        get { operation.blankDisplayStartedAt }
        nonmutating set { operation.blankDisplayStartedAt = newValue }
    }
    
    var announcementStartedAt: Date? {
        get { operation.announcementStartedAt }
        nonmutating set { operation.announcementStartedAt = newValue }
    }
    
    var marqueeQueue: [String] {
        get { marquee.queue }
        nonmutating set { marquee.queue = newValue }
    }
    
    var currentMarqueeMessage: String? {
        get { marquee.currentMessage }
        nonmutating set { marquee.currentMessage = newValue }
    }
    
    var marqueeStartedAt: Date? {
        get { marquee.startedAt }
        nonmutating set { marquee.startedAt = newValue }
    }
    
    var marqueeDuration: TimeInterval {
        get { marquee.duration }
        nonmutating set { marquee.duration = newValue }
    }
    
    var randomMarqueeEnabled: Bool {
        get { marquee.randomEnabled }
        nonmutating set { marquee.randomEnabled = newValue }
    }
    
    var marqueeSessionID: UUID {
        get { marquee.sessionID }
        nonmutating set { marquee.sessionID = newValue }
    }
    
    var lastRandomMarqueeMessage: String? {
        get { marquee.lastRandomMessage }
        nonmutating set { marquee.lastRandomMessage = newValue }
    }
    
    var randomMarqueeCycle: [String] {
        get { marquee.randomCycle }
        nonmutating set { marquee.randomCycle = newValue }
    }
    
    var preDepartureAnnouncement: String? {
        get { marquee.preDepartureAnnouncement }
        nonmutating set { marquee.preDepartureAnnouncement = newValue }
    }
    
    var preDepartureAnnouncementSessionID: UUID {
        get { marquee.preDepartureSessionID }
        nonmutating set { marquee.preDepartureSessionID = newValue }
    }
    
    var lastMessage: String {
        get { operation.lastMessage }
        nonmutating set { operation.lastMessage = newValue }
    }
    
    var systemTime: Date {
        get { operation.systemTime }
        nonmutating set { operation.systemTime = newValue }
    }
    
    var lastSimulationTime: Date {
        get { speedometer.lastSimulationTime }
        nonmutating set { speedometer.lastSimulationTime = newValue }
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black
                    .ignoresSafeArea()
                
                GridBackground()
                
                VStack(spacing: UILayoutConfig.Dashboard.sectionSpacing) {
                    header
                        .frame(height: geo.size.height * UILayoutConfig.Dashboard.headerHeightRatio)
                    
                    // 旧速度計領域は空枠として残し、右側の列車設定は維持する。
                    HStack(spacing: UILayoutConfig.Dashboard.sectionSpacing) {
                        speedometerPlaceholderPanel
                            .frame(width: geo.size.width * UILayoutConfig.Dashboard.drivePanelWidthRatio)
                        
                        trainPanel
                            .frame(maxWidth: .infinity)
                    }
                    .frame(height: geo.size.height * UILayoutConfig.Dashboard.upperSectionHeightRatio)
                    
                    // 左側に速度計、右側にDRIVER OPERATIONと同幅のROUTE MAPを縦積みする。
                    HStack(spacing: UILayoutConfig.Dashboard.sectionSpacing) {
                        drivePanel
                            .frame(width: geo.size.width * UILayoutConfig.Dashboard.routePanelWidthRatio)
                        
                        VStack(spacing: UILayoutConfig.Dashboard.sectionSpacing) {
                            controlPanel
                                .frame(height: geo.size.height * UILayoutConfig.Dashboard.lowerSectionHeightRatio)
                            
                            routeMapPanel
                                .frame(height: geo.size.height * UILayoutConfig.Dashboard.architectureHeightRatio)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .frame(
                        height: geo.size.height * (
                            UILayoutConfig.Dashboard.lowerSectionHeightRatio +
                            UILayoutConfig.Dashboard.architectureHeightRatio
                        ) + UILayoutConfig.Dashboard.sectionSpacing
                    )
                    
                    HStack(spacing: UILayoutConfig.Dashboard.sectionSpacing) {
                        logPanel
                            .frame(maxWidth: .infinity)

                        voltageTelemetryPanel
                            .frame(width: geo.size.width * UILayoutConfig.Dashboard.voltagePanelWidthRatio)

                        heartbeatPanel
                            .frame(width: geo.size.width * UILayoutConfig.Dashboard.heartbeatPanelWidthRatio)
                    }
                    .frame(height: geo.size.height * UILayoutConfig.Dashboard.footerHeightRatio)
                }
                .padding(UILayoutConfig.Dashboard.outerPadding)
            }
        }
        
        .sheet(isPresented: $showSettings) {
            ControlSettingsView(selectedChime: $operation.selectedChime)
        }
        .sheet(isPresented: $showPasswordSheet) {
            BLEPasswordEntrySheet(
                manager: bleManager,
                onPasswordSubmitted: submitBLEPassword,
                onCancelled: cancelBLEPasswordEntry
            )
        }
        .sheet(isPresented: $showBLETransportLog) {
            BLETransportLogView(manager: bleManager)
        }
        .sheet(isPresented: $showManualAudioLibrary) {
            ManualAudioLibraryView(
                audioQueue: audioQueue,
                isOperational: isSimulatedOrPhysicalLinkReady,
                sequenceLocked: isSequenceLocked,
                onPlayTrack: playManualAudioTrack,
                onPlaySequence: playManualAudioSequence,
                onStop: stopManualAudioPlayback
            )
        }
        .alert("充電が必要です", isPresented: $showChargeAlert) {
            Button("確認", role: .cancel) { }
        } message: {
            Text("電源電圧が6.8Vを下回りました。充電してください。")
        }
        .alert("終着駅に到着しました", isPresented: $showTerminalArrivalAlert) {
            Button("確認", role: .cancel) { }
        } message: {
            Text("\(terminalArrivalStationName)に到着しました。列車種別と行先を未設定へ戻しました。")
        }
        .alert("BLE接続エラー", isPresented: $showBLEErrorAlert) {
            Button("確認", role: .cancel) { }
        } message: {
            Text(bleErrorMessage)
        }
        .alert("電圧監視信号を受信できません", isPresented: $showVoltageTelemetryAlert) {
            Button("確認", role: .cancel) { }
        } message: {
            Text(voltageTelemetryAlertMessage)
        }
        .alert("車両に接続されていません", isPresented: $showOfflineOperationAlert) {
            Button("確認", role: .cancel) { }
        } message: {
            Text("\(offlineOperationName)を実行するには、BLE接続と認証を完了してください。")
        }
        .onChange(of: bleManager.connectionPhase) { phase in
            handleBLEConnectionPhase(phase)
        }
        .onChange(of: bleManager.isVehicleConnectionChecking) { isChecking in
            handleVehicleConnectionChecking(isChecking)
        }
        .onReceive(bleManager.$telemetryEvent) { event in
            guard let event else { return }
            handleTelemetry(event)
        }
        .onReceive(bleManager.$voltageTelemetryAlertMessage) { message in
            guard let message else { return }
            voltageTelemetryAlertMessage = message
            showVoltageTelemetryAlert = true
            lastMessage = "ALERT : VOLTAGE TELEMETRY LOST"
        }
        .onReceive(simulationTimer) { now in
            updatePrediction(now: now)
        }
        .onReceive(clockTimer) { now in
            systemTime = now
            
            // Debug Mode 2 must not emit a heartbeat or any other BLE write.
            if !isDebugMode2 {
                bleManager.performPeriodicMaintenance(runID: activeRunID, now: now)
            }
        }
    }
    
}
