import Foundation
import Combine
import UIKit

final class TrainOperationViewModel: ObservableObject {
    @Published var connected = false
    @Published var activeRunID: UInt16 = 0
    @Published var vehicleState: VehicleControllerState = .unknown
    @Published var pendingNotchAfterDeparture: Notch?
    /// 発車ブザー開始後、発車後チャイムが実際に鳴り始めるまで掲示板を消灯する。
    @Published var departureDisplayWaitingForPostDepartureChime = false
    // 400→700‰開始時に8秒後の発車後音声を予約する。
    // ESP32のREQUESTが先に来た場合はrunIDだけ保持し、予約時刻まで返答を待つ。
    @Published var postDepartureAudioReservedAt: Date?
    @Published var postDepartureAudioPendingRequestRunID: UInt16?

    // 発車・停車の2曲音声はアプリが順序を管理する。
    // 1曲目の終了確認後、設定された曲間を待って2曲目を送る。
    @Published var operationAudioStage: OperationAudioStage = .none
    @Published var operationAudioRunID: UInt16?
    @Published var operationAudioFirstTrack: Int?
    @Published var operationAudioSecondTrack: Int?
    @Published var operationAudioSecondNotBefore: Date?
    @Published var operationAudioFirstFinished = false

    @Published var driveState: DriveState = .disconnected
    @Published var selectedNotch: Notch = .n
    @Published var confirmedNotch: Notch = .n

    // DRIVER OPERATIONの応答性表示とlatest-wins制御。
    // pendingDutyNotchはESP32のAPPLIED待ち、queuedDutyNotchは
    // その間に最後に押されたノッチだけを保持する。
    @Published var pendingDutyRunID: UInt16?
    @Published var pendingDutyNotch: Notch?
    @Published var queuedDutyNotch: Notch?
    // 通常ノッチ変更はATC確認音の終了後にSET_DUTYを送る。
    @Published var pendingATCAudioRunID: UInt16?
    @Published var pendingATCNotch: Notch?
    @Published var driverCommandFeedback = ""
    @Published var driverCommandFeedbackIsError = false

    // 停車指令はESP32のAPPLIEDを受けてから掲示板演出を開始する。
    @Published var pendingStopRunID: UInt16?
    @Published var pendingStopApproachTrack: Int?
    @Published var pendingStopArrivalTrack: Int?
    @Published var stopZeroReachedAt: Date?
    // 停車前の予備減速(→180km/h)と車内放送を並行させるための同期状態。
    @Published var stopPreDecelerationCompleted = false
    @Published var stopAnnouncementFailed = false

    @Published var batteryVoltage: Double?
    @Published var selectedChime: ChimeType = .ambitiousJapan
    @Published var stopSequence: StopSequence = .none
    @Published var blankDisplayStartedAt: Date?
    @Published var announcementStartedAt: Date?
    @Published var lastMessage = "SYSTEM OFFLINE"
    @Published var systemTime = Date()
    
    func nextRunID() -> UInt16 {
        activeRunID = activeRunID == UInt16.max ? 1 : activeRunID + 1
        return activeRunID
    }
}

final class RouteManager: ObservableObject {
    @Published var selectedService: TrainService?
    @Published var selectedDestination: Destination?
    @Published var selectedOriginStation: Station?
    @Published var travelDirection: TravelDirection?
    @Published var currentStationIndex: Int?
    @Published var phase: RoutePhase = .unconfigured
    @Published var pendingArrivalStation: Station?
    @Published var displayUpdatePending = false
    
    var stations: [Station] {
        Station.allCases
    }
    
    var isConfigured: Bool {
        selectedService != nil &&
        selectedDestination != nil &&
        selectedOriginStation != nil &&
        travelDirection != nil &&
        currentStationIndex != nil
    }
    
    var currentStation: Station? {
        guard let currentStationIndex,
              stations.indices.contains(currentStationIndex) else {
            return nil
        }
        
        return stations[currentStationIndex]
    }
    
    var nextStation: Station? {
        guard let currentStationIndex,
              let travelDirection else {
            return nil
        }
        
        let nextIndex = currentStationIndex + travelDirection.step
        guard stations.indices.contains(nextIndex) else { return nil }
        return stations[nextIndex]
    }
    
    var nextStationIsTerminal: Bool {
        guard let nextStation,
              let selectedDestination else {
            return false
        }
        
        return nextStation == selectedDestination.terminalStation
    }
    
    /// 発車後案内用コード。末尾は「現在の発車駅」。
    var departureAnnouncementCode: String? {
        guard let travelDirection,
              let currentStation else {
            return nil
        }

        let directionCode = travelDirection == .upbound ? "u" : "d"
        return "\(directionCode)\(currentStation.audioCode)"
    }

    /// 停車前案内用コード。末尾は「次の停車駅」。
    var arrivalApproachCode: String? {
        guard let travelDirection,
              let nextStation else {
            return nil
        }

        let directionCode = travelDirection == .upbound ? "u" : "d"
        return "\(directionCode)\(nextStation.audioCode)"
    }

    /// 旧コードとの互換。停車前案内では従来どおり次駅基準を使う。
    var routeCode: String? {
        arrivalApproachCode
    }
    
    var remainingStations: [Station] {
        guard let currentStationIndex,
              let travelDirection,
              let selectedDestination else {
            return []
        }
        
        let terminalIndex = selectedDestination.terminalStation.rawValue
        var index = currentStationIndex + travelDirection.step
        var result: [Station] = []
        
        while stations.indices.contains(index) {
            let station = stations[index]
            result.append(station)
            
            if index == terminalIndex {
                break
            }
            
            index += travelDirection.step
        }
        
        return result
    }
    
    func configure(destination: Destination, origin requestedOrigin: Station? = nil) {
        let origin = requestedOrigin ?? selectedOriginStation ?? destination.defaultOriginStation
        selectedDestination = destination
        selectedOriginStation = origin
        currentStationIndex = origin.rawValue
        travelDirection = TravelDirection.from(origin: origin, destination: destination)
        phase = travelDirection == nil ? .unconfigured : .stoppedAtStation
        pendingArrivalStation = nil
    }

    func setOriginStation(_ station: Station) {
        selectedOriginStation = station
        currentStationIndex = station.rawValue

        if let selectedDestination {
            travelDirection = TravelDirection.from(origin: station, destination: selectedDestination)
            phase = travelDirection == nil ? .unconfigured : .stoppedAtStation
        } else {
            travelDirection = nil
            phase = .unconfigured
        }
        pendingArrivalStation = nil
    }
    
    func resetToManualMode() {
        selectedService = nil
        selectedDestination = nil
        selectedOriginStation = nil
        travelDirection = nil
        currentStationIndex = nil
        phase = .unconfigured
        pendingArrivalStation = nil
        displayUpdatePending = false
    }
}

final class AudioQueueManager: ObservableObject {
    @Published var shouldQueuePostDepartureAnnouncement = false
    @Published private(set) var queuedTracks: [Int] = []
    @Published private(set) var currentTrack: Int?
    @Published private(set) var runID: UInt16?
    @Published private(set) var nextTrackNotBefore: Date?

    private var queuedPostFinishDelays: [TimeInterval] = []
    private var currentPostFinishDelay: TimeInterval = 0

    var isBusy: Bool {
        currentTrack != nil || !queuedTracks.isEmpty
    }

    /// 新しい連続再生列を開始する。
    /// - firstTrackDelay: 1曲目を送るまでの待機。
    /// - interTrackDelay: 前曲FINISHED/ERRORから次曲PLAYまでの待機。
    func start(
        runID: UInt16,
        tracks: [Int],
        firstTrackDelay: TimeInterval = 0,
        interTrackDelay: TimeInterval
    ) {
        clear()
        self.runID = runID
        queuedTracks = tracks
        queuedPostFinishDelays = tracks.indices.map { index in
            index < tracks.count - 1 ? max(0, interTrackDelay) : 0
        }
        nextTrackNotBefore = firstTrackDelay > 0
            ? Date().addingTimeInterval(firstTrackDelay)
            : nil
    }

    func enqueue(
        _ tracks: [Int],
        interTrackDelay: TimeInterval
    ) {
        guard !tracks.isEmpty else { return }

        if !queuedPostFinishDelays.isEmpty {
            queuedPostFinishDelays[queuedPostFinishDelays.count - 1] = max(0, interTrackDelay)
        } else if currentTrack != nil {
            currentPostFinishDelay = max(0, interTrackDelay)
        }

        queuedTracks.append(contentsOf: tracks)
        queuedPostFinishDelays.append(contentsOf: tracks.indices.map { index in
            index < tracks.count - 1 ? max(0, interTrackDelay) : 0
        })
    }

    func takeNextTrack(at date: Date = Date()) -> Int? {
        guard currentTrack == nil, !queuedTracks.isEmpty else { return nil }

        if let nextTrackNotBefore, date < nextTrackNotBefore {
            return nil
        }

        self.nextTrackNotBefore = nil
        let track = queuedTracks.removeFirst()
        currentPostFinishDelay = queuedPostFinishDelays.isEmpty
            ? 0
            : queuedPostFinishDelays.removeFirst()
        currentTrack = track
        return track
    }

    func finish(
        runID: UInt16,
        track: Int?,
        at date: Date = Date()
    ) -> Bool {
        guard self.runID == runID,
              currentTrack == track else {
            return false
        }

        currentTrack = nil
        nextTrackNotBefore = currentPostFinishDelay > 0
            ? date.addingTimeInterval(currentPostFinishDelay)
            : nil
        currentPostFinishDelay = 0

        if queuedTracks.isEmpty {
            self.runID = nil
        }
        return true
    }

    func clear() {
        shouldQueuePostDepartureAnnouncement = false
        queuedTracks.removeAll()
        queuedPostFinishDelays.removeAll()
        currentTrack = nil
        currentPostFinishDelay = 0
        runID = nil
        nextTrackNotBefore = nil
    }
}

final class SpeedometerModel: ObservableObject {
    @Published var currentSpeed = 0.0
    @Published var targetSpeed = 0.0
    @Published var lastSimulationTime = Date()
    
    private var slew = SpeedometerSlew(
        startDutyPermille: 0,
        targetDutyPermille: 0,
        startedAt: .distantPast,
        durationOverride: nil
    )
    
    // DCモーター用PWM Dutyと速度計表示の対応表。
    // 実速度ではなく、ノッチに応じた疑似速度表示である。
    private let calibration = AppConfig.Speedometer.calibration

    // 隣接ノッチ間の通常加速率。
    private let dutySlewPermillePerSecond =
        AppConfig.Motor.normalNotchDutyDifference /
        AppConfig.Motor.normalNotchDuration

    // 発車時だけ使う二段始動演出。
    private let startupTo400Rate =
        AppConfig.Motor.startupFirstDuty /
        AppConfig.Motor.startupTo400Duration
    private let startup400To700Rate =
        (AppConfig.Motor.startupSecondDuty - AppConfig.Motor.startupFirstDuty) /
        AppConfig.Motor.startup400To700Duration
    
    func slewDuration(from start: Double, to target: Double) -> TimeInterval {
        if target > start, start < AppConfig.Motor.startupSecondDuty,
           target >= AppConfig.Motor.startupFirstDuty {
            var duration: TimeInterval = 0
            var cursor = start

            if cursor < AppConfig.Motor.startupFirstDuty {
                let segmentTarget = min(target, AppConfig.Motor.startupFirstDuty)
                duration += (segmentTarget - cursor) / startupTo400Rate
                cursor = segmentTarget
            }

            if target > cursor, cursor < AppConfig.Motor.startupSecondDuty {
                let segmentTarget = min(target, AppConfig.Motor.startupSecondDuty)
                duration += (segmentTarget - cursor) / startup400To700Rate
                cursor = segmentTarget
            }

            if target > cursor {
                duration += (target - cursor) / dutySlewPermillePerSecond
            }

            return duration
        }
        
        return abs(target - start) / dutySlewPermillePerSecond
    }
    
    func presentation(at date: Date) -> SpeedometerPresentation {
        let duty = duty(at: date)

        // 停止までの減速時は、Dutyごとの疑似速度表を段階的にたどらず、
        // 減速開始時の表示値から0までを一定割合で直接落とす。
        // これにより低速域だけ長く残る挙動を避ける。
        if slew.startDutyPermille > AppConfig.Motor.dutyEqualityTolerancePermille,
           slew.targetDutyPermille <= AppConfig.Motor.dutyEqualityTolerancePermille {
            let progress = slewProgress(at: date)
            let remaining = 1.0 - progress

            let startGauge = interpolatedValue(
                forDuty: slew.startDutyPermille,
                value: { $0.gaugeProgress }
            )
            let startSpeed = interpolatedValue(
                forDuty: slew.startDutyPermille,
                value: { $0.displaySpeed }
            )

            return SpeedometerPresentation(
                dutyPermille: duty,
                gaugeProgress: startGauge * remaining,
                displaySpeed: startSpeed * remaining
            )
        }

        return SpeedometerPresentation(
            dutyPermille: duty,
            gaugeProgress: interpolatedValue(
                forDuty: duty,
                value: { $0.gaugeProgress }
            ),
            displaySpeed: interpolatedValue(
                forDuty: duty,
                value: { $0.displaySpeed }
            )
        )
    }
    
    /// 最終減速中に、現在時刻から速度計が0になるまで背景が進むべき残距離。
    /// 表示速度が線形に0へ落ちる仕様なので、残り時間との三角形面積で厳密に求める。
    func remainingFinalBrakeSceneTravel(
        at date: Date,
        maxGaugeSpeed: Double = 300,
        maxAnimationSpeed: Double = 2000
    ) -> Double {
        guard slew.startDutyPermille > AppConfig.Motor.dutyEqualityTolerancePermille,
              slew.targetDutyPermille <= AppConfig.Motor.dutyEqualityTolerancePermille else {
            return 0
        }

        let duration = max(
            AppConfig.Motor.minimumAnimationDuration,
            slew.durationOverride ?? slewDuration(
                from: slew.startDutyPermille,
                to: slew.targetDutyPermille
            )
        )
        let elapsed = max(0, date.timeIntervalSince(slew.startedAt))
        let remainingTime = max(0, duration - elapsed)
        guard remainingTime > 0 else { return 0 }

        let currentDisplaySpeed = max(0, presentation(at: date).displaySpeed)
        let currentPixelsPerSecond =
            currentDisplaySpeed / maxGaugeSpeed * maxAnimationSpeed

        return 0.5 * currentPixelsPerSecond * remainingTime
    }

    func startSlew(
        to requestedDuty: Double,
        durationOverride: TimeInterval? = nil
    ) {
        let now = Date()
        let current = presentation(at: now)
        let target = min(
            max(requestedDuty, AppConfig.Motor.minimumDutyPermille),
            AppConfig.Motor.maximumDutyPermille
        )
        
        slew = SpeedometerSlew(
            startDutyPermille: current.dutyPermille,
            targetDutyPermille: target,
            startedAt: now,
            durationOverride: durationOverride
        )
        currentSpeed = current.displaySpeed
        lastSimulationTime = now
    }
    
    func reset(to duty: Double = 0) {
        let clampedDuty = min(
            max(duty, AppConfig.Motor.minimumDutyPermille),
            AppConfig.Motor.maximumDutyPermille
        )
        slew = SpeedometerSlew(
            startDutyPermille: clampedDuty,
            targetDutyPermille: clampedDuty,
            startedAt: Date(),
            durationOverride: nil
        )
        currentSpeed = interpolatedValue(
            forDuty: clampedDuty,
            value: { $0.displaySpeed }
        )
    }
    
    func update(at date: Date) {
        currentSpeed = presentation(at: date).displaySpeed
    }
    
    private func slewProgress(at date: Date) -> Double {
        let elapsed = max(0, date.timeIntervalSince(slew.startedAt))
        let duration = max(
            AppConfig.Motor.minimumAnimationDuration,
            slew.durationOverride ?? slewDuration(
                from: slew.startDutyPermille,
                to: slew.targetDutyPermille
            )
        )

        return min(elapsed / duration, 1)
    }

    private func duty(at date: Date) -> Double {
        let start = slew.startDutyPermille
        let target = slew.targetDutyPermille
        let elapsed = max(0, date.timeIntervalSince(slew.startedAt))
        
        if let durationOverride = slew.durationOverride {
            let duration = max(AppConfig.Motor.minimumAnimationDuration, durationOverride)
            let progress = min(elapsed / duration, 1)
            return start + (target - start) * progress
        }
        
        if target > start, start < AppConfig.Motor.startupSecondDuty,
           target >= AppConfig.Motor.startupFirstDuty {
            var remainingElapsed = elapsed
            var cursor = start

            if cursor < AppConfig.Motor.startupFirstDuty {
                let segmentTarget = min(target, AppConfig.Motor.startupFirstDuty)
                let segmentDuration =
                    (segmentTarget - cursor) / startupTo400Rate

                if remainingElapsed <= segmentDuration {
                    let progress = segmentDuration > 0
                        ? remainingElapsed / segmentDuration
                        : 1
                    return cursor + (segmentTarget - cursor) * progress
                }

                remainingElapsed -= segmentDuration
                cursor = segmentTarget
            }

            if target > cursor, cursor < AppConfig.Motor.startupSecondDuty {
                let segmentTarget = min(target, AppConfig.Motor.startupSecondDuty)
                let segmentDuration =
                    (segmentTarget - cursor) / startup400To700Rate

                if remainingElapsed <= segmentDuration {
                    let progress = segmentDuration > 0
                        ? remainingElapsed / segmentDuration
                        : 1
                    return cursor + (segmentTarget - cursor) * progress
                }

                remainingElapsed -= segmentDuration
                cursor = segmentTarget
            }

            guard target > cursor else { return target }
            let segmentDuration =
                (target - cursor) / dutySlewPermillePerSecond
            let progress = segmentDuration > 0
                ? min(remainingElapsed / segmentDuration, 1)
                : 1
            return cursor + (target - cursor) * progress
        }
        
        let difference = target - start
        let duration = slewDuration(from: start, to: target)
        guard duration > 0 else { return target }
        let progress = min(elapsed / duration, 1)
        return start + difference * progress
    }
    
    private func interpolatedValue(
        forDuty duty: Double,
        value: (SpeedometerCalibrationPoint) -> Double
    ) -> Double {
        guard let first = calibration.first,
              let last = calibration.last else {
            return 0
        }
        
        if duty <= first.dutyPermille { return value(first) }
        if duty >= last.dutyPermille { return value(last) }
        
        for index in 0..<(calibration.count - 1) {
            let lower = calibration[index]
            let upper = calibration[index + 1]
            
            if duty <= upper.dutyPermille {
                let ratio = (duty - lower.dutyPermille) /
                    (upper.dutyPermille - lower.dutyPermille)
                return value(lower) +
                    (value(upper) - value(lower)) * ratio
            }
        }
        
        return value(last)
    }
}

final class MarqueeManager: ObservableObject {
    @Published var queue: [String] = []
    @Published var currentMessage: String?
    @Published var currentDisplayKind: MarqueeDisplayKind = .scrolling
    // 通過駅案内が新しく選ばれた瞬間だけ更新するアニメーション連携イベント。
    // 同じ案内を2回流す仕様でも、駅アニメーションは1回だけ発火する。
    @Published var currentPassingStation: PassingStation?
    @Published var passingStationEventID = UUID()
    @Published var startedAt: Date?
    @Published var duration: TimeInterval = 0
    @Published var randomEnabled = false
    @Published var sessionID = UUID()
    @Published var preDepartureAnnouncement: String?
    @Published var preDepartureSessionID = UUID()

    var lastRandomMessage: String?
    var randomCycle: [String] = []

    // 現在の主要駅間で、まだ表示していない通過駅。
    private var passingStationQueue: [PassingStation] = []
    private var passageDisplayPattern: PassageDisplayPattern = .none

    /// 通過駅が選ばれた後に必ず流す表示。
    /// 1回目の通過案内は即時表示し、ここには
    /// 「同じ通過案内の2回目 → 現在駅―次駅表示」を積む。
    private struct PendingDisplay {
        let message: String
        let displayKind: MarqueeDisplayKind
    }

    private var pendingDisplayQueue: [PendingDisplay] = []

    // 通過駅とランダム案内の並びを制御する状態。
    private enum GeneratedMessageKind {
        case random
        case passingStation
    }

    private var lastGeneratedMessageKind: GeneratedMessageKind?
    private var consecutivePassingCount = 0
    private var randomCountSincePassing = 0

    func setPreDepartureAnnouncement(_ message: String?) {
        preDepartureAnnouncement = message
        preDepartureSessionID = UUID()
    }

    func clearPreDepartureAnnouncement() {
        setPreDepartureAnnouncement(nil)
    }

    /// 主要駅を出発するたびに、その駅間の通過駅キューを作り直す。
    func startDeparture(
        messages: [String],
        passingStations: [PassingStation] = [],
        passageDisplayPattern: PassageDisplayPattern = .none
    ) {
        clearPreDepartureAnnouncement()
        queue = messages
        randomEnabled = true
        lastRandomMessage = nil
        randomCycle = []

        passingStationQueue = passingStations
        self.passageDisplayPattern = passageDisplayPattern
        currentPassingStation = nil
        pendingDisplayQueue = []
        lastGeneratedMessageKind = nil
        consecutivePassingCount = 0
        randomCountSincePassing = 0
    }

    func nextMessage(
        randomCandidates: [String],
        routeProgressToken: String,
        scrollSpeed: CGFloat
    ) {
        let message: String
        let displayKind: MarqueeDisplayKind

        if !queue.isEmpty {
            // 出発直後の案内は、従来どおり最優先で表示する。
            message = queue.removeFirst()
            displayKind = message == routeProgressToken
                ? .routeProgress
                : .scrolling
        } else if !pendingDisplayQueue.isEmpty {
            // 通過案内2回目と、その直後の現在地案内を優先する。
            let pending = pendingDisplayQueue.removeFirst()
            message = pending.message
            displayKind = pending.displayKind
        } else if randomEnabled {
            let generated = nextGeneratedMessage(
                randomCandidates: randomCandidates,
                routeProgressToken: routeProgressToken
            )
            message = generated.message
            displayKind = generated.isPassingStation
                ? .passingStation
                : .scrolling
        } else {
            clear()
            return
        }

        currentMessage = message
        currentDisplayKind = displayKind
        startedAt = Date()
        duration = playbackDuration(
            for: message,
            displayKind: displayKind,
            scrollSpeed: scrollSpeed
        )
        sessionID = UUID()
    }

    func shouldAdvance(at date: Date, sequenceActive: Bool) -> Bool {
        guard !sequenceActive,
              currentMessage != nil,
              let startedAt else {
            return false
        }

        return date.timeIntervalSince(startedAt) >= duration
    }

    func clear() {
        queue = []
        currentMessage = nil
        currentDisplayKind = .scrolling
        startedAt = nil
        duration = 0
        randomEnabled = false
        lastRandomMessage = nil
        randomCycle = []

        passingStationQueue = []
        passageDisplayPattern = .none
        currentPassingStation = nil
        pendingDisplayQueue = []
        lastGeneratedMessageKind = nil
        consecutivePassingCount = 0
        randomCountSincePassing = 0
        sessionID = UUID()
    }

    /// ランダム案内または次の通過駅を、区間ごとの規則に従って選ぶ。
    /// 通過駅をすべて使い切った後は、常に従来のランダム案内を返す。
    private func nextGeneratedMessage(
        randomCandidates: [String],
        routeProgressToken: String
    ) -> (message: String, isPassingStation: Bool) {
        guard !passingStationQueue.isEmpty else {
            return (nextRandomMessage(candidates: randomCandidates), false)
        }

        let shouldShowPassingStation: Bool

        switch passageDisplayPattern {
        case .none:
            shouldShowPassingStation = false

        case .constrainedRandom:
            if lastGeneratedMessageKind == .random {
                // ランダムの次は必ず通過駅。
                shouldShowPassingStation = true
            } else if consecutivePassingCount >= 2 {
                // 通過駅が2回連続した次は必ずランダム。
                shouldShowPassingStation = false
            } else {
                // 最初、または通過駅1回の後は50%で選択する。
                shouldShowPassingStation = Bool.random()
            }

        case .twoRandomThenPassing:
            // ランダム→ランダム→通過駅を繰り返す。
            shouldShowPassingStation = randomCountSincePassing >= 2
        }

        if shouldShowPassingStation {
            let station = passingStationQueue.removeFirst()
            let passageMessage = station.passageMessage

            // 電光掲示板で新しい「〜駅を通過」が選ばれた瞬間を
            // 走行アニメーションへ1回だけ通知する。
            currentPassingStation = station
            passingStationEventID = UUID()

            // 今回返す1回目に続けて、同じ案内をもう1回流し、
            // その後に現在駅―次駅表示を必ず入れる。
            pendingDisplayQueue.append(
                PendingDisplay(
                    message: passageMessage,
                    displayKind: .passingStation
                )
            )
            pendingDisplayQueue.append(
                PendingDisplay(
                    message: routeProgressToken,
                    displayKind: .routeProgress
                )
            )

            lastGeneratedMessageKind = .passingStation
            consecutivePassingCount += 1
            randomCountSincePassing = 0
            return (passageMessage, true)
        }

        let message = nextRandomMessage(candidates: randomCandidates)
        lastGeneratedMessageKind = .random
        consecutivePassingCount = 0
        randomCountSincePassing += 1
        return (message, false)
    }

    private func nextRandomMessage(candidates: [String]) -> String {
        guard !candidates.isEmpty else { return "" }

        let candidateSetChanged =
            Set(randomCycle) != Set(candidates) && !randomCycle.isEmpty

        if randomCycle.isEmpty || candidateSetChanged {
            var nextCycle = candidates.shuffled()

            if let lastRandomMessage,
               nextCycle.count > 1,
               nextCycle.first == lastRandomMessage,
               let swapIndex = nextCycle.firstIndex(
                   where: { $0 != lastRandomMessage }
               ) {
                nextCycle.swapAt(0, swapIndex)
            }

            randomCycle = nextCycle
        }

        let message = randomCycle.removeFirst()
        lastRandomMessage = message
        return message
    }

    private func playbackDuration(
        for message: String,
        displayKind: MarqueeDisplayKind,
        scrollSpeed: CGFloat
    ) -> TimeInterval {
        switch displayKind {
        case .routeProgress:
            // 現在駅―次駅表示だけは6秒間の固定表示。
            return 6.0

        case .scrolling, .passingStation:
            // 通過案内は通常メッセージと同じ速度で最後まで流す。
            break
        }

        let font = UIFont.monospacedSystemFont(
            ofSize: AppConfig.Marquee.measurementFontSize,
            weight: .bold
        )
        let textWidth = (message as NSString).size(
            withAttributes: [.font: font]
        ).width
        let maximumDisplayWidth = AppConfig.Marquee.maximumDisplayWidth
        let exitMargin = AppConfig.Marquee.exitMargin

        return max(
            6,
            TimeInterval(
                (maximumDisplayWidth + textWidth + exitMargin) / scrollSpeed
            )
        )
    }
}

final class DebugSimulationManager: ObservableObject {
    @Published var isEnabled = false
    @Published var pendingPassword: String?
    @Published var sessionID = UUID()
    
    func beginSession() -> UUID {
        sessionID = UUID()
        return sessionID
    }
    
    func invalidateSession() {
        sessionID = UUID()
    }
}
